'use strict';

const fs = require('fs');
const path = require('path');
const config = require('./config');

const SENSITIVE_KEYS = new Set([
  'password',
  'password_hash',
  'passwordHash',
  'currentPassword',
  'newPassword',
  'token',
  'auth_token',
  'authToken',
  'secret',
  'sessionSecret',
  'nodeAuthSecret',
  'csrfSecret',
  'cookie',
  'authorization',
  'x-daemon-token'
]);

function redactObject(obj, depth = 0) {
  if (depth > 4 || obj === null || obj === undefined) return obj;
  if (typeof obj !== 'object') return obj;
  if (obj instanceof Error) {
    return {
      name: obj.name,
      message: obj.message,
      stack: obj.stack
    };
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => redactObject(item, depth + 1));
  }
  const clean = {};
  for (const [k, v] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(k.toLowerCase()) || SENSITIVE_KEYS.has(k)) {
      clean[k] = '[REDACTED]';
    } else {
      clean[k] = redactObject(v, depth + 1);
    }
  }
  return clean;
}

function createLogger(component = 'panel') {
  const logFile = path.join(config.logsDir, `${component}.log`);
  let stream = fs.createWriteStream(logFile, { flags: 'a', encoding: 'utf8' });
  stream.on('error', () => {});

  function write(level, category, message, meta = {}) {
    const timestamp = new Date().toISOString();
    const safeMeta = redactObject(meta);
    const entry = {
      timestamp,
      level,
      component,
      category,
      message,
      ...(Object.keys(safeMeta).length ? { meta: safeMeta } : {})
    };
    const jsonLine = JSON.stringify(entry) + '\n';
    if (stream && !stream.destroyed) {
      stream.write(jsonLine);
    }
    const metaStr = Object.keys(safeMeta).length ? ` ${JSON.stringify(safeMeta)}` : '';
    const line = `[${timestamp}] [${component.toUpperCase()}] [${level.toUpperCase()}] [${category}] ${message}${metaStr}`;
    if (level === 'error') {
      console.error(line);
    } else if (level === 'warn') {
      console.warn(line);
    } else {
      console.log(line);
    }
  }

  return {
    info: (category, message, meta) => write('info', category, message, meta),
    warn: (category, message, meta) => write('warn', category, message, meta),
    error: (category, message, meta) => write('error', category, message, meta),
    flush: () =>
      new Promise((resolve) => {
        if (!stream || stream.destroyed) return resolve();
        stream.end(() => resolve());
      })
  };
}

const panelLogger = createLogger('panel');

module.exports = {
  createLogger,
  logger: panelLogger,
  redactObject
};
