'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dotenv = require('dotenv');

const ROOT_DIR = path.resolve(__dirname, '..');
const ENV_PATH = path.join(ROOT_DIR, '.env');

function ensureEnvFile() {
  let content = '';
  let exists = fs.existsSync(ENV_PATH);
  if (exists) {
    content = fs.readFileSync(ENV_PATH, 'utf8');
  } else if (fs.existsSync(path.join(ROOT_DIR, '.env.example'))) {
    content = fs.readFileSync(path.join(ROOT_DIR, '.env.example'), 'utf8');
  }

  let parsed = dotenv.parse(content);
  let updated = !exists;

  const secretKeys = ['SESSION_SECRET', 'NODE_AUTH_SECRET', 'CSRF_SECRET'];
  for (const key of secretKeys) {
    if (!parsed[key] || parsed[key].trim().length < 32) {
      const generated = crypto.randomBytes(48).toString('hex');
      parsed[key] = generated;
      const regex = new RegExp(`^${key}=.*$`, 'm');
      if (regex.test(content)) {
        content = content.replace(regex, `${key}=${generated}`);
      } else {
        content += `\n${key}=${generated}`;
      }
      updated = true;
    }
  }

  if (updated) {
    fs.writeFileSync(ENV_PATH, content.trim() + '\n', { mode: 0o600 });
  }
}

ensureEnvFile();
dotenv.config({ path: ENV_PATH });

function resolvePath(relOrAbs, fallback) {
  const val = relOrAbs || fallback;
  return path.isAbsolute(val) ? val : path.resolve(ROOT_DIR, val);
}

const config = {
  panelName: 'AashirwadGamerzz Minecraft Server Management Panel',
  shortBrand: 'AashirwadGamerzz',
  panelVersion: 'v1.0.0',
  daemonVersion: 'v1.0.0',
  developer: 'AashirwadGamerzz',

  env: process.env.NODE_ENV || 'production',
  rootDir: ROOT_DIR,

  panelHost: process.env.PANEL_HOST || '0.0.0.0',
  panelPort: parseInt(process.env.PANEL_PORT || '8081', 10),

  daemonHost: process.env.DAEMON_HOST || '127.0.0.1',
  daemonPort: parseInt(process.env.DAEMON_PORT || '18081', 10),
  daemonPublicAddress: process.env.DAEMON_PUBLIC_ADDRESS || '127.0.0.1',

  sessionSecret: process.env.SESSION_SECRET,
  nodeAuthSecret: process.env.NODE_AUTH_SECRET,
  csrfSecret: process.env.CSRF_SECRET,

  databasePath: resolvePath(process.env.DATABASE_PATH, './database/panel.sqlite'),
  serversDir: resolvePath(process.env.SERVERS_DIR, './storage/servers'),
  backupsDir: resolvePath(process.env.BACKUPS_DIR, './storage/backups'),
  worldsDir: resolvePath(process.env.WORLDS_DIR, './storage/worlds'),
  uploadsDir: resolvePath(process.env.UPLOADS_DIR, './storage/uploads'),
  logsDir: resolvePath(process.env.LOGS_DIR, './logs'),

  maxUploadMb: Math.max(1, parseInt(process.env.MAX_UPLOAD_MB || '256', 10)),
  maxBackupsPerServer: Math.max(1, parseInt(process.env.MAX_BACKUPS_PER_SERVER || '10', 10)),
  metricsRetentionHours: Math.max(1, parseInt(process.env.METRICS_RETENTION_HOURS || '24', 10)),
  sessionLifetimeHours: Math.max(1, parseInt(process.env.SESSION_LIFETIME_HOURS || '24', 10)),

  javaBinOverride: process.env.JAVA_BIN ? process.env.JAVA_BIN.trim() : ''
};

// Ensure required directories exist and are writable
const requiredDirs = [
  path.dirname(config.databasePath),
  config.serversDir,
  config.backupsDir,
  config.worldsDir,
  config.uploadsDir,
  config.logsDir
];

for (const dir of requiredDirs) {
  fs.mkdirSync(dir, { recursive: true });
  fs.accessSync(dir, fs.constants.R_OK | fs.constants.W_OK);
}

module.exports = config;
