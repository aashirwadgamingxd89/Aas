'use strict';

const http = require('http');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const { Server: SocketIOServer } = require('socket.io');

const config = require('./config/config');
const { logger } = require('./config/logger');
const { getDb, closeDb } = require('./database/database');
const {
  sessionStore,
  sessionMiddleware,
  attachLocals
} = require('./middleware/auth');
const { maintenanceGuard } = require('./middleware/permissions');
const { notFoundHandler, globalErrorHandler } = require('./middleware/errorHandler');
const { daemonManager } = require('./services/daemonManager');
const { bindSocketIo: bindNotificationSocketIo } = require('./services/notificationService');

// Route modules
const healthRoutes = require('./routes/health');
const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const serverRoutes = require('./routes/servers');
const fileRoutes = require('./routes/files');
const pluginRoutes = require('./routes/plugins');
const worldRoutes = require('./routes/worlds');
const playerRoutes = require('./routes/players');
const backupRoutes = require('./routes/backups');
const startupRoutes = require('./routes/startup');
const settingsRoutes = require('./routes/settings');
const adminRoutes = require('./routes/admin');

function createPanelServer() {
  // Initialize SQLite schema + defaults
  getDb();

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);
  app.set('views', path.join(__dirname, 'views'));
  app.set('view engine', 'ejs');

  // Security headers (iframe-preview compatible, no restrictive frame-ancestors/X-Frame-Options)
  app.use(
    helmet({
      frameguard: false,
      crossOriginEmbedderPolicy: false,
      crossOriginOpenerPolicy: false,
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      contentSecurityPolicy: {
        useDefaults: false,
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'https:', 'http:'],
          fontSrc: ["'self'", 'data:'],
          connectSrc: ["'self'", 'ws:', 'wss:'],
          objectSrc: ["'none'"],
          baseUri: ["'self'"]
        }
      }
    })
  );

  app.use(compression());

  // Static assets
  app.use(
    express.static(path.join(__dirname, 'public'), {
      maxAge: config.env === 'production' ? '1h' : 0,
      etag: true
    })
  );

  // Body parsers
  app.use(express.json({ limit: '5mb' }));
  app.use(express.urlencoded({ extended: true, limit: '5mb' }));

  // Adaptive session cookies + template locals + CSRF generation
  app.use(sessionMiddleware);
  app.use(attachLocals);
  app.use(maintenanceGuard);

  // Application routes
  app.use(healthRoutes);
  app.use(authRoutes);
  app.use(dashboardRoutes);
  app.use(serverRoutes);
  app.use(fileRoutes);
  app.use(pluginRoutes);
  app.use(worldRoutes);
  app.use(playerRoutes);
  app.use(backupRoutes);
  app.use(startupRoutes);
  app.use(settingsRoutes);
  app.use(adminRoutes);

  // 404 & global safe error handler
  app.use(notFoundHandler);
  app.use(globalErrorHandler);

  const httpServer = http.createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: true,
      credentials: true
    },
    transports: ['websocket', 'polling']
  });

  // Share Express session with Socket.IO connections
  io.engine.use((req, res, next) => {
    sessionMiddleware(req, res, next);
  });

  io.on('connection', (socket) => {
    const sess = socket.request && socket.request.session;
    if (!sess || !sess.userId) {
      socket.disconnect(true);
      return;
    }

    const db = getDb();
    const user = db
      .prepare('SELECT id, username, role, status FROM users WHERE id = ?')
      .get(sess.userId);

    if (!user || user.status !== 'active') {
      socket.disconnect(true);
      return;
    }

    socket.data.user = user;
    socket.join(`user:${user.id}`);
    if (user.role === 'admin') {
      socket.join('admin:global');
    }

    socket.on('subscribe:server', (rawUuid) => {
      const uuid = String(rawUuid || '').trim();
      if (!uuid) return;
      try {
        const srv = db
          .prepare('SELECT id, uuid, owner_id FROM servers WHERE uuid = ?')
          .get(uuid);
        if (!srv) return;
        if (user.role !== 'admin' && srv.owner_id !== user.id) {
          return;
        }
        socket.join(`server:${srv.uuid}`);
      } catch (_) {}
    });

    socket.on('unsubscribe:server', (rawUuid) => {
      const uuid = String(rawUuid || '').trim();
      if (uuid) {
        socket.leave(`server:${uuid}`);
      }
    });
  });

  // Bind real-time notification + daemon event bridges
  bindNotificationSocketIo(io);
  daemonManager.bindSocketIo(io);

  async function start() {
    await daemonManager.initialize();
    await new Promise((resolve, reject) => {
      httpServer.once('error', reject);
      httpServer.listen(config.panelPort, config.panelHost, () => {
        logger.info(
          'startup',
          `AashirwadGamerzz Panel ${config.panelVersion} listening on http://${config.panelHost}:${config.panelPort}`
        );
        resolve();
      });
    });
    return { host: config.panelHost, port: config.panelPort };
  }

  async function shutdown() {
    logger.info('shutdown', 'Shutting down AashirwadGamerzz Panel cleanly...');
    await daemonManager.shutdown();
    if (sessionStore && typeof sessionStore.stopCleanup === 'function') {
      sessionStore.stopCleanup();
    }
    await new Promise((resolve) => io.close(() => resolve()));
    await new Promise((resolve) => httpServer.close(() => resolve()));
    closeDb();
    await logger.flush();
  }

  return { app, httpServer, io, start, shutdown };
}

if (require.main === module) {
  const panel = createPanelServer();
  panel.start().catch((err) => {
    logger.error('startup', 'Panel failed to start', { error: err.message, stack: err.stack });
    process.exit(1);
  });

  let shuttingDown = false;
  const handleSignal = async (sig) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info('shutdown', `Received ${sig}, stopping Panel...`);
    try {
      await panel.shutdown();
    } catch (_) {}
    process.exit(0);
  };

  process.on('SIGINT', () => handleSignal('SIGINT'));
  process.on('SIGTERM', () => handleSignal('SIGTERM'));
}

module.exports = { createPanelServer };
