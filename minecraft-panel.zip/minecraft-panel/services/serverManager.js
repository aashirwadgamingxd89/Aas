'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config/config');
const { getDb } = require('../database/database');
const { generateUUID } = require('../utils/cryptoUtils');
const { resolveSafePath } = require('../utils/pathGuard');
const {
  isValidServerName,
  isValidPort,
  parseAndValidateStartupCommand
} = require('../utils/validators');
const { daemonManager } = require('./daemonManager');
const { getLatestTelemetry, removeServerTelemetry } = require('./metricsService');
const { getDirectorySize } = require('../daemon/monitor');
const { getSupportedVersions } = require('../daemon/installer');
const { recordAudit } = require('./auditService');

const SUPPORTED_SOFTWARE = ['paper', 'purpur', 'vanilla', 'fabric', 'forge'];

function findNextAvailablePort(nodeId, startPort = 25565) {
  const db = getDb();
  const used = new Set(
    db
      .prepare('SELECT port FROM servers WHERE node_id = ?')
      .all(nodeId)
      .map((r) => r.port)
  );
  let candidate = startPort;
  while (used.has(candidate) && candidate < 65500) {
    candidate++;
  }
  return candidate;
}

function getUserAllocatedResources(userId) {
  const db = getDb();
  const row = db
    .prepare(`
      SELECT
        COUNT(*) AS serverCount,
        COALESCE(SUM(ram_limit), 0) AS ramMb,
        COALESCE(SUM(disk_limit), 0) AS diskMb,
        COALESCE(SUM(cpu_limit), 0) AS cpuCores
      FROM servers
      WHERE owner_id = ?
    `)
    .get(userId);
  return row || { serverCount: 0, ramMb: 0, diskMb: 0, cpuCores: 0 };
}

function getNodeAllocatedResources(nodeId, excludeServerId = null) {
  const db = getDb();
  const row = excludeServerId
    ? db
        .prepare(`
          SELECT
            COUNT(*) AS serverCount,
            COALESCE(SUM(ram_limit), 0) AS ramMb,
            COALESCE(SUM(disk_limit), 0) AS diskMb,
            COALESCE(SUM(cpu_limit), 0) AS cpuCores
          FROM servers
          WHERE node_id = ? AND id != ?
        `)
        .get(nodeId, excludeServerId)
    : db
        .prepare(`
          SELECT
            COUNT(*) AS serverCount,
            COALESCE(SUM(ram_limit), 0) AS ramMb,
            COALESCE(SUM(disk_limit), 0) AS diskMb,
            COALESCE(SUM(cpu_limit), 0) AS cpuCores
          FROM servers
          WHERE node_id = ?
        `)
        .get(nodeId);
  return row || { serverCount: 0, ramMb: 0, diskMb: 0, cpuCores: 0 };
}

async function listVersionsForSoftware(software, nodeId = null) {
  const cleanType = String(software || 'paper').toLowerCase();
  if (!SUPPORTED_SOFTWARE.includes(cleanType)) {
    throw new Error(`Unsupported server software "${software}".`);
  }
  if (nodeId) {
    try {
      const res = await daemonManager.requestNode(
        nodeId,
        'GET',
        `/api/v1/software/${encodeURIComponent(cleanType)}/versions`
      );
      if (res && Array.isArray(res.versions)) return res.versions;
    } catch (_) {}
  }
  return getSupportedVersions(cleanType);
}

async function createServer({
  actor,
  ownerId,
  name,
  description = '',
  software = 'paper',
  mcVersion = '1.21.4',
  ramLimitMb = 1024,
  diskLimitMb = 2048,
  cpuLimit = 1,
  nodeId,
  port = null,
  ip = ''
}) {
  const db = getDb();

  if (!isValidServerName(name)) {
    throw new Error('Server name must be 2–64 characters and contain valid characters.');
  }

  const cleanSoftware = String(software || 'paper').toLowerCase();
  if (!SUPPORTED_SOFTWARE.includes(cleanSoftware)) {
    throw new Error(`Unsupported server software: ${software}`);
  }

  const ram = parseInt(ramLimitMb, 10);
  const disk = parseInt(diskLimitMb, 10);
  const cpu = Number(cpuLimit);

  if (!Number.isInteger(ram) || ram < 256 || ram > 65536) {
    throw new Error('RAM allocation must be between 256 MB and 65,536 MB.');
  }
  if (!Number.isInteger(disk) || disk < 256 || disk > 524288) {
    throw new Error('Disk allocation must be between 256 MB and 524,288 MB.');
  }
  if (!Number.isFinite(cpu) || cpu < 0.25 || cpu > 64) {
    throw new Error('CPU allocation must be between 0.25 and 64 cores.');
  }

  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(ownerId);
  if (!owner) {
    throw new Error('Target server owner does not exist.');
  }

  // Enforce per-user quotas unless actor is Admin overriding for user or Admin themselves
  if (actor.role !== 'admin') {
    const used = getUserAllocatedResources(owner.id);
    if (used.serverCount + 1 > owner.max_servers) {
      throw new Error(`Server limit reached (${owner.max_servers} servers max).`);
    }
    if (used.ramMb + ram > owner.max_ram_mb) {
      throw new Error(
        `Insufficient RAM quota (${owner.max_ram_mb - used.ramMb} MB remaining of ${owner.max_ram_mb} MB).`
      );
    }
    if (used.diskMb + disk > owner.max_disk_mb) {
      throw new Error(
        `Insufficient Disk quota (${owner.max_disk_mb - used.diskMb} MB remaining of ${owner.max_disk_mb} MB).`
      );
    }
    if (used.cpuCores + cpu > owner.max_cpu_cores) {
      throw new Error(
        `Insufficient CPU quota (${(owner.max_cpu_cores - used.cpuCores).toFixed(2)} cores remaining).`
      );
    }
  }

  // Validate node
  const node = nodeId
    ? db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId)
    : db.prepare("SELECT * FROM nodes WHERE status = 'online' ORDER BY is_local DESC, id ASC LIMIT 1").get();

  if (!node) {
    throw new Error('No online daemon node is available. Check node status in Admin -> Nodes.');
  }

  const health = await daemonManager.checkSingleNodeHealth(node);
  if (health.status !== 'online') {
    throw new Error(`Node "${node.name}" is currently offline.`);
  }

  // Validate node capacity
  const nodeUsed = getNodeAllocatedResources(node.id);
  if (nodeUsed.ramMb + ram > node.ram_capacity) {
    throw new Error(
      `Node "${node.name}" does not have enough free RAM capacity (${Math.max(
        0,
        node.ram_capacity - nodeUsed.ramMb
      )} MB unallocated).`
    );
  }
  if (nodeUsed.diskMb + disk > node.disk_capacity) {
    throw new Error(
      `Node "${node.name}" does not have enough free Disk capacity (${Math.max(
        0,
        node.disk_capacity - nodeUsed.diskMb
      )} MB unallocated).`
    );
  }

  // Validate software + version compatibility
  const versions = await listVersionsForSoftware(cleanSoftware, node.id);
  if (!versions.includes(mcVersion)) {
    throw new Error(`Version "${mcVersion}" is not valid for ${cleanSoftware.toUpperCase()}.`);
  }

  const assignedPort = port ? parseInt(port, 10) : findNextAvailablePort(node.id, 25565);
  if (!isValidPort(assignedPort)) {
    throw new Error('Server port must be between 1024 and 65535.');
  }
  const portConflict = db
    .prepare('SELECT id FROM servers WHERE node_id = ? AND port = ?')
    .get(node.id, assignedPort);
  if (portConflict) {
    throw new Error(`Port ${assignedPort} is already allocated on node "${node.name}".`);
  }

  const uuid = generateUUID();
  const serverDir = resolveSafePath(config.serversDir, uuid);
  fs.mkdirSync(serverDir, { recursive: true });

  const startupCmd = parseAndValidateStartupCommand(
    `java -Xms${Math.min(512, ram)}M -Xmx${ram}M -jar server.jar nogui`,
    ram,
    'server.jar'
  ).normalizedCommand;

  const motd = name.trim();
  const insertResult = db
    .prepare(`
      INSERT INTO servers (
        owner_id, name, uuid, description, server_type, mc_version,
        java_version, ram_limit, cpu_limit, disk_limit, port,
        node_id, server_dir, startup_command, motd, max_players,
        suspended, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, '21', ?, ?, ?, ?, ?, ?, ?, ?, 20, 0, 'installing', datetime('now'))
    `)
    .run(
      owner.id,
      name.trim(),
      uuid,
      String(description || '').trim().slice(0, 250),
      cleanSoftware,
      mcVersion,
      ram,
      cpu,
      disk,
      assignedPort,
      node.id,
      serverDir,
      startupCmd,
      motd
    );

  const serverRow = db.prepare('SELECT * FROM servers WHERE id = ?').get(insertResult.lastInsertRowid);

  // Trigger real installation on the assigned Daemon node
  await daemonManager.requestNode(node, 'POST', `/api/v1/servers/${uuid}/install`, {
    software: cleanSoftware,
    mcVersion,
    port: assignedPort,
    motd,
    maxPlayers: 20,
    serverDir: uuid
  });

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'server.create',
    target: `${serverRow.name} (${uuid})`,
    ip,
    result: 'success',
    details: { software: cleanSoftware, mcVersion, ram, disk, cpu, nodeId: node.id, port: assignedPort }
  });

  return serverRow;
}

async function enrichServerWithTelemetry(serverRow) {
  if (!serverRow) return null;
  const db = getDb();
  const node = db.prepare('SELECT id, name, host, public_host, port, status FROM nodes WHERE id = ?').get(
    serverRow.node_id
  );

  let telemetry = getLatestTelemetry(serverRow.uuid);
  if (!telemetry) {
    const disk = await getDirectorySize(serverRow.server_dir);
    telemetry = {
      uuid: serverRow.uuid,
      status: serverRow.status,
      cpuPercent: 0,
      memoryMb: 0,
      ramLimitMb: serverRow.ram_limit,
      diskMb: disk.mb,
      diskBytes: disk.bytes,
      diskLimitMb: serverRow.disk_limit,
      uptimeSeconds: 0,
      playerCount: 0,
      players: []
    };
  }

  const addressHost = node ? node.public_host || node.host : '127.0.0.1';
  return {
    ...serverRow,
    node,
    address: `${addressHost}:${serverRow.port}`,
    telemetry
  };
}

async function performPowerAction(serverRow, action, actor, ip = '') {
  if (serverRow.suspended && actor.role !== 'admin') {
    throw new Error('This server is currently suspended by an administrator.');
  }
  if (serverRow.status === 'installing') {
    throw new Error('Server software installation is still in progress.');
  }

  const result = await daemonManager.requestNode(
    serverRow.node_id,
    'POST',
    `/api/v1/servers/${serverRow.uuid}/power`,
    {
      action,
      serverConfig: {
        uuid: serverRow.uuid,
        serverDir: serverRow.uuid,
        startupCommand: serverRow.startup_command,
        ramLimitMb: serverRow.ram_limit,
        diskLimitMb: serverRow.disk_limit,
        cpuLimit: serverRow.cpu_limit,
        mcVersion: serverRow.mc_version,
        port: serverRow.port,
        motd: serverRow.motd,
        maxPlayers: serverRow.max_players
      }
    },
    30000
  );

  const db = getDb();
  if (result && result.status) {
    db.prepare('UPDATE servers SET status = ? WHERE id = ?').run(result.status, serverRow.id);
  }

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: `server.power.${action}`,
    target: `${serverRow.name} (${serverRow.uuid})`,
    ip,
    result: 'success'
  });

  return result;
}

async function sendServerCommand(serverRow, command) {
  if (serverRow.suspended) {
    throw new Error('Server is suspended.');
  }
  return daemonManager.requestNode(
    serverRow.node_id,
    'POST',
    `/api/v1/servers/${serverRow.uuid}/command`,
    { command }
  );
}

function readServerProperties(serverRow) {
  const propsPath = resolveSafePath(serverRow.server_dir, 'server.properties');
  const map = {};
  if (fs.existsSync(propsPath)) {
    const lines = fs.readFileSync(propsPath, 'utf8').split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const idx = trimmed.indexOf('=');
      if (idx !== -1) {
        const key = trimmed.slice(0, idx).trim();
        const val = trimmed.slice(idx + 1);
        map[key] = val;
      }
    }
  }
  return map;
}

function getMcVersionCapabilities(mcVersion) {
  const v = String(mcVersion || '1.21.4');
  const isModern26 = /^2[6-9]\./.test(v);
  const m = v.match(/^1\.(\d+)/);
  const minor = isModern26 ? 26 : m ? parseInt(m[1], 10) : 21;

  return {
    supportsSimulationDistance: minor >= 18,
    supportsEntityBroadcastRange: minor >= 16,
    supportsLegacyAchievements: minor < 12,
    supportsEnforceSecureProfile: minor >= 19
  };
}

function writeServerProperties(serverRow, updates) {
  const propsPath = resolveSafePath(serverRow.server_dir, 'server.properties');
  fs.mkdirSync(serverRow.server_dir, { recursive: true });

  const current = readServerProperties(serverRow);
  const caps = getMcVersionCapabilities(serverRow.mc_version);

  const allowedKeys = new Set([
    'motd',
    'max-players',
    'view-distance',
    'gamemode',
    'difficulty',
    'spawn-protection',
    'op-permission-level',
    'max-build-height',
    'level-seed',
    'level-name',
    'online-mode',
    'pvp',
    'allow-flight',
    'enable-command-block',
    'allow-nether',
    'spawn-animals',
    'spawn-monsters',
    'spawn-npcs',
    'white-list'
  ]);

  if (caps.supportsSimulationDistance) allowedKeys.add('simulation-distance');
  if (caps.supportsEntityBroadcastRange) allowedKeys.add('entity-broadcast-range-percentage');
  if (caps.supportsLegacyAchievements) allowedKeys.add('announce-player-achievements');
  if (caps.supportsEnforceSecureProfile) allowedKeys.add('enforce-secure-profile');

  for (const [k, v] of Object.entries(updates)) {
    if (allowedKeys.has(k)) {
      current[k] = String(v).replace(/[\r\n\0]/g, '');
    }
  }

  // Always lock server-port to allocated port
  current['server-port'] = String(serverRow.port);

  const lines = [
    '#Minecraft server properties',
    `#Updated via AashirwadGamerzz Panel at ${new Date().toUTCString()}`
  ];
  for (const [k, v] of Object.entries(current)) {
    lines.push(`${k}=${v}`);
  }
  fs.writeFileSync(propsPath, lines.join('\n') + '\n', 'utf8');

  const db = getDb();
  const motd = current['motd'] || serverRow.motd;
  const maxPlayers = Math.max(1, Math.min(10000, parseInt(current['max-players'] || '20', 10) || 20));
  db.prepare('UPDATE servers SET motd = ?, max_players = ? WHERE id = ?').run(
    motd,
    maxPlayers,
    serverRow.id
  );

  return current;
}

async function reinstallServer(serverRow, { software, mcVersion }, actor, ip = '') {
  const db = getDb();
  if (serverRow.status === 'running' || serverRow.status === 'starting' || serverRow.status === 'stopping') {
    throw new Error('Stop the server before reinstalling software.');
  }

  const targetSoftware = String(software || serverRow.server_type).toLowerCase();
  const targetVersion = String(mcVersion || serverRow.mc_version).trim();
  const versions = await listVersionsForSoftware(targetSoftware, serverRow.node_id);
  if (!versions.includes(targetVersion)) {
    throw new Error(`Minecraft ${targetVersion} is not available for ${targetSoftware.toUpperCase()}.`);
  }

  db.prepare("UPDATE servers SET server_type = ?, mc_version = ?, status = 'installing' WHERE id = ?").run(
    targetSoftware,
    targetVersion,
    serverRow.id
  );

  await daemonManager.requestNode(
    serverRow.node_id,
    'POST',
    `/api/v1/servers/${serverRow.uuid}/install`,
    {
      software: targetSoftware,
      mcVersion: targetVersion,
      port: serverRow.port,
      motd: serverRow.motd,
      maxPlayers: serverRow.max_players,
      serverDir: serverRow.uuid
    }
  );

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'server.reinstall',
    target: `${serverRow.name} (${serverRow.uuid})`,
    ip,
    result: 'success',
    details: { software: targetSoftware, mcVersion: targetVersion }
  });
}

async function deleteServer(serverRow, actor, ip = '') {
  const db = getDb();

  // 1. Stop & remove resources on Daemon node safely
  try {
    await daemonManager.requestNode(
      serverRow.node_id,
      'DELETE',
      `/api/v1/servers/${serverRow.uuid}`,
      null,
      20000
    );
  } catch (_) {
    // If daemon node is offline, ensure local directory cleanup if present
    const safeDir = resolveSafePath(config.serversDir, serverRow.uuid);
    if (fs.existsSync(safeDir)) {
      fs.rmSync(safeDir, { recursive: true, force: true });
    }
  }

  // 2. Remove backups directory for this server
  const serverBackupDir = resolveSafePath(config.backupsDir, serverRow.uuid);
  if (fs.existsSync(serverBackupDir)) {
    fs.rmSync(serverBackupDir, { recursive: true, force: true });
  }

  // 3. Remove cached telemetry & database records (ON DELETE CASCADE cleans metrics, plugins, worlds, backups, players)
  removeServerTelemetry(serverRow.uuid, serverRow.id);
  db.prepare('DELETE FROM servers WHERE id = ?').run(serverRow.id);

  // 4. Audit log
  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'server.delete',
    target: `${serverRow.name} (${serverRow.uuid})`,
    ip,
    result: 'success'
  });
}

module.exports = {
  SUPPORTED_SOFTWARE,
  findNextAvailablePort,
  getUserAllocatedResources,
  getNodeAllocatedResources,
  listVersionsForSoftware,
  createServer,
  enrichServerWithTelemetry,
  performPowerAction,
  sendServerCommand,
  readServerProperties,
  writeServerProperties,
  getMcVersionCapabilities,
  reinstallServer,
  deleteServer
};
