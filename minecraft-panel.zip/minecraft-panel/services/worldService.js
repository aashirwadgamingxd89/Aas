'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const AdmZip = require('adm-zip');
const { getDb } = require('../database/database');
const {
  resolveSafePath,
  sanitizeFilename,
  validateAndExtractZip
} = require('../utils/pathGuard');
const { getDirectorySize } = require('../daemon/monitor');
const { readServerProperties, writeServerProperties } = require('./serverManager');
const { createNotification } = require('./notificationService');
const { recordAudit } = require('./auditService');

function detectWorldType(dirName) {
  if (dirName.endsWith('_nether')) return 'nether';
  if (dirName.endsWith('_the_end')) return 'the_end';
  return 'overworld';
}

function isLikelyWorldFolder(fullDir) {
  try {
    if (fs.existsSync(path.join(fullDir, 'level.dat'))) return true;
    if (fs.existsSync(path.join(fullDir, 'region'))) return true;
    if (fs.existsSync(path.join(fullDir, 'DIM-1')) || fs.existsSync(path.join(fullDir, 'DIM1'))) {
      return true;
    }
    if (fs.existsSync(path.join(fullDir, 'uid.dat'))) return true;
  } catch (_) {}
  return false;
}

async function listServerWorlds(serverRow) {
  const db = getDb();
  fs.mkdirSync(serverRow.server_dir, { recursive: true });

  const props = readServerProperties(serverRow);
  const activeLevelName = (props['level-name'] || 'world').trim() || 'world';

  const dirents = await fsp.readdir(serverRow.server_dir, { withFileTypes: true });
  const foundDirs = new Set();

  for (const d of dirents) {
    if (!d.isDirectory() || d.isSymbolicLink()) continue;
    // Skip known non-world server folders
    if (['plugins', 'mods', 'logs', 'cache', 'config', 'libraries', 'versions', 'crash-reports'].includes(d.name)) {
      continue;
    }
    const fullDir = path.join(serverRow.server_dir, d.name);
    if (
      isLikelyWorldFolder(fullDir) ||
      d.name === activeLevelName ||
      d.name === `${activeLevelName}_nether` ||
      d.name === `${activeLevelName}_the_end`
    ) {
      foundDirs.add(d.name);
      const sizeObj = await getDirectorySize(fullDir, true);
      const st = await fsp.stat(fullDir);
      const isActive = d.name === activeLevelName ? 1 : 0;
      const type = detectWorldType(d.name);

      db.prepare(`
        INSERT INTO worlds (server_id, world_name, directory, size, type, is_active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(server_id, directory) DO UPDATE SET
          size = excluded.size,
          type = excluded.type,
          is_active = excluded.is_active
      `).run(
        serverRow.id,
        d.name,
        d.name,
        sizeObj.bytes,
        type,
        isActive,
        (st.birthtime || st.ctime || new Date()).toISOString()
      );
    }
  }

  // Remove stale DB world rows whose folder no longer exists on disk
  const existingRows = db.prepare('SELECT * FROM worlds WHERE server_id = ?').all(serverRow.id);
  for (const row of existingRows) {
    if (!foundDirs.has(row.directory)) {
      db.prepare('DELETE FROM worlds WHERE id = ?').run(row.id);
    }
  }

  const synced = db
    .prepare(`
      SELECT * FROM worlds
      WHERE server_id = ?
      ORDER BY is_active DESC, world_name COLLATE NOCASE ASC
    `)
    .all(serverRow.id);

  const serverRunning = serverRow.status === 'running';
  return {
    activeLevelName,
    worlds: synced.map((w) => ({
      ...w,
      runtimeStatus: w.is_active
        ? serverRunning
          ? 'LOADED'
          : 'ACTIVE'
        : serverRunning &&
          (w.directory === `${activeLevelName}_nether` || w.directory === `${activeLevelName}_the_end`)
        ? 'LOADED'
        : 'INACTIVE'
    }))
  };
}

async function activateWorld(serverRow, worldName, actor, ip = '') {
  const cleanName = sanitizeFilename(worldName);
  const fullDir = resolveSafePath(serverRow.server_dir, cleanName);
  if (!fs.existsSync(fullDir) || !fs.statSync(fullDir).isDirectory()) {
    throw new Error(`World directory "${cleanName}" does not exist.`);
  }

  writeServerProperties(serverRow, { 'level-name': cleanName });

  const db = getDb();
  db.prepare('UPDATE worlds SET is_active = CASE WHEN directory = ? THEN 1 ELSE 0 END WHERE server_id = ?').run(
    cleanName,
    serverRow.id
  );

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'world.activate',
    target: `${serverRow.name}: ${cleanName}`,
    ip,
    result: 'success'
  });

  return { activeLevelName: cleanName };
}

async function renameWorld(serverRow, oldDirName, newWorldName, actor, ip = '') {
  if (
    serverRow.status === 'running' ||
    serverRow.status === 'starting' ||
    serverRow.status === 'stopping'
  ) {
    throw new Error('Stop the server before renaming a world.');
  }

  const cleanOld = sanitizeFilename(oldDirName);
  const cleanNew = sanitizeFilename(newWorldName);
  const srcPath = resolveSafePath(serverRow.server_dir, cleanOld);
  const dstPath = resolveSafePath(serverRow.server_dir, cleanNew);

  if (!fs.existsSync(srcPath)) {
    throw new Error(`World "${cleanOld}" not found.`);
  }
  if (fs.existsSync(dstPath)) {
    throw new Error(`A folder named "${cleanNew}" already exists.`);
  }

  await fsp.rename(srcPath, dstPath);

  const props = readServerProperties(serverRow);
  if ((props['level-name'] || 'world') === cleanOld) {
    writeServerProperties(serverRow, { 'level-name': cleanNew });
  }

  const db = getDb();
  db.prepare(
    'UPDATE worlds SET world_name = ?, directory = ? WHERE server_id = ? AND directory = ?'
  ).run(cleanNew, cleanNew, serverRow.id, cleanOld);

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'world.rename',
    target: `${serverRow.name}: ${cleanOld} -> ${cleanNew}`,
    ip,
    result: 'success'
  });

  return { oldName: cleanOld, newName: cleanNew };
}

function buildWorldZipBuffer(serverRow, worldDirName) {
  const cleanDir = sanitizeFilename(worldDirName);
  const fullDir = resolveSafePath(serverRow.server_dir, cleanDir);
  if (!fs.existsSync(fullDir) || !fs.statSync(fullDir).isDirectory()) {
    throw new Error(`World "${cleanDir}" not found.`);
  }
  const zip = new AdmZip();
  zip.addLocalFolder(fullDir, cleanDir);
  return {
    fileName: `${cleanDir}.zip`,
    buffer: zip.toBuffer()
  };
}

async function deleteWorld(serverRow, worldDirName, confirmActiveDelete = false, actor, ip = '') {
  const cleanDir = sanitizeFilename(worldDirName);
  const fullDir = resolveSafePath(serverRow.server_dir, cleanDir);
  if (!fs.existsSync(fullDir)) {
    throw new Error(`World "${cleanDir}" does not exist.`);
  }

  const props = readServerProperties(serverRow);
  const activeLevel = (props['level-name'] || 'world').trim() || 'world';
  const isActive =
    cleanDir === activeLevel ||
    cleanDir === `${activeLevel}_nether` ||
    cleanDir === `${activeLevel}_the_end`;

  const isStopped =
    serverRow.status === 'offline' ||
    serverRow.status === 'crashed' ||
    serverRow.status === 'install_failed';

  if (!isStopped) {
    throw new Error('Stop the server before deleting world data.');
  }

  if (isActive && !confirmActiveDelete) {
    throw new Error(
      `World "${cleanDir}" is currently active. Explicit active-world deletion confirmation is required.`
    );
  }

  await fsp.rm(fullDir, { recursive: true, force: true });

  const db = getDb();
  db.prepare('DELETE FROM worlds WHERE server_id = ? AND directory = ?').run(
    serverRow.id,
    cleanDir
  );

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'world.delete',
    target: `${serverRow.name}: ${cleanDir}`,
    ip,
    result: 'success'
  });

  return { deleted: cleanDir };
}

async function installWorldArchive(serverRow, uploadedZipPath, desiredWorldName, actor, ip = '') {
  try {
    if (!fs.existsSync(uploadedZipPath)) {
      throw new Error('Uploaded archive file is missing.');
    }

    const usage = await getDirectorySize(serverRow.server_dir, true);
    const remainingBytes = Math.max(0, (serverRow.disk_limit || 2048) * 1048576 - usage.bytes);
    if (remainingBytes < 1024 * 64) {
      throw new Error('Insufficient server disk quota remaining to import world.');
    }

    let zip;
    try {
      zip = new AdmZip(uploadedZipPath);
    } catch (_) {
      throw new Error('Invalid or corrupted ZIP archive.');
    }

    const entries = zip.getEntries();
    if (entries.length === 0) {
      throw new Error('Uploaded ZIP archive is empty.');
    }

    // Validate that archive actually contains Minecraft world files (level.dat or region/)
    let hasRootLevelDat = false;
    let nestedRootFolder = null;

    for (const entry of entries) {
      const norm = entry.entryName.replace(/\\/g, '/').replace(/^\/+/, '');
      if (norm === 'level.dat' || norm.startsWith('region/')) {
        hasRootLevelDat = true;
        break;
      }
      const m = norm.match(/^([^/]+)\/(level\.dat|region\/)/);
      if (m) {
        nestedRootFolder = m[1];
      }
    }

    if (!hasRootLevelDat && !nestedRootFolder) {
      throw new Error(
        'Archive does not appear to be a valid Minecraft world (missing level.dat or region/ directory).'
      );
    }

    const rawTargetName =
      desiredWorldName && desiredWorldName.trim()
        ? desiredWorldName.trim()
        : nestedRootFolder || `world_imported_${Date.now()}`;
    const cleanWorldName = sanitizeFilename(rawTargetName.replace(/\.zip$/i, ''));
    const finalWorldDir = resolveSafePath(serverRow.server_dir, cleanWorldName);

    if (fs.existsSync(finalWorldDir)) {
      throw new Error(
        `A world or directory named "${cleanWorldName}" already exists. Choose a unique world name.`
      );
    }

    const tempExtractDir = resolveSafePath(
      serverRow.server_dir,
      `.world_import_tmp_${Date.now()}`
    );
    fs.mkdirSync(tempExtractDir, { recursive: true });

    try {
      validateAndExtractZip(zip, tempExtractDir, remainingBytes);

      if (hasRootLevelDat) {
        await fsp.rename(tempExtractDir, finalWorldDir);
      } else {
        const innerDir = resolveSafePath(tempExtractDir, nestedRootFolder);
        await fsp.rename(innerDir, finalWorldDir);
        await fsp.rm(tempExtractDir, { recursive: true, force: true });
      }
    } catch (err) {
      if (fs.existsSync(tempExtractDir)) {
        await fsp.rm(tempExtractDir, { recursive: true, force: true });
      }
      throw err;
    }

    const sizeObj = await getDirectorySize(finalWorldDir, true);
    const db = getDb();
    db.prepare(`
      INSERT INTO worlds (server_id, world_name, directory, size, type, is_active, created_at)
      VALUES (?, ?, ?, ?, ?, 0, datetime('now'))
      ON CONFLICT(server_id, directory) DO UPDATE SET size = excluded.size
    `).run(serverRow.id, cleanWorldName, cleanWorldName, sizeObj.bytes, detectWorldType(cleanWorldName));

    createNotification({
      userId: serverRow.owner_id,
      serverId: serverRow.id,
      type: 'success',
      title: 'World Installed',
      message: `World "${cleanWorldName}" (${sizeObj.mb} MB) imported into "${serverRow.name}".`
    });

    recordAudit({
      userId: actor.id,
      username: actor.username,
      action: 'world.install',
      target: `${serverRow.name}: ${cleanWorldName}`,
      ip,
      result: 'success',
      details: { sizeBytes: sizeObj.bytes }
    });

    return {
      worldName: cleanWorldName,
      sizeBytes: sizeObj.bytes,
      sizeMb: sizeObj.mb
    };
  } finally {
    try {
      if (uploadedZipPath && fs.existsSync(uploadedZipPath)) {
        await fsp.unlink(uploadedZipPath);
      }
    } catch (_) {}
  }
}

module.exports = {
  listServerWorlds,
  activateWorld,
  renameWorld,
  buildWorldZipBuffer,
  deleteWorld,
  installWorldArchive
};
