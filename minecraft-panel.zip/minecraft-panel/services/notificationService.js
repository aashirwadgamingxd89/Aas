'use strict';

const { getDb } = require('../database/database');

let panelIoRef = null;

function bindSocketIo(io) {
  panelIoRef = io;
}

function createNotification({
  userId,
  serverId = null,
  type = 'info',
  title,
  message
}) {
  if (!userId) return null;
  const db = getDb();
  const info = db
    .prepare(`
      INSERT INTO notifications (user_id, server_id, type, title, message, is_read, created_at)
      VALUES (?, ?, ?, ?, ?, 0, datetime('now'))
    `)
    .run(userId, serverId || null, type, String(title), String(message));

  const created = db.prepare('SELECT * FROM notifications WHERE id = ?').get(info.lastInsertRowid);
  const unreadCount = getUnreadCount(userId);

  if (panelIoRef) {
    panelIoRef.to(`user:${userId}`).emit('notification:new', {
      notification: created,
      unreadCount
    });
  }

  return created;
}

function getUnreadCount(userId) {
  if (!userId) return 0;
  const db = getDb();
  const row = db
    .prepare('SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(userId);
  return row ? row.count : 0;
}

function listNotifications(userId, limit = 50) {
  const db = getDb();
  return db
    .prepare(`
      SELECT n.*, s.name AS server_name, s.uuid AS server_uuid
      FROM notifications n
      LEFT JOIN servers s ON s.id = n.server_id
      WHERE n.user_id = ?
      ORDER BY n.id DESC
      LIMIT ?
    `)
    .all(userId, Math.min(200, Math.max(1, limit)));
}

function markAsRead(userId, notificationId) {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(
    notificationId,
    userId
  );
  return getUnreadCount(userId);
}

function markAllAsRead(userId) {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(userId);
  return 0;
}

function deleteNotification(userId, notificationId) {
  const db = getDb();
  db.prepare('DELETE FROM notifications WHERE id = ? AND user_id = ?').run(notificationId, userId);
  return getUnreadCount(userId);
}

module.exports = {
  bindSocketIo,
  createNotification,
  getUnreadCount,
  listNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification
};
