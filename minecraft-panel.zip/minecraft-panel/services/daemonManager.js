'use strict';

const { io: createSocketClient } = require('socket.io-client');
const { getDb } = require('../database/database');
const { logger } = require('../config/logger');
const { createNotification } = require('./notificationService');
const { recordLiveTelemetry, pruneOldMetrics } = require('./metricsService');

class DaemonManager {
  constructor() {
    this.panelIo = null;
    // nodeId -> socket.io-client instance
    this.nodeSockets = new Map();
    // nodeId -> latest health data from daemon
    this.nodeHealthCache = new Map();
    this.healthTimer = null;
    this.pruneTimer = null;
  }

  bindSocketIo(io) {
    this.panelIo = io;
  }

  _buildBaseUrl(node) {
    const host = node.host.includes(':') && !node.host.startsWith('[') ? `[${node.host}]` : node.host;
    return `http://${host}:${node.port}`;
  }

  async requestNode(nodeOrId, method, endpoint, body = null, timeoutMs = 20000) {
    const db = getDb();
    const node =
      typeof nodeOrId === 'object'
        ? nodeOrId
        : db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeOrId);

    if (!node) {
      throw new Error('Assigned daemon node does not exist.');
    }

    const url = `${this._buildBaseUrl(node)}${endpoint}`;
    const headers = {
      'X-Daemon-Token': node.auth_token,
      Accept: 'application/json'
    };
    const fetchOpts = {
      method,
      headers,
      signal: AbortSignal.timeout(timeoutMs)
    };
    if (body !== null && method !== 'GET' && method !== 'HEAD') {
      headers['Content-Type'] = 'application/json';
      fetchOpts.body = JSON.stringify(body);
    }

    let res;
    try {
      res = await fetch(url, fetchOpts);
    } catch (err) {
      this._markNodeOffline(node.id);
      throw new Error(`Daemon node "${node.name}" is unreachable (${err.message}).`);
    }

    let payload = null;
    try {
      payload = await res.json();
    } catch (_) {
      throw new Error(`Invalid response from daemon node "${node.name}" (HTTP ${res.status}).`);
    }

    if (!res.ok || !payload.success) {
      throw new Error(payload.message || `Daemon request failed with HTTP ${res.status}`);
    }

    return payload.data;
  }

  _markNodeOffline(nodeId) {
    try {
      const db = getDb();
      db.prepare("UPDATE nodes SET status = 'offline' WHERE id = ?").run(nodeId);
      const prev = this.nodeHealthCache.get(nodeId) || {};
      this.nodeHealthCache.set(nodeId, { ...prev, status: 'offline', updatedAt: new Date().toISOString() });
      if (this.panelIo) {
        this.panelIo.to('admin:global').emit('node:status', { nodeId, status: 'offline' });
      }
    } catch (_) {}
  }

  connectNodeSocket(node) {
    if (!node || !node.id) return;
    this.disconnectNodeSocket(node.id);

    const url = this._buildBaseUrl(node);
    const socket = createSocketClient(url, {
      auth: { token: node.auth_token },
      reconnection: true,
      reconnectionDelay: 2000,
      reconnectionDelayMax: 10000,
      timeout: 8000
    });

    socket.on('connect', () => {
      logger.info('daemonManager', `Connected event stream to node "${node.name}" (${url})`);
      this.checkSingleNodeHealth(node).catch(() => {});
    });

    socket.on('disconnect', () => {
      this._markNodeOffline(node.id);
    });

    socket.on('connect_error', () => {
      this._markNodeOffline(node.id);
    });

    socket.on('server:console', (payload) => {
      if (this.panelIo && payload && payload.uuid) {
        this.panelIo.to(`server:${payload.uuid}`).emit('server:console', payload);
      }
    });

    socket.on('server:status', (payload) => {
      if (!payload || !payload.uuid) return;
      try {
        const db = getDb();
        const srv = db.prepare('SELECT * FROM servers WHERE uuid = ?').get(payload.uuid);
        if (!srv) return;

        if (payload.status === 'running') {
          db.prepare("UPDATE servers SET status = 'running', last_started = datetime('now') WHERE id = ?").run(
            srv.id
          );
          if (srv.status !== 'running') {
            createNotification({
              userId: srv.owner_id,
              serverId: srv.id,
              type: 'success',
              title: 'Server Online',
              message: `Server "${srv.name}" is now running.`
            });
          }
        } else {
          db.prepare('UPDATE servers SET status = ? WHERE id = ?').run(payload.status, srv.id);
          if (payload.status === 'offline' && (srv.status === 'running' || srv.status === 'stopping')) {
            createNotification({
              userId: srv.owner_id,
              serverId: srv.id,
              type: 'info',
              title: 'Server Stopped',
              message: `Server "${srv.name}" has stopped.`
            });
          }
        }

        if (this.panelIo) {
          this.panelIo.to(`server:${srv.uuid}`).emit('server:status', payload);
          this.panelIo.to(`user:${srv.owner_id}`).emit('server:status', payload);
          this.panelIo.to('admin:global').emit('server:status', payload);
        }
      } catch (err) {
        logger.error('daemonManager', 'Error handling server:status', { error: err.message });
      }
    });

    socket.on('server:crash', (payload) => {
      if (!payload || !payload.uuid) return;
      try {
        const db = getDb();
        const srv = db.prepare('SELECT * FROM servers WHERE uuid = ?').get(payload.uuid);
        if (!srv) return;
        db.prepare("UPDATE servers SET status = 'crashed' WHERE id = ?").run(srv.id);
        createNotification({
          userId: srv.owner_id,
          serverId: srv.id,
          type: 'danger',
          title: 'Server Crashed',
          message: `Server "${srv.name}" exited unexpectedly (exit code ${payload.exitCode ?? 'unknown'}).`
        });
      } catch (_) {}
    });

    socket.on('server:metrics', (stats) => {
      if (!stats || !stats.uuid) return;
      try {
        const db = getDb();
        const srv = db
          .prepare('SELECT id, uuid, owner_id, ram_limit, disk_limit FROM servers WHERE uuid = ?')
          .get(stats.uuid);
        if (!srv) return;

        recordLiveTelemetry(srv, stats);

        if (this.panelIo) {
          this.panelIo.to(`server:${srv.uuid}`).emit('server:metrics', stats);
          this.panelIo.to(`user:${srv.owner_id}`).emit('server:metrics', stats);
          this.panelIo.to('admin:global').emit('server:metrics', stats);
        }
      } catch (_) {}
    });

    socket.on('server:player_join', (payload) => {
      if (!payload || !payload.uuid || !payload.player) return;
      try {
        const db = getDb();
        const srv = db.prepare('SELECT id, uuid, owner_id FROM servers WHERE uuid = ?').get(payload.uuid);
        if (!srv) return;

        db.prepare(`
          INSERT INTO known_players (server_id, uuid, username, first_seen, last_seen)
          VALUES (?, ?, ?, datetime('now'), datetime('now'))
          ON CONFLICT(server_id, username) DO UPDATE SET
            uuid = CASE WHEN excluded.uuid != '' THEN excluded.uuid ELSE known_players.uuid END,
            last_seen = datetime('now')
        `).run(srv.id, payload.player.uuid || '', payload.player.username);

        if (this.panelIo) {
          this.panelIo.to(`server:${srv.uuid}`).emit('server:players', payload);
        }
      } catch (_) {}
    });

    socket.on('server:player_leave', (payload) => {
      if (!payload || !payload.uuid) return;
      try {
        const db = getDb();
        const srv = db.prepare('SELECT id, uuid FROM servers WHERE uuid = ?').get(payload.uuid);
        if (!srv) return;
        if (payload.username) {
          db.prepare(
            "UPDATE known_players SET last_seen = datetime('now') WHERE server_id = ? AND username = ?"
          ).run(srv.id, payload.username);
        }
        if (this.panelIo) {
          this.panelIo.to(`server:${srv.uuid}`).emit('server:players', payload);
        }
      } catch (_) {}
    });

    socket.on('server:install_progress', (payload) => {
      if (this.panelIo && payload && payload.uuid) {
        this.panelIo.to(`server:${payload.uuid}`).emit('server:install', payload);
      }
    });

    socket.on('server:install_complete', (payload) => {
      if (!payload || !payload.uuid) return;
      try {
        const db = getDb();
        const srv = db.prepare('SELECT * FROM servers WHERE uuid = ?').get(payload.uuid);
        if (!srv) return;

        db.prepare("UPDATE servers SET status = 'offline', java_version = ? WHERE id = ?").run(
          payload.javaVersion || srv.java_version || '21',
          srv.id
        );

        createNotification({
          userId: srv.owner_id,
          serverId: srv.id,
          type: 'success',
          title: 'Server Installation Complete',
          message: `Server "${srv.name}" (${srv.server_type.toUpperCase()} ${srv.mc_version}) is ready to start.`
        });

        if (this.panelIo) {
          this.panelIo.to(`server:${srv.uuid}`).emit('server:install', payload);
          this.panelIo.to(`user:${srv.owner_id}`).emit('server:status', {
            uuid: srv.uuid,
            status: 'offline'
          });
        }
      } catch (_) {}
    });

    socket.on('server:install_failed', (payload) => {
      if (!payload || !payload.uuid) return;
      try {
        const db = getDb();
        const srv = db.prepare('SELECT * FROM servers WHERE uuid = ?').get(payload.uuid);
        if (!srv) return;

        db.prepare("UPDATE servers SET status = 'install_failed' WHERE id = ?").run(srv.id);
        createNotification({
          userId: srv.owner_id,
          serverId: srv.id,
          type: 'danger',
          title: 'Server Installation Failed',
          message: `Installation failed for "${srv.name}": ${payload.error || payload.message}`
        });

        if (this.panelIo) {
          this.panelIo.to(`server:${srv.uuid}`).emit('server:install', payload);
          this.panelIo.to(`user:${srv.owner_id}`).emit('server:status', {
            uuid: srv.uuid,
            status: 'install_failed'
          });
        }
      } catch (_) {}
    });

    this.nodeSockets.set(node.id, socket);
  }

  disconnectNodeSocket(nodeId) {
    const existing = this.nodeSockets.get(nodeId);
    if (existing) {
      existing.removeAllListeners();
      existing.disconnect();
      this.nodeSockets.delete(nodeId);
    }
  }

  async checkSingleNodeHealth(node) {
    const db = getDb();
    try {
      const data = await this.requestNode(node, 'GET', '/api/v1/health', null, 6000);
      db.prepare(`
        UPDATE nodes
        SET status = 'online',
            daemon_version = ?,
            last_seen = datetime('now')
        WHERE id = ?
      `).run(data.daemonVersion || 'v1.0.0', node.id);

      const health = {
        nodeId: node.id,
        status: 'online',
        ...data,
        updatedAt: new Date().toISOString()
      };
      this.nodeHealthCache.set(node.id, health);

      if (this.panelIo) {
        this.panelIo.to('admin:global').emit('node:health', health);
      }
      return health;
    } catch (err) {
      this._markNodeOffline(node.id);
      return {
        nodeId: node.id,
        status: 'offline',
        error: err.message,
        updatedAt: new Date().toISOString()
      };
    }
  }

  async checkAllNodesHealth() {
    const db = getDb();
    const nodes = db.prepare('SELECT * FROM nodes').all();
    const results = [];
    for (const node of nodes) {
      if (!this.nodeSockets.has(node.id)) {
        this.connectNodeSocket(node);
      }
      results.push(await this.checkSingleNodeHealth(node));
    }
    return results;
  }

  getNodeHealth(nodeId) {
    return this.nodeHealthCache.get(nodeId) || null;
  }

  async initialize() {
    const db = getDb();
    // Reset stale transient running states in DB until synchronized with live daemons
    const nodes = db.prepare('SELECT * FROM nodes').all();
    for (const node of nodes) {
      this.connectNodeSocket(node);
    }
    await this.checkAllNodesHealth();

    // Synchronize actual running server statuses from online nodes
    for (const node of nodes) {
      const servers = db.prepare('SELECT * FROM servers WHERE node_id = ?').all(node.id);
      if (servers.length === 0) continue;
      try {
        const batch = await this.requestNode(node, 'POST', '/api/v1/servers/telemetry-batch', {
          servers: servers.map((s) => ({
            uuid: s.uuid,
            dir: s.uuid,
            ramLimitMb: s.ram_limit,
            diskLimitMb: s.disk_limit
          }))
        });
        const telemetryMap = (batch && batch.telemetry) || {};
        for (const srv of servers) {
          const t = telemetryMap[srv.uuid];
          if (t) {
            recordLiveTelemetry(srv, t);
            if (srv.status !== 'installing' && srv.status !== 'install_failed') {
              db.prepare('UPDATE servers SET status = ? WHERE id = ?').run(t.status, srv.id);
            }
          }
        }
      } catch (_) {}
    }

    this.healthTimer = setInterval(() => {
      this.checkAllNodesHealth().catch(() => {});
    }, 15000);
    this.healthTimer.unref();

    this.pruneTimer = setInterval(() => {
      pruneOldMetrics();
    }, 30 * 60 * 1000);
    this.pruneTimer.unref();
  }

  async shutdown() {
    if (this.healthTimer) clearInterval(this.healthTimer);
    if (this.pruneTimer) clearInterval(this.pruneTimer);
    for (const nodeId of this.nodeSockets.keys()) {
      this.disconnectNodeSocket(nodeId);
    }
  }
}

const daemonManager = new DaemonManager();

module.exports = {
  daemonManager
};
