'use strict';

const fs = require('fs');
const path = require('path');
const { getDb } = require('../database/database');
const { resolveSafePath } = require('../utils/pathGuard');
const { getLatestTelemetry } = require('./metricsService');
const { sendServerCommand } = require('./serverManager');
const { recordAudit } = require('./auditService');

function readJsonArraySafe(serverDir, fileName) {
  try {
    const filePath = resolveSafePath(serverDir, fileName);
    if (!fs.existsSync(filePath)) return [];
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return Array.isArray(data) ? data : [];
  } catch (_) {
    return [];
  }
}

function writeJsonArraySafe(serverDir, fileName, arr) {
  const filePath = resolveSafePath(serverDir, fileName);
  fs.writeFileSync(filePath, JSON.stringify(arr, null, 2) + '\n', 'utf8');
}

function getPlayersOverview(serverRow) {
  const db = getDb();
  const telemetry = getLatestTelemetry(serverRow.uuid);
  const onlineList = (telemetry && Array.isArray(telemetry.players) ? telemetry.players : []);
  const onlineSet = new Map(onlineList.map((p) => [p.username.toLowerCase(), p]));

  const usercache = readJsonArraySafe(serverRow.server_dir, 'usercache.json');
  const ops = readJsonArraySafe(serverRow.server_dir, 'ops.json');
  const whitelist = readJsonArraySafe(serverRow.server_dir, 'whitelist.json');
  const banned = readJsonArraySafe(serverRow.server_dir, 'banned-players.json');

  // Sync usercache entries into known_players
  const upsertKnown = db.prepare(`
    INSERT INTO known_players (server_id, uuid, username, first_seen, last_seen)
    VALUES (?, ?, ?, datetime('now'), datetime('now'))
    ON CONFLICT(server_id, username) DO UPDATE SET
      uuid = CASE WHEN excluded.uuid != '' THEN excluded.uuid ELSE known_players.uuid END
  `);
  for (const entry of usercache) {
    if (entry && entry.name) {
      upsertKnown.run(serverRow.id, entry.uuid || '', entry.name);
    }
  }

  const knownRows = db
    .prepare('SELECT * FROM known_players WHERE server_id = ? ORDER BY last_seen DESC')
    .all(serverRow.id);

  const opSet = new Set(ops.map((o) => String(o.name || '').toLowerCase()).filter(Boolean));
  const wlSet = new Set(whitelist.map((w) => String(w.name || '').toLowerCase()).filter(Boolean));
  const banMap = new Map(
    banned
      .filter((b) => b && b.name)
      .map((b) => [String(b.name).toLowerCase(), b])
  );

  const mergedMap = new Map();

  for (const row of knownRows) {
    const key = row.username.toLowerCase();
    const live = onlineSet.get(key);
    mergedMap.set(key, {
      username: row.username,
      uuid: (live && live.uuid) || row.uuid || '',
      online: Boolean(live),
      firstSeen: row.first_seen,
      lastSeen: live ? new Date().toISOString() : row.last_seen,
      isOp: opSet.has(key),
      isWhitelisted: wlSet.has(key),
      isBanned: banMap.has(key),
      banReason: banMap.has(key) ? banMap.get(key).reason || '' : ''
    });
  }

  for (const live of onlineList) {
    const key = live.username.toLowerCase();
    if (!mergedMap.has(key)) {
      mergedMap.set(key, {
        username: live.username,
        uuid: live.uuid || '',
        online: true,
        firstSeen: live.joinedAt,
        lastSeen: new Date().toISOString(),
        isOp: opSet.has(key),
        isWhitelisted: wlSet.has(key),
        isBanned: banMap.has(key),
        banReason: ''
      });
    }
  }

  // Also include ops, whitelisted, or banned players not yet in known_players
  for (const extra of [...ops, ...whitelist, ...banned]) {
    if (!extra || !extra.name) continue;
    const key = String(extra.name).toLowerCase();
    if (!mergedMap.has(key)) {
      mergedMap.set(key, {
        username: extra.name,
        uuid: extra.uuid || '',
        online: false,
        firstSeen: extra.created || null,
        lastSeen: null,
        isOp: opSet.has(key),
        isWhitelisted: wlSet.has(key),
        isBanned: banMap.has(key),
        banReason: banMap.has(key) ? banMap.get(key).reason || '' : ''
      });
    }
  }

  const allPlayers = Array.from(mergedMap.values()).sort((a, b) => {
    if (a.online !== b.online) return a.online ? -1 : 1;
    return a.username.localeCompare(b.username, undefined, { sensitivity: 'base' });
  });

  return {
    serverOnline: serverRow.status === 'running',
    onlinePlayers: allPlayers.filter((p) => p.online),
    allPlayers,
    ops,
    whitelist,
    banned
  };
}

async function executePlayerAction(serverRow, { action, username, reason = '' }, actor, ip = '') {
  if (typeof username !== 'string' || !/^[A-Za-z0-9_.\-]{1,32}$/.test(username.trim())) {
    throw new Error('Invalid Minecraft username.');
  }
  const cleanUser = username.trim();
  const cleanReason = String(reason || '')
    .replace(/[\r\n\0;|&]/g, ' ')
    .trim()
    .slice(0, 120);

  const isRunning = serverRow.status === 'running';

  if (action === 'kick') {
    if (!isRunning) {
      throw new Error('Server must be running to kick an online player.');
    }
    const cmd = cleanReason ? `kick ${cleanUser} ${cleanReason}` : `kick ${cleanUser}`;
    await sendServerCommand(serverRow, cmd);
  } else if (action === 'ban') {
    if (!isRunning) {
      throw new Error('Start the server to execute player ban via the Minecraft server engine.');
    }
    const cmd = cleanReason ? `ban ${cleanUser} ${cleanReason}` : `ban ${cleanUser}`;
    await sendServerCommand(serverRow, cmd);
  } else if (action === 'unban') {
    if (isRunning) {
      await sendServerCommand(serverRow, `pardon ${cleanUser}`);
    } else {
      const banned = readJsonArraySafe(serverRow.server_dir, 'banned-players.json');
      const filtered = banned.filter(
        (b) => String(b.name || '').toLowerCase() !== cleanUser.toLowerCase()
      );
      writeJsonArraySafe(serverRow.server_dir, 'banned-players.json', filtered);
    }
  } else if (action === 'whitelist_add') {
    if (!isRunning) {
      throw new Error('Start the server so Minecraft can resolve UUID and add player to whitelist.');
    }
    await sendServerCommand(serverRow, `whitelist add ${cleanUser}`);
  } else if (action === 'whitelist_remove') {
    if (isRunning) {
      await sendServerCommand(serverRow, `whitelist remove ${cleanUser}`);
    } else {
      const wl = readJsonArraySafe(serverRow.server_dir, 'whitelist.json');
      const filtered = wl.filter(
        (w) => String(w.name || '').toLowerCase() !== cleanUser.toLowerCase()
      );
      writeJsonArraySafe(serverRow.server_dir, 'whitelist.json', filtered);
    }
  } else if (action === 'op') {
    if (!isRunning) {
      throw new Error('Start the server to grant OP permissions.');
    }
    await sendServerCommand(serverRow, `op ${cleanUser}`);
  } else if (action === 'deop') {
    if (isRunning) {
      await sendServerCommand(serverRow, `deop ${cleanUser}`);
    } else {
      const ops = readJsonArraySafe(serverRow.server_dir, 'ops.json');
      const filtered = ops.filter(
        (o) => String(o.name || '').toLowerCase() !== cleanUser.toLowerCase()
      );
      writeJsonArraySafe(serverRow.server_dir, 'ops.json', filtered);
    }
  } else {
    throw new Error(`Unsupported player action "${action}".`);
  }

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: `player.${action}`,
    target: `${serverRow.name}: ${cleanUser}`,
    ip,
    result: 'success'
  });

  return { action, username: cleanUser };
}

module.exports = {
  getPlayersOverview,
  executePlayerAction
};
