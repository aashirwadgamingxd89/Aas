'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const tar = require('tar');
const config = require('../config/config');
const { getDb, getSetting } = require('../database/database');
const { resolveSafePath, sanitizeFilename } = require('../utils/pathGuard');
const { getDirectorySize } = require('../daemon/monitor');
const { sendServerCommand, writeServerProperties } = require('./serverManager');
const { createNotification } = require('./notificationService');
const { recordAudit } = require('./auditService');

// serverId -> string ('creating' | 'restoring')
const serverBackupLocks = new Map();
let panelIoRef = null;

function bindSocketIo(io) {
  panelIoRef = io;
}

function listBackups(serverRow) {
  const db = getDb();
  return db
    .prepare('SELECT * FROM backups WHERE server_id = ? ORDER BY id DESC')
    .all(serverRow.id);
}

async function createServerBackup(serverRow, customName = '', actor, ip = '') {
  if (serverBackupLocks.has(serverRow.id)) {
    throw new Error(
      `A backup operation (${serverBackupLocks.get(serverRow.id)}) is already in progress for this server.`
    );
  }

  const db = getDb();
  const maxBackups = Math.max(1, parseInt(getSetting('max_backups_per_server', '10'), 10) || 10);
  const existingCount = db
    .prepare("SELECT COUNT(*) AS count FROM backups WHERE server_id = ? AND status = 'completed'")
    .get(serverRow.id).count;

  if (existingCount >= maxBackups) {
    throw new Error(
      `Backup limit reached (${maxBackups} backups max per server). Delete an older backup first.`
    );
  }

  if (!fs.existsSync(serverRow.server_dir)) {
    throw new Error('Server directory does not exist.');
  }

  const label =
    customName && customName.trim()
      ? customName.trim().slice(0, 64)
      : `Backup ${new Date().toISOString().replace('T', ' ').slice(0, 19)}`;

  const backupFolder = resolveSafePath(config.backupsDir, serverRow.uuid);
  fs.mkdirSync(backupFolder, { recursive: true });

  const fileSlug = sanitizeFilename(
    `backup-${serverRow.id}-${Date.now()}.tar.gz`
  );
  const fullArchivePath = resolveSafePath(backupFolder, fileSlug);

  const insert = db
    .prepare(`
      INSERT INTO backups (server_id, name, file_path, size, status, created_at)
      VALUES (?, ?, ?, 0, 'creating', datetime('now'))
    `)
    .run(serverRow.id, label, fullArchivePath);
  const backupId = insert.lastInsertRowid;

  serverBackupLocks.set(serverRow.id, 'creating');

  const emitProgress = (payload) => {
    if (panelIoRef) {
      panelIoRef.to(`server:${serverRow.uuid}`).emit('backup:update', {
        backupId,
        uuid: serverRow.uuid,
        ...payload
      });
    }
  };

  // Run backup asynchronously while streaming real progress updates
  (async () => {
    const wasRunning = serverRow.status === 'running';
    try {
      emitProgress({ status: 'creating', percent: 10, message: 'Calculating server data size...' });
      const totalDir = await getDirectorySize(serverRow.server_dir, true);

      if (wasRunning) {
        try {
          await sendServerCommand(serverRow, 'save-off');
          await sendServerCommand(serverRow, 'save-all');
          await new Promise((r) => setTimeout(r, 800));
        } catch (_) {}
      }

      emitProgress({ status: 'creating', percent: 25, message: 'Compressing server files (.tar.gz)...' });

      const entries = (await fsp.readdir(serverRow.server_dir)).filter(
        (name) => !name.startsWith('.world_import_tmp_')
      );

      let processedBytes = 0;
      let lastReport = 0;

      await tar.c(
        {
          gzip: true,
          file: fullArchivePath,
          cwd: serverRow.server_dir,
          portable: true,
          noMtime: false,
          onReadEntry: (entry) => {
            processedBytes += entry.size || 0;
            const now = Date.now();
            if (totalDir.bytes > 0 && now - lastReport > 350) {
              lastReport = now;
              const pct = Math.min(95, Math.max(25, Math.round((processedBytes / totalDir.bytes) * 95)));
              emitProgress({
                status: 'creating',
                percent: pct,
                message: `Archiving (${(processedBytes / 1048576).toFixed(1)} / ${totalDir.mb.toFixed(1)} MB)...`
              });
            }
          }
        },
        entries.length > 0 ? entries : ['.']
      );

      const stat = await fsp.stat(fullArchivePath);
      db.prepare("UPDATE backups SET size = ?, status = 'completed' WHERE id = ?").run(
        stat.size,
        backupId
      );

      emitProgress({
        status: 'completed',
        percent: 100,
        size: stat.size,
        message: `Backup "${label}" completed (${(stat.size / 1048576).toFixed(2)} MB).`
      });

      createNotification({
        userId: serverRow.owner_id,
        serverId: serverRow.id,
        type: 'success',
        title: 'Backup Completed',
        message: `Backup "${label}" (${(stat.size / 1048576).toFixed(2)} MB) created for "${serverRow.name}".`
      });

      recordAudit({
        userId: actor.id,
        username: actor.username,
        action: 'backup.create',
        target: `${serverRow.name}: ${label}`,
        ip,
        result: 'success',
        details: { backupId, sizeBytes: stat.size }
      });
    } catch (err) {
      db.prepare("UPDATE backups SET status = 'failed' WHERE id = ?").run(backupId);
      try {
        if (fs.existsSync(fullArchivePath)) await fsp.unlink(fullArchivePath);
      } catch (_) {}

      emitProgress({
        status: 'failed',
        percent: 0,
        message: `Backup failed: ${err.message}`
      });

      createNotification({
        userId: serverRow.owner_id,
        serverId: serverRow.id,
        type: 'danger',
        title: 'Backup Failed',
        message: `Backup "${label}" failed on "${serverRow.name}": ${err.message}`
      });
    } finally {
      if (wasRunning) {
        try {
          await sendServerCommand(serverRow, 'save-on');
        } catch (_) {}
      }
      serverBackupLocks.delete(serverRow.id);
    }
  })();

  return db.prepare('SELECT * FROM backups WHERE id = ?').get(backupId);
}

async function restoreServerBackup(serverRow, backupId, actor, ip = '') {
  if (serverBackupLocks.has(serverRow.id)) {
    throw new Error('Another backup or restore operation is currently active for this server.');
  }

  if (
    serverRow.status === 'running' ||
    serverRow.status === 'starting' ||
    serverRow.status === 'stopping'
  ) {
    throw new Error('Stop the server before restoring a backup.');
  }

  const db = getDb();
  const backup = db
    .prepare('SELECT * FROM backups WHERE id = ? AND server_id = ?')
    .get(backupId, serverRow.id);

  if (!backup || backup.status !== 'completed') {
    throw new Error('Selected backup is not available for restore.');
  }

  const safeBackupPath = resolveSafePath(
    path.join(config.backupsDir, serverRow.uuid),
    path.basename(backup.file_path)
  );
  if (!fs.existsSync(safeBackupPath)) {
    throw new Error('Backup archive file is missing on storage.');
  }

  serverBackupLocks.set(serverRow.id, 'restoring');
  try {
    // Inspect archive entries first for path traversal and total size safety
    let totalBytes = 0;
    const limitBytes = (serverRow.disk_limit || 2048) * 1048576;

    await tar.t({
      file: safeBackupPath,
      onReadEntry: (entry) => {
        const p = entry.path.replace(/\\/g, '/');
        if (p.startsWith('/') || p.includes('../') || p === '..') {
          throw new Error(`Unsafe path in backup archive blocked: ${entry.path}`);
        }
        if (entry.type === 'SymbolicLink' || entry.type === 'Link') {
          throw new Error(`Symbolic/hard link inside backup blocked: ${entry.path}`);
        }
        totalBytes += entry.size || 0;
        if (totalBytes > limitBytes) {
          throw new Error('Backup uncompressed size exceeds server disk allocation.');
        }
      }
    });

    // Clear current server files safely before extracting backup
    fs.mkdirSync(serverRow.server_dir, { recursive: true });
    const currentItems = await fsp.readdir(serverRow.server_dir);
    for (const item of currentItems) {
      const full = resolveSafePath(serverRow.server_dir, item);
      await fsp.rm(full, { recursive: true, force: true });
    }

    await tar.x({
      file: safeBackupPath,
      cwd: serverRow.server_dir,
      filter: (p, stat) => {
        const norm = p.replace(/\\/g, '/');
        if (norm.startsWith('/') || norm.includes('../')) return false;
        if (stat.type === 'SymbolicLink' || stat.type === 'Link') return false;
        return true;
      }
    });

    // Ensure assigned server-port remains enforced in server.properties
    writeServerProperties(serverRow, {});

    createNotification({
      userId: serverRow.owner_id,
      serverId: serverRow.id,
      type: 'success',
      title: 'Backup Restored',
      message: `Restored backup "${backup.name}" onto "${serverRow.name}".`
    });

    recordAudit({
      userId: actor.id,
      username: actor.username,
      action: 'backup.restore',
      target: `${serverRow.name}: ${backup.name}`,
      ip,
      result: 'success',
      details: { backupId: backup.id }
    });

    return backup;
  } finally {
    serverBackupLocks.delete(serverRow.id);
  }
}

async function deleteServerBackup(serverRow, backupId, actor, ip = '') {
  if (serverBackupLocks.has(serverRow.id)) {
    throw new Error('Wait for the active backup operation to finish before deleting backups.');
  }

  const db = getDb();
  const backup = db
    .prepare('SELECT * FROM backups WHERE id = ? AND server_id = ?')
    .get(backupId, serverRow.id);
  if (!backup) {
    throw new Error('Backup not found.');
  }

  try {
    const safeBackupPath = resolveSafePath(
      path.join(config.backupsDir, serverRow.uuid),
      path.basename(backup.file_path)
    );
    if (fs.existsSync(safeBackupPath)) {
      await fsp.unlink(safeBackupPath);
    }
  } catch (_) {}

  db.prepare('DELETE FROM backups WHERE id = ?').run(backup.id);

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'backup.delete',
    target: `${serverRow.name}: ${backup.name}`,
    ip,
    result: 'success'
  });

  return backup;
}

function getBackupDownloadPath(serverRow, backupId) {
  const db = getDb();
  const backup = db
    .prepare('SELECT * FROM backups WHERE id = ? AND server_id = ?')
    .get(backupId, serverRow.id);
  if (!backup || backup.status !== 'completed') {
    throw new Error('Backup is not available for download.');
  }
  const safePath = resolveSafePath(
    path.join(config.backupsDir, serverRow.uuid),
    path.basename(backup.file_path)
  );
  if (!fs.existsSync(safePath)) {
    throw new Error('Backup file not found on disk.');
  }
  return {
    backup,
    safePath,
    downloadName: `${sanitizeFilename(serverRow.name)}-${path.basename(safePath)}`
  };
}

module.exports = {
  bindSocketIo,
  listBackups,
  createServerBackup,
  restoreServerBackup,
  deleteServerBackup,
  getBackupDownloadPath
};
