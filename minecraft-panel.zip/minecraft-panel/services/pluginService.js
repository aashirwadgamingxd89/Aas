'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const AdmZip = require('adm-zip');
const { getDb } = require('../database/database');
const { resolveSafePath, sanitizeFilename } = require('../utils/pathGuard');
const { assertDiskQuotaAvailable } = require('./fileService');
const { createNotification } = require('./notificationService');
const { recordAudit } = require('./auditService');

const USER_AGENT = 'AashirwadGamerzz-Panel/1.0.0 (Minecraft-Server-Management-Panel)';

const TRUSTED_PLUGIN_HOSTS = new Set([
  'cdn.modrinth.com',
  'hangarcdn.papermc.io',
  'hangar.papermc.io'
]);

function getPluginFolderName(serverRow) {
  const type = String(serverRow.server_type || 'paper').toLowerCase();
  if (type === 'fabric' || type === 'forge') return 'mods';
  return 'plugins';
}

function parseSimpleYamlMeta(yamlText) {
  const meta = {};
  const lines = String(yamlText || '').split(/\r?\n/);
  for (const line of lines) {
    const m = line.match(/^([a-zA-Z0-9_-]+)\s*:\s*(.+)$/);
    if (m) {
      const key = m[1].toLowerCase();
      let val = m[2].trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (val.startsWith('[') && val.endsWith(']')) {
        val = val
          .slice(1, -1)
          .split(',')
          .map((s) => s.trim().replace(/^['"]|['"]$/g, ''))
          .filter(Boolean)
          .join(', ');
      }
      meta[key] = val;
    }
  }
  return meta;
}

function inspectPluginJar(jarPath) {
  const fallbackName = path.basename(jarPath, '.jar');
  try {
    const zip = new AdmZip(jarPath);
    const yamlCandidates = ['paper-plugin.yml', 'plugin.yml', 'bungee.yml'];
    for (const candidate of yamlCandidates) {
      const entry = zip.getEntry(candidate);
      if (entry) {
        const parsed = parseSimpleYamlMeta(entry.getData().toString('utf8'));
        return {
          name: parsed.name || fallbackName,
          version: parsed.version || '1.0.0',
          author: parsed.author || parsed.authors || 'Unknown',
          description: parsed.description || ''
        };
      }
    }

    const fabricEntry = zip.getEntry('fabric.mod.json');
    if (fabricEntry) {
      const json = JSON.parse(fabricEntry.getData().toString('utf8'));
      const authors = Array.isArray(json.authors)
        ? json.authors.map((a) => (typeof a === 'string' ? a : a.name)).filter(Boolean).join(', ')
        : 'Unknown';
      return {
        name: json.name || json.id || fallbackName,
        version: json.version || '1.0.0',
        author: authors || 'Unknown',
        description: json.description || ''
      };
    }
  } catch (_) {}

  return {
    name: fallbackName,
    version: 'unknown',
    author: 'Unknown',
    description: ''
  };
}

async function listInstalledPlugins(serverRow) {
  const db = getDb();
  const folder = getPluginFolderName(serverRow);
  const pluginsDir = resolveSafePath(serverRow.server_dir, folder);
  fs.mkdirSync(pluginsDir, { recursive: true });

  const dirents = await fsp.readdir(pluginsDir, { withFileTypes: true });
  const jarFilesOnDisk = new Set();

  const existingByFile = new Map(
    db
      .prepare('SELECT * FROM plugins WHERE server_id = ?')
      .all(serverRow.id)
      .map((r) => [r.file_name, r])
  );

  for (const d of dirents) {
    if (!d.isFile() || !d.name.toLowerCase().endsWith('.jar')) continue;
    jarFilesOnDisk.add(d.name);
    const fullJar = path.join(pluginsDir, d.name);
    const stat = await fsp.stat(fullJar);
    const existing = existingByFile.get(d.name);

    if (!existing || existing.file_size !== stat.size) {
      const meta = inspectPluginJar(fullJar);
      db.prepare(`
        INSERT INTO plugins (
          server_id, plugin_name, version, author, description,
          file_name, file_size, source, installed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        ON CONFLICT(server_id, file_name) DO UPDATE SET
          plugin_name = excluded.plugin_name,
          version = excluded.version,
          author = excluded.author,
          description = excluded.description,
          file_size = excluded.file_size
      `).run(
        serverRow.id,
        meta.name,
        meta.version,
        meta.author,
        meta.description,
        d.name,
        stat.size,
        existing ? existing.source : 'local'
      );
    }
  }

  // Prune DB records whose JAR no longer exists on disk
  for (const fileName of existingByFile.keys()) {
    if (!jarFilesOnDisk.has(fileName)) {
      db.prepare('DELETE FROM plugins WHERE server_id = ? AND file_name = ?').run(
        serverRow.id,
        fileName
      );
    }
  }

  return db
    .prepare('SELECT * FROM plugins WHERE server_id = ? ORDER BY plugin_name COLLATE NOCASE ASC')
    .all(serverRow.id);
}

function getCompatibleLoadersForServer(serverRow) {
  const type = String(serverRow.server_type || 'paper').toLowerCase();
  if (type === 'paper') return ['paper', 'spigot', 'bukkit'];
  if (type === 'purpur') return ['purpur', 'paper', 'spigot', 'bukkit'];
  if (type === 'fabric') return ['fabric'];
  if (type === 'forge') return ['forge'];
  return [];
}

async function searchMarketplace(serverRow, { query = '', source = 'all', limit = 20, offset = 0 } = {}) {
  const loaders = getCompatibleLoadersForServer(serverRow);
  if (loaders.length === 0) {
    return {
      compatible: false,
      reason:
        'Vanilla Minecraft does not load plugins or mods natively. Switch server software to Paper, Purpur, Fabric, or Forge in Server Settings to use plugins/mods.',
      items: []
    };
  }

  const results = [];
  const cleanSource = String(source || 'all').toLowerCase();
  const safeLimit = Math.min(30, Math.max(1, parseInt(limit, 10) || 20));
  const safeOffset = Math.max(0, parseInt(offset, 10) || 0);

  if (cleanSource === 'all' || cleanSource === 'modrinth') {
    const loaderFacet = loaders.map((l) => `"categories:${l}"`).join(',');
    const projectType =
      serverRow.server_type === 'fabric' || serverRow.server_type === 'forge'
        ? '"project_type:mod"'
        : '"project_type:plugin","project_type:mod"';
    const facets = `[[${loaderFacet}],[${projectType}]]`;
    const url =
      `https://api.modrinth.com/v2/search?query=${encodeURIComponent(query.trim())}` +
      `&facets=${encodeURIComponent(facets)}` +
      `&limit=${safeLimit}&offset=${safeOffset}`;

    const res = await fetch(url, {
      headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
      signal: AbortSignal.timeout(15000)
    });
    if (res.ok) {
      const data = await res.json();
      for (const hit of data.hits || []) {
        const versionsList = Array.isArray(hit.versions) ? hit.versions : [];
        results.push({
          id: hit.project_id,
          slug: hit.slug,
          name: hit.title,
          author: hit.author || 'Unknown',
          description: hit.description || '',
          iconUrl: hit.icon_url || '',
          downloads: hit.downloads || 0,
          follows: hit.follows || 0,
          source: 'MODRINTH',
          categories: hit.categories || [],
          latestMcVersion: versionsList.length ? versionsList[versionsList.length - 1] : '',
          exactMcMatch: versionsList.includes(serverRow.mc_version)
        });
      }
    }
  }

  if (
    (cleanSource === 'all' || cleanSource === 'hangar') &&
    (serverRow.server_type === 'paper' || serverRow.server_type === 'purpur')
  ) {
    const hangarLimit = cleanSource === 'hangar' ? safeLimit : Math.min(8, safeLimit);
    const hUrl =
      `https://hangar.papermc.io/api/v1/projects?platform=PAPER&limit=${hangarLimit}&offset=${safeOffset}` +
      (query.trim() ? `&q=${encodeURIComponent(query.trim())}` : '');
    try {
      const hRes = await fetch(hUrl, {
        headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
        signal: AbortSignal.timeout(12000)
      });
      if (hRes.ok) {
        const hData = await hRes.json();
        for (const p of hData.result || []) {
          const ns = p.namespace || {};
          results.push({
            id: `${ns.owner}/${ns.slug}`,
            slug: ns.slug,
            name: p.name,
            author: ns.owner || 'Unknown',
            description: p.description || '',
            iconUrl: p.avatarUrl || '',
            downloads: (p.stats && p.stats.downloads) || 0,
            follows: (p.stats && p.stats.stars) || 0,
            source: 'HANGAR',
            categories: p.category ? [p.category] : ['paper'],
            latestMcVersion: '',
            exactMcMatch: true
          });
        }
      }
    } catch (_) {}
  }

  return {
    compatible: true,
    items: results
  };
}

function assertTrustedPluginUrl(urlStr) {
  const parsed = new URL(urlStr);
  if (parsed.protocol !== 'https:' || !TRUSTED_PLUGIN_HOSTS.has(parsed.hostname)) {
    throw new Error(`Untrusted plugin download host rejected: ${parsed.hostname}`);
  }
  return parsed.toString();
}

async function installMarketplacePlugin(serverRow, { projectId, source = 'MODRINTH' }, actor, ip = '') {
  const loaders = getCompatibleLoadersForServer(serverRow);
  if (loaders.length === 0) {
    throw new Error(
      'Vanilla servers cannot load plugins/mods. Change server type to Paper, Purpur, Fabric, or Forge first.'
    );
  }

  const src = String(source || 'MODRINTH').toUpperCase();
  let downloadUrl = null;
  let fileName = null;
  let expectedSha512 = null;
  let expectedSha256 = null;
  let pluginTitle = projectId;
  let pluginAuthor = 'Unknown';
  let pluginDescription = '';
  let versionNumber = '1.0.0';

  if (src === 'MODRINTH') {
    const projRes = await fetch(
      `https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}`,
      { headers: { 'User-Agent': USER_AGENT }, signal: AbortSignal.timeout(15000) }
    );
    if (!projRes.ok) {
      throw new Error('Plugin project not found on Modrinth.');
    }
    const proj = await projRes.json();
    pluginTitle = proj.title || proj.slug || projectId;
    pluginDescription = proj.description || '';

    const loadersParam = JSON.stringify(loaders);
    const verRes = await fetch(
      `https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}/version?loaders=${encodeURIComponent(
        loadersParam
      )}`,
      { headers: { 'User-Agent': USER_AGENT }, signal: AbortSignal.timeout(15000) }
    );
    if (!verRes.ok) {
      throw new Error('Failed to fetch Modrinth versions for this plugin.');
    }
    const versions = await verRes.json();
    if (!Array.isArray(versions) || versions.length === 0) {
      throw new Error(
        `No release of "${pluginTitle}" is compatible with ${serverRow.server_type.toUpperCase()}.`
      );
    }

    // Prefer exact Minecraft version match; otherwise match same major.minor family for Bukkit/Paper plugins
    const mcMajorMinor = serverRow.mc_version.split('.').slice(0, 2).join('.');
    let chosen = versions.find(
      (v) => Array.isArray(v.game_versions) && v.game_versions.includes(serverRow.mc_version)
    );
    if (!chosen && (serverRow.server_type === 'paper' || serverRow.server_type === 'purpur')) {
      chosen = versions.find(
        (v) =>
          Array.isArray(v.game_versions) &&
          v.game_versions.some((gv) => gv === mcMajorMinor || gv.startsWith(mcMajorMinor + '.'))
      );
    }
    if (!chosen) {
      throw new Error(
        `No compatible version of "${pluginTitle}" found for Minecraft ${serverRow.mc_version} (${serverRow.server_type.toUpperCase()}).`
      );
    }

    const fileObj = (chosen.files || []).find((f) => f.primary) || (chosen.files || [])[0];
    if (!fileObj || !fileObj.url) {
      throw new Error('Selected Modrinth plugin version has no downloadable JAR file.');
    }

    downloadUrl = assertTrustedPluginUrl(fileObj.url);
    fileName = sanitizeFilename(fileObj.filename || `${proj.slug}-${chosen.version_number}.jar`);
    expectedSha512 = fileObj.hashes && fileObj.hashes.sha512 ? fileObj.hashes.sha512 : null;
    versionNumber = chosen.version_number || '1.0.0';
  } else if (src === 'HANGAR') {
    // projectId is "owner/slug"
    const parts = String(projectId).split('/');
    if (parts.length !== 2) {
      throw new Error('Invalid Hangar project identifier.');
    }
    const [owner, slug] = parts;
    pluginAuthor = owner;
    pluginTitle = slug;

    const verRes = await fetch(
      `https://hangar.papermc.io/api/v1/projects/${encodeURIComponent(owner)}/${encodeURIComponent(
        slug
      )}/versions?platform=PAPER&limit=10`,
      { headers: { 'User-Agent': USER_AGENT }, signal: AbortSignal.timeout(15000) }
    );
    if (!verRes.ok) {
      throw new Error('Unable to query Hangar versions for this plugin.');
    }
    const verData = await verRes.json();
    const list = verData.result || [];
    const chosen = list.find((v) => v.downloads && v.downloads.PAPER && v.downloads.PAPER.downloadUrl);
    if (!chosen) {
      throw new Error(
        `Plugin "${slug}" links to an external URL or has no direct verified Hangar JAR download.`
      );
    }
    const dlInfo = chosen.downloads.PAPER;
    downloadUrl = assertTrustedPluginUrl(dlInfo.downloadUrl);
    fileName = sanitizeFilename(
      (dlInfo.fileInfo && dlInfo.fileInfo.name) || `${slug}-${chosen.name}.jar`
    );
    expectedSha256 = dlInfo.fileInfo && dlInfo.fileInfo.sha256Hash ? dlInfo.fileInfo.sha256Hash : null;
    versionNumber = chosen.name || '1.0.0';
  } else {
    throw new Error(`Unsupported marketplace source "${source}".`);
  }

  if (!fileName.toLowerCase().endsWith('.jar')) {
    throw new Error('Marketplace artifact is not a valid .jar plugin.');
  }

  const dlRes = await fetch(downloadUrl, {
    headers: { 'User-Agent': USER_AGENT },
    signal: AbortSignal.timeout(60000)
  });
  if (!dlRes.ok) {
    throw new Error(`Plugin download failed with HTTP ${dlRes.status}.`);
  }

  const buf = Buffer.from(await dlRes.arrayBuffer());
  if (buf.length < 256) {
    throw new Error('Downloaded plugin file is invalid or empty.');
  }

  await assertDiskQuotaAvailable(serverRow, buf.length);

  if (expectedSha512) {
    const actual512 = crypto.createHash('sha512').update(buf).digest('hex');
    if (actual512.toLowerCase() !== expectedSha512.toLowerCase()) {
      throw new Error('Plugin SHA-512 integrity verification failed.');
    }
  }
  if (expectedSha256) {
    const actual256 = crypto.createHash('sha256').update(buf).digest('hex');
    if (actual256.toLowerCase() !== expectedSha256.toLowerCase()) {
      throw new Error('Plugin SHA-256 integrity verification failed.');
    }
  }

  const folder = getPluginFolderName(serverRow);
  const pluginsDir = resolveSafePath(serverRow.server_dir, folder);
  fs.mkdirSync(pluginsDir, { recursive: true });
  const targetJar = resolveSafePath(pluginsDir, fileName);
  await fsp.writeFile(targetJar, buf);

  const jarMeta = inspectPluginJar(targetJar);
  const finalName = jarMeta.name !== path.basename(fileName, '.jar') ? jarMeta.name : pluginTitle;
  const finalAuthor = jarMeta.author !== 'Unknown' ? jarMeta.author : pluginAuthor;
  const finalDesc = jarMeta.description || pluginDescription;

  const db = getDb();
  db.prepare(`
    INSERT INTO plugins (
      server_id, plugin_name, version, author, description,
      file_name, file_size, source, installed_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(server_id, file_name) DO UPDATE SET
      plugin_name = excluded.plugin_name,
      version = excluded.version,
      author = excluded.author,
      description = excluded.description,
      file_size = excluded.file_size,
      source = excluded.source,
      installed_at = datetime('now')
  `).run(
    serverRow.id,
    finalName,
    versionNumber,
    finalAuthor,
    finalDesc,
    fileName,
    buf.length,
    src.toLowerCase()
  );

  createNotification({
    userId: serverRow.owner_id,
    serverId: serverRow.id,
    type: 'success',
    title: 'Plugin Installed',
    message: `Installed "${finalName}" (${versionNumber}) on "${serverRow.name}". Restart server to load.`
  });

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'plugin.install',
    target: `${serverRow.name}: ${finalName} (${fileName})`,
    ip,
    result: 'success',
    details: { source: src, version: versionNumber }
  });

  return {
    pluginName: finalName,
    version: versionNumber,
    fileName,
    size: buf.length
  };
}

async function deleteInstalledPlugin(serverRow, pluginId, actor, ip = '') {
  if (
    serverRow.status === 'running' ||
    serverRow.status === 'starting' ||
    serverRow.status === 'stopping'
  ) {
    throw new Error('Stop the server before deleting installed plugins to avoid file locks or corruption.');
  }

  const db = getDb();
  const plugin = db
    .prepare('SELECT * FROM plugins WHERE id = ? AND server_id = ?')
    .get(pluginId, serverRow.id);
  if (!plugin) {
    throw new Error('Plugin record not found.');
  }

  const folder = getPluginFolderName(serverRow);
  const fullJar = resolveSafePath(path.join(serverRow.server_dir, folder), plugin.file_name);
  if (fs.existsSync(fullJar)) {
    await fsp.unlink(fullJar);
  }

  db.prepare('DELETE FROM plugins WHERE id = ?').run(plugin.id);

  recordAudit({
    userId: actor.id,
    username: actor.username,
    action: 'plugin.delete',
    target: `${serverRow.name}: ${plugin.plugin_name} (${plugin.file_name})`,
    ip,
    result: 'success'
  });

  return plugin;
}

module.exports = {
  getPluginFolderName,
  inspectPluginJar,
  listInstalledPlugins,
  searchMarketplace,
  installMarketplacePlugin,
  deleteInstalledPlugin
};
