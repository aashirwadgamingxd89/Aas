'use strict';

const { getDb, getSetting } = require('../database/database');

// uuid -> latest telemetry object
const liveTelemetryMap = new Map();
// serverId -> timestamp (ms) of last DB sample write
const lastRecordedMap = new Map();

const DB_SAMPLE_INTERVAL_MS = 15000;

function recordLiveTelemetry(serverRow, stats) {
  if (!serverRow || !stats) return;
  const enriched = {
    ...stats,
    uuid: serverRow.uuid,
    serverId: serverRow.id,
    updatedAt: new Date().toISOString()
  };
  liveTelemetryMap.set(serverRow.uuid, enriched);

  const now = Date.now();
  const prev = lastRecordedMap.get(serverRow.id) || 0;
  if (now - prev >= DB_SAMPLE_INTERVAL_MS) {
    lastRecordedMap.set(serverRow.id, now);
    try {
      const db = getDb();
      db.prepare(`
        INSERT INTO server_metrics (
          server_id, cpu_usage, ram_usage, disk_usage,
          player_count, tps, uptime, recorded_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
      `).run(
        serverRow.id,
        Number(stats.cpuPercent || 0),
        Number(stats.memoryMb || 0),
        Number(stats.diskMb || 0),
        Number(stats.playerCount || 0),
        stats.tps != null ? Number(stats.tps) : null,
        Number(stats.uptimeSeconds || 0)
      );
    } catch (_) {}
  }
}

function getLatestTelemetry(uuid) {
  return liveTelemetryMap.get(uuid) || null;
}

function removeServerTelemetry(uuid, serverId) {
  if (uuid) liveTelemetryMap.delete(uuid);
  if (serverId) lastRecordedMap.delete(serverId);
}

function getHistoricalMetrics(serverId, limit = 30) {
  const db = getDb();
  const rows = db
    .prepare(`
      SELECT cpu_usage, ram_usage, disk_usage, player_count, tps, uptime, recorded_at
      FROM server_metrics
      WHERE server_id = ?
      ORDER BY id DESC
      LIMIT ?
    `)
    .all(serverId, Math.min(120, Math.max(5, limit)));
  return rows.reverse();
}

function pruneOldMetrics() {
  try {
    const db = getDb();
    const hours = Math.max(1, parseInt(getSetting('metrics_retention_hours', '24'), 10) || 24);
    db.prepare(`
      DELETE FROM server_metrics
      WHERE recorded_at < datetime('now', ?)
    `).run(`-${hours} hours`);
  } catch (_) {}
}

module.exports = {
  recordLiveTelemetry,
  getLatestTelemetry,
  removeServerTelemetry,
  getHistoricalMetrics,
  pruneOldMetrics
};
