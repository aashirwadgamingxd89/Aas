'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const AdmZip = require('adm-zip');
const {
  resolveSafePath,
  sanitizeFilename,
  getRelativeServerPath,
  validateAndExtractZip
} = require('../utils/pathGuard');
const { getDirectorySize } = require('../daemon/monitor');

const EDITABLE_EXTENSIONS = new Set([
  '.properties',
  '.yml',
  '.yaml',
  '.json',
  '.txt',
  '.cfg',
  '.conf',
  '.toml',
  '.sh',
  '.log',
  '.md',
  '.xml',
  '.ini',
  '.mcmeta',
  '.csv'
]);

const MAX_EDIT_FILE_BYTES = 2 * 1024 * 1024; // 2 MB

function formatModeToPermissions(mode) {
  const chars = ['r', 'w', 'x'];
  let out = '';
  for (let i = 8; i >= 0; i--) {
    out += mode & (1 << i) ? chars[(8 - i) % 3] : '-';
  }
  const octal = (mode & 0o777).toString(8).padStart(3, '0');
  return `${out} (${octal})`;
}

function classifyFileType(name, isDir) {
  if (isDir) return 'directory';
  const ext = path.extname(name).toLowerCase();
  if (ext === '.jar') return 'java-archive';
  if (ext === '.zip' || ext === '.gz' || ext === '.tar') return 'archive';
  if (EDITABLE_EXTENSIONS.has(ext)) return ext.slice(1) || 'text';
  if (['.png', '.jpg', '.jpeg', '.webp', '.gif', '.ico'].includes(ext)) return 'image';
  if (['.dat', '.mca', '.mcr'].includes(ext)) return 'minecraft-data';
  return ext ? ext.slice(1) : 'file';
}

function isEditableFile(name, size) {
  if (size > MAX_EDIT_FILE_BYTES) return false;
  const ext = path.extname(name).toLowerCase();
  const base = path.basename(name).toLowerCase();
  if (EDITABLE_EXTENSIONS.has(ext)) return true;
  if (['eula.txt', 'ops.json', 'whitelist.json', 'banned-players.json', 'banned-ips.json'].includes(base)) {
    return true;
  }
  return false;
}

async function assertDiskQuotaAvailable(serverRow, additionalBytes = 0) {
  const usage = await getDirectorySize(serverRow.server_dir, true);
  const limitBytes = (serverRow.disk_limit || 2048) * 1048576;
  if (usage.bytes + additionalBytes > limitBytes) {
    throw new Error(
      `Server disk limit exceeded (${usage.mb.toFixed(1)} MB used of ${serverRow.disk_limit} MB allocated).`
    );
  }
}

async function listServerDirectory(serverRow, relDir = '') {
  fs.mkdirSync(serverRow.server_dir, { recursive: true });
  const targetDir = resolveSafePath(serverRow.server_dir, relDir);
  const stat = await fsp.stat(targetDir);
  if (!stat.isDirectory()) {
    throw new Error('Requested path is not a directory.');
  }

  const dirents = await fsp.readdir(targetDir, { withFileTypes: true });
  const items = [];

  for (const d of dirents) {
    if (d.isSymbolicLink()) continue;
    const itemPath = path.join(targetDir, d.name);
    let itemStat;
    try {
      itemStat = await fsp.lstat(itemPath);
    } catch (_) {
      continue;
    }

    const isDir = itemStat.isDirectory();
    const relPath = getRelativeServerPath(serverRow.server_dir, itemPath);
    items.push({
      name: d.name,
      path: relPath,
      isDirectory: isDir,
      size: isDir ? 0 : itemStat.size,
      modifiedAt: itemStat.mtime.toISOString(),
      permissions: formatModeToPermissions(itemStat.mode),
      type: classifyFileType(d.name, isDir),
      editable: !isDir && isEditableFile(d.name, itemStat.size),
      isZip: !isDir && d.name.toLowerCase().endsWith('.zip')
    });
  }

  items.sort((a, b) => {
    if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1;
    return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
  });

  const cleanRel = getRelativeServerPath(serverRow.server_dir, targetDir);
  return {
    currentPath: cleanRel,
    items
  };
}

async function readTextFile(serverRow, relPath) {
  const fullPath = resolveSafePath(serverRow.server_dir, relPath);
  const stat = await fsp.stat(fullPath);
  if (stat.isDirectory()) {
    throw new Error('Cannot open a directory in the text editor.');
  }
  if (stat.size > MAX_EDIT_FILE_BYTES) {
    throw new Error('File exceeds 2 MB editor limit. Download the file to edit locally.');
  }

  const buffer = await fsp.readFile(fullPath);
  // Check for binary NUL bytes in first 8 KB
  const sampleLen = Math.min(buffer.length, 8192);
  for (let i = 0; i < sampleLen; i++) {
    if (buffer[i] === 0) {
      throw new Error('Binary files cannot be edited in the text editor.');
    }
  }

  return {
    name: path.basename(fullPath),
    path: getRelativeServerPath(serverRow.server_dir, fullPath),
    size: stat.size,
    modifiedAt: stat.mtime.toISOString(),
    extension: path.extname(fullPath).toLowerCase(),
    content: buffer.toString('utf8')
  };
}

async function writeTextFile(serverRow, relPath, content) {
  const fullPath = resolveSafePath(serverRow.server_dir, relPath);
  const strContent = String(content ?? '');
  const newBytes = Buffer.byteLength(strContent, 'utf8');
  await assertDiskQuotaAvailable(serverRow, newBytes);

  await fsp.mkdir(path.dirname(fullPath), { recursive: true });
  await fsp.writeFile(fullPath, strContent, 'utf8');
  const stat = await fsp.stat(fullPath);
  return {
    name: path.basename(fullPath),
    path: getRelativeServerPath(serverRow.server_dir, fullPath),
    size: stat.size,
    modifiedAt: stat.mtime.toISOString()
  };
}

async function createDirectory(serverRow, parentRelPath, folderName) {
  const cleanName = sanitizeFilename(folderName);
  const parentDir = resolveSafePath(serverRow.server_dir, parentRelPath);
  const newDir = resolveSafePath(parentDir, cleanName);
  if (fs.existsSync(newDir)) {
    throw new Error(`"${cleanName}" already exists.`);
  }
  await fsp.mkdir(newDir, { recursive: false });
  return { path: getRelativeServerPath(serverRow.server_dir, newDir) };
}

async function createEmptyFile(serverRow, parentRelPath, fileName, initialContent = '') {
  const cleanName = sanitizeFilename(fileName);
  const parentDir = resolveSafePath(serverRow.server_dir, parentRelPath);
  const newFile = resolveSafePath(parentDir, cleanName);
  if (fs.existsSync(newFile)) {
    throw new Error(`"${cleanName}" already exists.`);
  }
  await assertDiskQuotaAvailable(serverRow, Buffer.byteLength(initialContent, 'utf8'));
  await fsp.writeFile(newFile, String(initialContent), 'utf8');
  return { path: getRelativeServerPath(serverRow.server_dir, newFile) };
}

async function renameItem(serverRow, relPath, newName) {
  const cleanNewName = sanitizeFilename(newName);
  const sourcePath = resolveSafePath(serverRow.server_dir, relPath);
  if (sourcePath === fs.realpathSync(serverRow.server_dir)) {
    throw new Error('Cannot rename server root directory.');
  }
  const destPath = resolveSafePath(path.dirname(sourcePath), cleanNewName);
  if (fs.existsSync(destPath)) {
    throw new Error(`An item named "${cleanNewName}" already exists.`);
  }
  await fsp.rename(sourcePath, destPath);
  return { path: getRelativeServerPath(serverRow.server_dir, destPath) };
}

async function deleteItems(serverRow, relPaths) {
  if (!Array.isArray(relPaths) || relPaths.length === 0) {
    throw new Error('No files or folders selected for deletion.');
  }
  const rootReal = fs.realpathSync(serverRow.server_dir);
  let deleted = 0;

  for (const rel of relPaths) {
    const target = resolveSafePath(serverRow.server_dir, rel);
    if (target === rootReal) {
      throw new Error('Deleting the root server directory is forbidden.');
    }
    if (fs.existsSync(target)) {
      await fsp.rm(target, { recursive: true, force: true });
      deleted++;
    }
  }
  return { deleted };
}

async function zipSelectedItems(serverRow, relPaths, currentDirRel = '', archiveName = null) {
  if (!Array.isArray(relPaths) || relPaths.length === 0) {
    throw new Error('Select at least one file or directory to compress.');
  }
  await assertDiskQuotaAvailable(serverRow, 1024 * 1024);

  const zip = new AdmZip();
  const rootReal = fs.realpathSync(serverRow.server_dir);

  for (const rel of relPaths) {
    const target = resolveSafePath(serverRow.server_dir, rel);
    if (target === rootReal || !fs.existsSync(target)) continue;
    const st = await fsp.lstat(target);
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) {
      zip.addLocalFolder(target, path.basename(target));
    } else if (st.isFile()) {
      zip.addLocalFile(target);
    }
  }

  const destFolder = resolveSafePath(serverRow.server_dir, currentDirRel);
  const baseZipName = sanitizeFilename(
    archiveName && archiveName.trim()
      ? archiveName.trim().endsWith('.zip')
        ? archiveName.trim()
        : `${archiveName.trim()}.zip`
      : `archive-${new Date().toISOString().replace(/[:.]/g, '-')}.zip`
  );
  const outZipPath = resolveSafePath(destFolder, baseZipName);
  zip.writeZip(outZipPath);

  const st = await fsp.stat(outZipPath);
  return {
    name: baseZipName,
    path: getRelativeServerPath(serverRow.server_dir, outZipPath),
    size: st.size
  };
}

function buildDownloadBufferForMultiple(serverRow, relPaths) {
  const zip = new AdmZip();
  const rootReal = fs.realpathSync(serverRow.server_dir);
  for (const rel of relPaths) {
    const target = resolveSafePath(serverRow.server_dir, rel);
    if (target === rootReal || !fs.existsSync(target)) continue;
    const st = fs.lstatSync(target);
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) {
      zip.addLocalFolder(target, path.basename(target));
    } else if (st.isFile()) {
      zip.addLocalFile(target);
    }
  }
  return zip.toBuffer();
}

async function extractZipInServer(serverRow, relZipPath, targetRelDir = '') {
  const zipFullPath = resolveSafePath(serverRow.server_dir, relZipPath);
  if (!fs.existsSync(zipFullPath) || !zipFullPath.toLowerCase().endsWith('.zip')) {
    throw new Error('Selected file is not a valid .zip archive.');
  }
  const destDir = resolveSafePath(
    serverRow.server_dir,
    targetRelDir || path.dirname(getRelativeServerPath(serverRow.server_dir, zipFullPath))
  );
  const usage = await getDirectorySize(serverRow.server_dir, true);
  const remainingBytes = Math.max(0, (serverRow.disk_limit || 2048) * 1048576 - usage.bytes);
  if (remainingBytes < 65536) {
    throw new Error('Disk allocation is full; cannot extract archive.');
  }

  const zip = new AdmZip(zipFullPath);
  return validateAndExtractZip(zip, destDir, remainingBytes);
}

module.exports = {
  listServerDirectory,
  readTextFile,
  writeTextFile,
  createDirectory,
  createEmptyFile,
  renameItem,
  deleteItems,
  zipSelectedItems,
  buildDownloadBufferForMultiple,
  extractZipInServer,
  assertDiskQuotaAvailable
};
