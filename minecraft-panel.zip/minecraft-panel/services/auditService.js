'use strict';

const { getDb } = require('../database/database');
const { logger } = require('../config/logger');

function recordAudit({
  userId = null,
  username = 'system',
  action,
  target = '',
  ip = '',
  result = 'success',
  details = ''
}) {
  try {
    const db = getDb();
    db.prepare(`
      INSERT INTO audit_logs (user_id, username, action, target, ip_address, result, details, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(
      userId || null,
      String(username || 'system'),
      String(action),
      String(target || ''),
      String(ip || ''),
      String(result || 'success'),
      typeof details === 'object' ? JSON.stringify(details) : String(details || '')
    );
    logger.info('audit', `${username} -> ${action} (${result})`, { target, ip });
  } catch (err) {
    logger.error('audit', 'Failed to write audit log', { error: err.message });
  }
}

function listAuditLogs({ limit = 100, offset = 0, search = '' } = {}) {
  const db = getDb();
  const safeLimit = Math.min(500, Math.max(1, parseInt(limit, 10) || 100));
  const safeOffset = Math.max(0, parseInt(offset, 10) || 0);

  if (search && search.trim()) {
    const q = `%${search.trim()}%`;
    const rows = db
      .prepare(`
        SELECT * FROM audit_logs
        WHERE username LIKE ? OR action LIKE ? OR target LIKE ? OR details LIKE ?
        ORDER BY id DESC
        LIMIT ? OFFSET ?
      `)
      .all(q, q, q, q, safeLimit, safeOffset);
    const total = db
      .prepare(`
        SELECT COUNT(*) AS count FROM audit_logs
        WHERE username LIKE ? OR action LIKE ? OR target LIKE ? OR details LIKE ?
      `)
      .get(q, q, q, q).count;
    return { rows, total };
  }

  const rows = db
    .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?')
    .all(safeLimit, safeOffset);
  const total = db.prepare('SELECT COUNT(*) AS count FROM audit_logs').get().count;
  return { rows, total };
}

module.exports = {
  recordAudit,
  listAuditLogs
};
