'use strict';

const config = require('../../config/config');
const { getHostMetrics } = require('../../utils/systemCheck');

const DEFAULT_SETTINGS = {
  // General
  panel_name: 'AashirwadGamerzz Minecraft Server Management Panel',
  panel_short_name: 'AashirwadGamerzz',
  panel_subtitle: 'GAME HOSTING',
  panel_description: 'Production Minecraft Server Management Control Panel',
  logo_url: '/images/logo.svg',
  favicon_url: '/images/logo.svg',
  footer_text: '© 2026 AashirwadGamerzz — Minecraft Server Management Panel',
  default_language: 'en',

  // Appearance
  primary_color: '#ffffff',
  accent_color: '#7c3aed',
  dark_theme: 'true',
  sidebar_compact: 'false',

  // System
  session_lifetime_hours: String(config.sessionLifetimeHours),
  max_upload_mb: String(config.maxUploadMb),
  max_backups_per_server: String(config.maxBackupsPerServer),
  metrics_retention_hours: String(config.metricsRetentionHours),
  maintenance_mode: 'false',
  allow_registration: 'true',

  // Security
  login_rate_limit_max: '10',
  login_rate_limit_window_min: '15',
  api_rate_limit_max: '180'
};

function initializeDefaults(db) {
  const insertSetting = db.prepare(`
    INSERT OR IGNORE INTO panel_settings (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
  `);

  const seedSettingsTx = db.transaction(() => {
    for (const [key, val] of Object.entries(DEFAULT_SETTINGS)) {
      insertSetting.run(key, String(val));
    }
  });
  seedSettingsTx();

  // Ensure the real local Daemon node record exists and reflects actual host hardware/container capacity
  const metrics = getHostMetrics(config.serversDir);
  const ramCapMb = Math.max(256, metrics.memory.totalMb || 1024);
  const diskCapMb = Math.max(512, metrics.disk.totalMb || 10240);
  const cpuCap = Math.max(1, metrics.cpuCores || 1);

  const localNode = db.prepare('SELECT * FROM nodes WHERE is_local = 1 LIMIT 1').get();
  if (!localNode) {
    db.prepare(`
      INSERT INTO nodes (
        name, host, public_host, port, status,
        ram_capacity, disk_capacity, cpu_capacity,
        daemon_version, auth_token, is_local
      ) VALUES (?, ?, ?, ?, 'offline', ?, ?, ?, ?, ?, 1)
    `).run(
      'Local Daemon Node',
      config.daemonHost,
      config.daemonPublicAddress,
      config.daemonPort,
      ramCapMb,
      diskCapMb,
      cpuCap,
      config.daemonVersion,
      config.nodeAuthSecret
    );
  } else {
    db.prepare(`
      UPDATE nodes
      SET host = ?,
          port = ?,
          ram_capacity = ?,
          disk_capacity = ?,
          cpu_capacity = ?,
          daemon_version = ?,
          auth_token = ?
      WHERE id = ?
    `).run(
      config.daemonHost,
      config.daemonPort,
      ramCapMb,
      diskCapMb,
      cpuCap,
      config.daemonVersion,
      config.nodeAuthSecret,
      localNode.id
    );
  }
}

module.exports = {
  DEFAULT_SETTINGS,
  initializeDefaults
};
