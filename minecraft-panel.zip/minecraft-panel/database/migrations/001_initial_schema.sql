-- 001_initial_schema.sql
-- AashirwadGamerzz Minecraft Server Management Panel v1.0.0

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
  avatar_color TEXT NOT NULL DEFAULT '#7c3aed',
  avatar_url TEXT NOT NULL DEFAULT '',
  max_servers INTEGER NOT NULL DEFAULT 5,
  max_ram_mb INTEGER NOT NULL DEFAULT 4096,
  max_disk_mb INTEGER NOT NULL DEFAULT 10240,
  max_cpu_cores REAL NOT NULL DEFAULT 4.0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS password_resets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  sess TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS nodes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  host TEXT NOT NULL,
  public_host TEXT NOT NULL DEFAULT '127.0.0.1',
  port INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'offline' CHECK (status IN ('online', 'offline')),
  ram_capacity INTEGER NOT NULL DEFAULT 1024,
  disk_capacity INTEGER NOT NULL DEFAULT 10240,
  cpu_capacity REAL NOT NULL DEFAULT 1.0,
  daemon_version TEXT NOT NULL DEFAULT 'v1.0.0',
  auth_token TEXT NOT NULL,
  is_local INTEGER NOT NULL DEFAULT 0,
  last_seen TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS servers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  uuid TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  server_type TEXT NOT NULL DEFAULT 'paper',
  mc_version TEXT NOT NULL DEFAULT '1.21.4',
  java_version TEXT NOT NULL DEFAULT '21',
  ram_limit INTEGER NOT NULL DEFAULT 1024,
  cpu_limit REAL NOT NULL DEFAULT 1.0,
  disk_limit INTEGER NOT NULL DEFAULT 2048,
  port INTEGER NOT NULL DEFAULT 25565,
  node_id INTEGER NOT NULL REFERENCES nodes(id) ON DELETE RESTRICT,
  server_dir TEXT NOT NULL,
  startup_command TEXT NOT NULL,
  motd TEXT NOT NULL DEFAULT 'A Minecraft Server',
  max_players INTEGER NOT NULL DEFAULT 20,
  suspended INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'offline',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_started TEXT
);

CREATE INDEX IF NOT EXISTS idx_servers_owner ON servers(owner_id);
CREATE INDEX IF NOT EXISTS idx_servers_node ON servers(node_id);

CREATE TABLE IF NOT EXISTS server_metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  cpu_usage REAL NOT NULL DEFAULT 0,
  ram_usage REAL NOT NULL DEFAULT 0,
  disk_usage REAL NOT NULL DEFAULT 0,
  player_count INTEGER NOT NULL DEFAULT 0,
  tps REAL,
  uptime INTEGER NOT NULL DEFAULT 0,
  recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_metrics_server_time ON server_metrics(server_id, recorded_at);

CREATE TABLE IF NOT EXISTS backups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  size INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'creating',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_backups_server ON backups(server_id);

CREATE TABLE IF NOT EXISTS plugins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  plugin_name TEXT NOT NULL,
  version TEXT NOT NULL DEFAULT 'unknown',
  author TEXT NOT NULL DEFAULT 'Unknown',
  description TEXT NOT NULL DEFAULT '',
  file_name TEXT NOT NULL,
  file_size INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT 'upload',
  installed_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(server_id, file_name)
);

CREATE INDEX IF NOT EXISTS idx_plugins_server ON plugins(server_id);

CREATE TABLE IF NOT EXISTS worlds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  world_name TEXT NOT NULL,
  directory TEXT NOT NULL,
  size INTEGER NOT NULL DEFAULT 0,
  type TEXT NOT NULL DEFAULT 'overworld',
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(server_id, directory)
);

CREATE INDEX IF NOT EXISTS idx_worlds_server ON worlds(server_id);

CREATE TABLE IF NOT EXISTS known_players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  uuid TEXT NOT NULL DEFAULT '',
  username TEXT NOT NULL,
  first_seen TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(server_id, username)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  server_id INTEGER REFERENCES servers(id) ON DELETE SET NULL,
  type TEXT NOT NULL DEFAULT 'info',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  username TEXT NOT NULL DEFAULT 'system',
  action TEXT NOT NULL,
  target TEXT NOT NULL DEFAULT '',
  ip_address TEXT NOT NULL DEFAULT '',
  result TEXT NOT NULL DEFAULT 'success',
  details TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS panel_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
