'use strict';

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('../config/config');
const { logger } = require('../config/logger');
const { initializeDefaults, DEFAULT_SETTINGS } = require('./seeds/initDefaults');

let dbInstance = null;

function runMigrations(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const migrationsDir = path.join(__dirname, 'migrations');
  if (!fs.existsSync(migrationsDir)) return;

  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  const checkMigration = db.prepare('SELECT version FROM schema_migrations WHERE version = ?');
  const recordMigration = db.prepare('INSERT INTO schema_migrations (version) VALUES (?)');

  for (const file of files) {
    const existing = checkMigration.get(file);
    if (!existing) {
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
      const migrateTx = db.transaction(() => {
        db.exec(sql);
        recordMigration.run(file);
      });
      migrateTx();
      logger.info('database', `Applied migration: ${file}`);
    }
  }
}

function getDb() {
  if (dbInstance) return dbInstance;

  fs.mkdirSync(path.dirname(config.databasePath), { recursive: true });
  dbInstance = new Database(config.databasePath);
  dbInstance.pragma('journal_mode = WAL');
  dbInstance.pragma('foreign_keys = ON');
  dbInstance.pragma('synchronous = NORMAL');
  dbInstance.pragma('busy_timeout = 5000');

  runMigrations(dbInstance);
  initializeDefaults(dbInstance);

  return dbInstance;
}

function getPanelSettings() {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM panel_settings').all();
  const settings = { ...DEFAULT_SETTINGS };
  for (const r of rows) {
    settings[r.key] = r.value;
  }
  return settings;
}

function getSetting(key, fallback = null) {
  const db = getDb();
  const row = db.prepare('SELECT value FROM panel_settings WHERE key = ?').get(key);
  if (row) return row.value;
  return Object.prototype.hasOwnProperty.call(DEFAULT_SETTINGS, key)
    ? DEFAULT_SETTINGS[key]
    : fallback;
}

function updatePanelSettings(updates) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO panel_settings (key, value, updated_at)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')
  `);
  const tx = db.transaction((entries) => {
    for (const [k, v] of entries) {
      stmt.run(k, String(v));
    }
  });
  tx(Object.entries(updates));
}

function closeDb() {
  if (dbInstance) {
    try {
      dbInstance.pragma('wal_checkpoint(TRUNCATE)');
      dbInstance.close();
      logger.info('database', 'SQLite connection closed cleanly.');
    } catch (err) {
      logger.error('database', 'Error closing SQLite database', { error: err.message });
    } finally {
      dbInstance = null;
    }
  }
}

module.exports = {
  getDb,
  getPanelSettings,
  getSetting,
  updatePanelSettings,
  closeDb
};
