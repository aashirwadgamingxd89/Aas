'use strict';

const fs = require('fs');
const path = require('path');

class PathSecurityError extends Error {
  constructor(message) {
    super(message);
    this.name = 'PathSecurityError';
    this.statusCode = 403;
  }
}

function assertNoNullBytes(input) {
  if (typeof input !== 'string' || input.includes('\0')) {
    throw new PathSecurityError('Invalid path characters detected.');
  }
}

function sanitizeFilename(name) {
  assertNoNullBytes(name);
  const trimmed = name.trim();
  if (!trimmed || trimmed === '.' || trimmed === '..') {
    throw new PathSecurityError('Invalid file or directory name.');
  }
  if (/[/\\<>:"|?*\x00-\x1f]/.test(trimmed)) {
    throw new PathSecurityError('Filename contains disallowed characters.');
  }
  if (trimmed.length > 200) {
    throw new PathSecurityError('Filename exceeds maximum length (200 chars).');
  }
  return trimmed;
}

/**
 * Strictly resolves `userRelPath` inside `baseDir`, preventing path traversal
 * and symlink escapes outside `baseDir`.
 */
function resolveSafePath(baseDir, userRelPath = '') {
  assertNoNullBytes(baseDir);
  const rel = userRelPath == null ? '' : String(userRelPath);
  assertNoNullBytes(rel);

  const realBase = fs.existsSync(baseDir) ? fs.realpathSync(baseDir) : path.resolve(baseDir);
  const normalizedRel = rel.replace(/\\/g, '/').replace(/^\/+/, '');
  const resolved = path.resolve(realBase, normalizedRel);

  if (resolved !== realBase && !resolved.startsWith(realBase + path.sep)) {
    throw new PathSecurityError('Access outside assigned server directory is forbidden.');
  }

  // Walk up to nearest existing ancestor and verify realpath does not escape via symlink
  let cursor = resolved;
  while (cursor && cursor.length >= realBase.length) {
    if (fs.existsSync(cursor)) {
      const realCursor = fs.realpathSync(cursor);
      if (realCursor !== realBase && !realCursor.startsWith(realBase + path.sep)) {
        throw new PathSecurityError('Symbolic link escape outside server directory blocked.');
      }
      break;
    }
    const parent = path.dirname(cursor);
    if (parent === cursor) break;
    cursor = parent;
  }

  return resolved;
}

function getRelativeServerPath(baseDir, targetPath) {
  const realBase = fs.existsSync(baseDir) ? fs.realpathSync(baseDir) : path.resolve(baseDir);
  const absTarget = path.resolve(targetPath);
  const rel = path.relative(realBase, absTarget);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    throw new PathSecurityError('Path escapes server root.');
  }
  return rel.split(path.sep).join('/');
}

/**
 * Inspects an AdmZip instance before extracting to prevent Zip Slip,
 * symlink attacks, malicious filenames, and zip bombs.
 */
function validateAndExtractZip(admZip, destDir, maxTotalBytes = 1024 * 1024 * 1024) {
  const entries = admZip.getEntries();
  if (entries.length > 15000) {
    throw new PathSecurityError('Archive contains too many entries (max 15,000).');
  }

  const realDest = fs.existsSync(destDir) ? fs.realpathSync(destDir) : path.resolve(destDir);
  let totalUncompressed = 0;

  for (const entry of entries) {
    const rawName = entry.entryName;
    assertNoNullBytes(rawName);
    const normalized = rawName.replace(/\\/g, '/');

    if (
      normalized.startsWith('/') ||
      normalized.includes('../') ||
      normalized.endsWith('/..') ||
      normalized === '..'
    ) {
      throw new PathSecurityError(`Unsafe archive entry blocked: ${rawName}`);
    }

    const parts = normalized.split('/').filter(Boolean);
    for (const part of parts) {
      sanitizeFilename(part);
    }

    // Reject Unix symlink attributes in zip external file attributes ((attr >>> 16) & 0o170000 === 0o120000)
    const unixMode = (entry.header.attr >>> 16) & 0o170000;
    if (unixMode === 0o120000) {
      throw new PathSecurityError(`Symbolic link inside archive is disallowed: ${rawName}`);
    }

    const outPath = path.resolve(realDest, normalized);
    if (outPath !== realDest && !outPath.startsWith(realDest + path.sep)) {
      throw new PathSecurityError(`Zip Slip path traversal blocked: ${rawName}`);
    }

    totalUncompressed += Math.max(0, entry.header.size || 0);
    if (totalUncompressed > maxTotalBytes) {
      throw new PathSecurityError(
        `Archive uncompressed size exceeds safety limit (${Math.round(maxTotalBytes / 1048576)} MB).`
      );
    }
  }

  // Safe controlled extraction entry-by-entry
  let extractedFiles = 0;
  for (const entry of entries) {
    const normalized = entry.entryName.replace(/\\/g, '/');
    const outPath = resolveSafePath(realDest, normalized);
    if (entry.isDirectory) {
      fs.mkdirSync(outPath, { recursive: true });
    } else {
      fs.mkdirSync(path.dirname(outPath), { recursive: true });
      const data = entry.getData();
      fs.writeFileSync(outPath, data);
      extractedFiles++;
    }
  }

  return { entriesCount: entries.length, extractedFiles, totalBytes: totalUncompressed };
}

module.exports = {
  PathSecurityError,
  sanitizeFilename,
  resolveSafePath,
  getRelativeServerPath,
  validateAndExtractZip
};
