'use strict';

function isValidUsername(username) {
  return typeof username === 'string' && /^[a-zA-Z0-9_.-]{3,32}$/.test(username.trim());
}

function isValidEmail(email) {
  return (
    typeof email === 'string' &&
    email.length <= 160 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())
  );
}

function isValidPassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 128;
}

function isValidServerName(name) {
  return typeof name === 'string' && /^[\w\s().\-#'!]{2,64}$/.test(name.trim());
}

function isValidPort(port) {
  const n = Number(port);
  return Number.isInteger(n) && n >= 1024 && n <= 65535;
}

function isValidHost(host) {
  if (typeof host !== 'string') return false;
  const h = host.trim();
  if (!h || h.length > 253) return false;
  return /^[a-zA-Z0-9.-]+$/.test(h) || /^\[[0-9a-fA-F:]+\]$/.test(h);
}

/**
 * Validates and normalizes a Java startup command string into safe arguments,
 * clamping memory flags to the assigned server RAM limit and blocking shell/agent injection.
 */
function parseAndValidateStartupCommand(commandStr, maxRamMb, defaultJar = 'server.jar') {
  const raw = typeof commandStr === 'string' && commandStr.trim()
    ? commandStr.trim()
    : `java -Xms${Math.min(512, maxRamMb)}M -Xmx${maxRamMb}M -jar ${defaultJar} nogui`;

  if (/[;|&`$><\r\n\0\\]/.test(raw)) {
    throw new Error('Startup command contains forbidden shell metacharacters.');
  }

  const tokens = raw.split(/\s+/).filter(Boolean);
  if (tokens.length < 3) {
    throw new Error('Startup command must specify java, -jar, and a target JAR file.');
  }

  // First token must be 'java' (actual binary is resolved securely by the daemon)
  if (tokens[0] !== 'java') {
    throw new Error('Startup command must start with "java".');
  }

  // Disallow dangerous JVM flags that load arbitrary native code or execute external commands
  const forbiddenPrefixes = [
    '-javaagent:',
    '-agentlib:',
    '-agentpath:',
    '-XX:OnOutOfMemoryError',
    '-XX:OnError',
    '-Xbootclasspath',
    '--patch-module'
  ];

  const args = [];
  let hasXmx = false;
  let hasXms = false;
  let jarIndex = -1;

  for (let i = 1; i < tokens.length; i++) {
    const tok = tokens[i];
    for (const bad of forbiddenPrefixes) {
      if (tok.toLowerCase().startsWith(bad.toLowerCase())) {
        throw new Error(`JVM argument "${bad}" is restricted by security policy.`);
      }
    }

    const xmxMatch = tok.match(/^-Xmx(\d+)([mMgG])$/);
    if (xmxMatch) {
      let mb = parseInt(xmxMatch[1], 10) * (xmxMatch[2].toLowerCase() === 'g' ? 1024 : 1);
      mb = Math.max(128, Math.min(mb, maxRamMb));
      args.push(`-Xmx${mb}M`);
      hasXmx = true;
      continue;
    }

    const xmsMatch = tok.match(/^-Xms(\d+)([mMgG])$/);
    if (xmsMatch) {
      let mb = parseInt(xmsMatch[1], 10) * (xmsMatch[2].toLowerCase() === 'g' ? 1024 : 1);
      mb = Math.max(128, Math.min(mb, maxRamMb));
      args.push(`-Xms${mb}M`);
      hasXms = true;
      continue;
    }

    if (tok === '-jar') {
      jarIndex = args.length;
      args.push('-jar');
      const jarFile = tokens[i + 1];
      if (!jarFile || !/^[a-zA-Z0-9_.-]+\.jar$/.test(jarFile) || jarFile.includes('..')) {
        throw new Error('Invalid JAR filename in startup command.');
      }
      args.push(jarFile);
      i++;
      continue;
    }

    if (!/^[a-zA-Z0-9_.,:=+\-/]+$/.test(tok)) {
      throw new Error(`Disallowed token in startup command: ${tok}`);
    }
    args.push(tok);
  }

  if (jarIndex === -1) {
    args.push('-jar', defaultJar, 'nogui');
  }
  if (!hasXmx) {
    args.unshift(`-Xmx${maxRamMb}M`);
  }
  if (!hasXms) {
    args.unshift(`-Xms${Math.min(512, maxRamMb)}M`);
  }
  if (!args.includes('nogui') && !args.includes('--nogui')) {
    args.push('nogui');
  }

  return {
    normalizedCommand: `java ${args.join(' ')}`,
    args
  };
}

function sanitizeConsoleCommand(cmd) {
  if (typeof cmd !== 'string') {
    throw new Error('Command must be a string.');
  }
  const clean = cmd.replace(/[\r\n\0]/g, '').trim().replace(/^\/+/, '');
  if (!clean) {
    throw new Error('Command cannot be empty.');
  }
  if (clean.length > 512) {
    throw new Error('Command exceeds maximum length (512 chars).');
  }
  return clean;
}

module.exports = {
  isValidUsername,
  isValidEmail,
  isValidPassword,
  isValidServerName,
  isValidPort,
  isValidHost,
  parseAndValidateStartupCommand,
  sanitizeConsoleCommand
};
