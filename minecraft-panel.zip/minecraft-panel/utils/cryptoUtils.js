'use strict';

const crypto = require('crypto');
const config = require('../config/config');

function safeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function generateToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

function generateUUID() {
  return crypto.randomUUID();
}

function createCsrfToken(sessionId, nonce) {
  const actualNonce = nonce || crypto.randomBytes(16).toString('hex');
  const hmac = crypto
    .createHmac('sha256', config.csrfSecret)
    .update(`${sessionId}:${actualNonce}`)
    .digest('hex');
  return `${actualNonce}.${hmac}`;
}

function verifyCsrfToken(sessionId, token) {
  if (!sessionId || typeof token !== 'string' || !token.includes('.')) {
    return false;
  }
  const [nonce, providedHmac] = token.split('.', 2);
  if (!nonce || !providedHmac) return false;
  const expected = createCsrfToken(sessionId, nonce).split('.')[1];
  return safeCompare(providedHmac, expected);
}

module.exports = {
  safeCompare,
  generateToken,
  generateUUID,
  createCsrfToken,
  verifyCsrfToken
};
