'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const config = require('../config/config');

let cachedJavaInfo = null;
let cachedJavaAt = 0;

function detectEnvironmentCapabilities() {
  const isProot = Boolean(
    process.env.PROOT_TMP_DIR ||
      process.env.PROOT_NO_SECCOMP ||
      (() => {
        try {
          if (fs.existsSync('/proc/self/status')) {
            const st = fs.readFileSync('/proc/self/status', 'utf8');
            const tracerMatch = st.match(/^TracerPid:\s*(\d+)/m);
            if (tracerMatch && parseInt(tracerMatch[1], 10) > 0) {
              // Often non-zero under ptrace-based proot
              return true;
            }
          }
        } catch (_) {}
        return false;
      })()
  );

  let isContainer = false;
  let containerRuntime = 'standard-posix';
  try {
    if (fs.existsSync('/.dockerenv')) {
      isContainer = true;
      containerRuntime = 'docker';
    } else if (fs.existsSync('/run/.containerenv')) {
      isContainer = true;
      containerRuntime = 'podman';
    } else if (fs.existsSync('/proc/1/cgroup')) {
      const cg = fs.readFileSync('/proc/1/cgroup', 'utf8');
      if (/docker|lxc|kubepods|containerd/i.test(cg)) {
        isContainer = true;
        containerRuntime = 'cgroup-container';
      }
    }
  } catch (_) {}

  if (isProot) {
    containerRuntime = 'proot';
    isContainer = true;
  }

  let procFsAvailable = false;
  try {
    procFsAvailable = fs.existsSync('/proc/stat') && fs.existsSync('/proc/self/stat');
  } catch (_) {
    procFsAvailable = false;
  }

  let statfsAvailable = typeof fs.statfsSync === 'function';
  if (statfsAvailable) {
    try {
      fs.statfsSync(config.rootDir);
    } catch (_) {
      statfsAvailable = false;
    }
  }

  const nodeVersion = process.versions.node;
  const nodeMajor = parseInt(nodeVersion.split('.')[0], 10);

  return {
    platform: os.platform(),
    arch: os.arch(),
    release: os.release(),
    hostname: os.hostname(),
    isContainer,
    isProot,
    containerRuntime,
    isRoot: typeof process.getuid === 'function' ? process.getuid() === 0 : false,
    procFsAvailable,
    statfsAvailable,
    nodeVersion,
    nodeCompatible: nodeMajor >= 18
  };
}

function probeJavaBinary(binPath) {
  try {
    const out = execFileSync(binPath, ['-version'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 5000
    });
    return out;
  } catch (err) {
    // `java -version` prints to stderr; execFileSync only throws on non-zero exit
    if (err && (err.stderr || err.stdout)) {
      const combined = `${err.stdout || ''}\n${err.stderr || ''}`.trim();
      if (err.status === 0 && combined) return combined;
    }
    return null;
  }
}

function getJavaStderrVersion(binPath) {
  try {
    const { spawnSync } = require('child_process');
    const res = spawnSync(binPath, ['-version'], {
      encoding: 'utf8',
      timeout: 5000
    });
    if (res.error || res.status !== 0) return null;
    const raw = `${res.stderr || ''}\n${res.stdout || ''}`.trim();
    if (!raw) return null;

    let major = 0;
    const quoted = raw.match(/version\s+"([^"]+)"/i);
    const versionStr = quoted ? quoted[1] : raw.split('\n')[0];
    if (versionStr.startsWith('1.')) {
      major = parseInt(versionStr.split('.')[1], 10) || 0;
    } else {
      major = parseInt(versionStr.split(/[.\-+_]/)[0], 10) || 0;
    }

    return {
      available: true,
      binary: binPath,
      version: versionStr,
      major,
      isJava21Plus: major >= 21,
      rawOutput: raw.split('\n').slice(0, 3).join(' | ')
    };
  } catch (_) {
    return null;
  }
}

function detectJavaRuntime(forceRefresh = false) {
  if (!forceRefresh && cachedJavaInfo && Date.now() - cachedJavaAt < 30000) {
    return cachedJavaInfo;
  }

  const candidates = [];
  if (config.javaBinOverride) {
    candidates.push(config.javaBinOverride);
  }
  if (process.env.JAVA_HOME) {
    candidates.push(path.join(process.env.JAVA_HOME, 'bin', 'java'));
  }

  // Scan standard JVM installation directories so Java 21+ is preferred even if older Java is default
  const jvmDirs = ['/usr/lib/jvm', '/opt/java', path.join(os.homedir(), '.sdkman/candidates/java')];
  for (const dir of jvmDirs) {
    try {
      if (fs.existsSync(dir)) {
        const entries = fs.readdirSync(dir);
        for (const entry of entries) {
          const candidate = path.join(dir, entry, 'bin', 'java');
          if (fs.existsSync(candidate)) {
            candidates.push(candidate);
          }
        }
      }
    } catch (_) {}
  }

  candidates.push('java');

  const detectedList = [];
  const seen = new Set();
  for (const bin of candidates) {
    if (seen.has(bin)) continue;
    seen.add(bin);
    const info = getJavaStderrVersion(bin);
    if (info) {
      detectedList.push(info);
    }
  }

  // Prefer highest major version >= 21
  detectedList.sort((a, b) => b.major - a.major);

  if (detectedList.length > 0) {
    const best = detectedList[0];
    best.allRuntimes = detectedList.map((r) => ({
      binary: r.binary,
      version: r.version,
      major: r.major
    }));
    cachedJavaInfo = best;
  } else {
    cachedJavaInfo = {
      available: false,
      binary: null,
      version: null,
      major: 0,
      isJava21Plus: false,
      rawOutput: 'Java runtime not found. Install OpenJDK 21+ or set JAVA_BIN in .env.',
      allRuntimes: []
    };
  }

  cachedJavaAt = Date.now();
  return cachedJavaInfo;
}

// CPU usage measurement across samples using os.cpus()
let lastCpuSnapshot = null;

function sampleCpuPercent() {
  const cpus = os.cpus();
  if (!cpus || cpus.length === 0) return 0;

  let idle = 0;
  let total = 0;
  for (const cpu of cpus) {
    for (const type of Object.keys(cpu.times)) {
      total += cpu.times[type];
    }
    idle += cpu.times.idle;
  }

  if (!lastCpuSnapshot) {
    lastCpuSnapshot = { idle, total };
    return 0;
  }

  const idleDiff = idle - lastCpuSnapshot.idle;
  const totalDiff = total - lastCpuSnapshot.total;
  lastCpuSnapshot = { idle, total };

  if (totalDiff <= 0) return 0;
  const pct = ((totalDiff - idleDiff) / totalDiff) * 100;
  return Math.max(0, Math.min(100, Number(pct.toFixed(1))));
}

function getContainerAwareMemory() {
  let totalBytes = os.totalmem();
  let freeBytes = os.freemem();
  let usedBytes = Math.max(0, totalBytes - freeBytes);

  // Check cgroup v2 memory limits when inside container
  try {
    if (fs.existsSync('/sys/fs/cgroup/memory.max') && fs.existsSync('/sys/fs/cgroup/memory.current')) {
      const maxStr = fs.readFileSync('/sys/fs/cgroup/memory.max', 'utf8').trim();
      const curStr = fs.readFileSync('/sys/fs/cgroup/memory.current', 'utf8').trim();
      if (maxStr !== 'max') {
        const cgMax = parseInt(maxStr, 10);
        const cgCur = parseInt(curStr, 10);
        if (Number.isFinite(cgMax) && cgMax > 0 && cgMax < totalBytes) {
          totalBytes = cgMax;
          usedBytes = Math.min(cgMax, Math.max(0, cgCur));
          freeBytes = Math.max(0, totalBytes - usedBytes);
        }
      }
    }
  } catch (_) {}

  return {
    totalBytes,
    usedBytes,
    freeBytes,
    totalMb: Math.round(totalBytes / 1048576),
    usedMb: Math.round(usedBytes / 1048576),
    freeMb: Math.round(freeBytes / 1048576),
    percent: totalBytes > 0 ? Number(((usedBytes / totalBytes) * 100).toFixed(1)) : 0
  };
}

function getDiskSpace(targetDir = config.serversDir) {
  try {
    if (typeof fs.statfsSync === 'function') {
      const st = fs.statfsSync(targetDir);
      const blockSize = st.bsize || st.frsize || 4096;
      const totalBytes = st.blocks * blockSize;
      const availBytes = st.bavail * blockSize;
      const usedBytes = Math.max(0, totalBytes - st.bfree * blockSize);
      return {
        available: true,
        totalBytes,
        usedBytes,
        freeBytes: availBytes,
        totalMb: Math.round(totalBytes / 1048576),
        usedMb: Math.round(usedBytes / 1048576),
        freeMb: Math.round(availBytes / 1048576),
        percent: totalBytes > 0 ? Number(((usedBytes / totalBytes) * 100).toFixed(1)) : 0
      };
    }
  } catch (err) {
    return {
      available: false,
      error: err.message,
      totalBytes: 0,
      usedBytes: 0,
      freeBytes: 0,
      totalMb: 0,
      usedMb: 0,
      freeMb: 0,
      percent: 0
    };
  }
  return {
    available: false,
    error: 'statfs not supported by current runtime',
    totalBytes: 0,
    usedBytes: 0,
    freeBytes: 0,
    totalMb: 0,
    usedMb: 0,
    freeMb: 0,
    percent: 0
  };
}

function getHostMetrics(targetDir = config.serversDir) {
  const cpus = os.cpus() || [];
  const cpuPercent = sampleCpuPercent();
  const memory = getContainerAwareMemory();
  const disk = getDiskSpace(targetDir);
  const loadAvg = os.loadavg ? os.loadavg().map((v) => Number(v.toFixed(2))) : [0, 0, 0];

  return {
    cpuCores: cpus.length || 1,
    cpuModel: cpus[0] ? cpus[0].model : 'Generic Virtual CPU',
    cpuPercent,
    memory,
    disk,
    loadAvg,
    uptimeSeconds: Math.floor(os.uptime()),
    processUptimeSeconds: Math.floor(process.uptime())
  };
}

module.exports = {
  detectEnvironmentCapabilities,
  detectJavaRuntime,
  probeJavaBinary,
  getHostMetrics,
  getDiskSpace,
  getContainerAwareMemory
};
