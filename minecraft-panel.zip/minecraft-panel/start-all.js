'use strict';

/**
 * Unified production launcher for AashirwadGamerzz Minecraft Server Management Panel.
 * Starts the local Daemon service first, then boots the Web Control Panel and bridges Socket.IO.
 */

const { createDaemonServer } = require('./daemon/daemon');
const { createPanelServer } = require('./app');
const { logger } = require('./config/logger');

async function bootAll() {
  const daemon = createDaemonServer();
  await daemon.start();

  const panel = createPanelServer();
  await panel.start();

  let shuttingDown = false;
  const gracefulExit = async (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info('shutdown', `Received ${signal} — gracefully shutting down Panel and Daemon...`);
    try {
      await panel.shutdown();
    } catch (err) {
      logger.error('shutdown', 'Error stopping Panel', { error: err.message });
    }
    try {
      await daemon.shutdown();
    } catch (err) {
      logger.error('shutdown', 'Error stopping Daemon', { error: err.message });
    }
    process.exit(0);
  };

  process.on('SIGINT', () => gracefulExit('SIGINT'));
  process.on('SIGTERM', () => gracefulExit('SIGTERM'));
}

bootAll().catch((err) => {
  logger.error('startup', 'Fatal startup error in start-all.js', {
    error: err.message,
    stack: err.stack
  });
  process.exit(1);
});
