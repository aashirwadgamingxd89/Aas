/* AashirwadGamerzz Panel v1.0.0 — Plugins & Marketplace Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const installedRoot = document.getElementById('plugins-installed-root');
    const marketRoot = document.getElementById('plugins-marketplace-root');

    // --- INSTALLED PLUGINS ---
    if (installedRoot) {
      const uuid = installedRoot.getAttribute('data-uuid');
      const uploadBtn = document.getElementById('plugin-upload-btn');
      const uploadInput = document.getElementById('plugin-upload-input');

      if (uploadBtn && uploadInput) {
        uploadBtn.addEventListener('click', function () {
          uploadInput.click();
        });
        uploadInput.addEventListener('change', async function () {
          if (!uploadInput.files || !uploadInput.files[0]) return;
          const fd = new FormData();
          fd.append('plugin', uploadInput.files[0]);

          AG.setButtonLoading(uploadBtn, true, 'Uploading...');
          try {
            const res = await AG.uploadWithProgress(
              '/api/server/' + encodeURIComponent(uuid) + '/plugins/upload',
              fd
            );
            AG.toast(res.message, 'success');
            setTimeout(function () {
              window.location.reload();
            }, 600);
          } catch (err) {
            AG.toast(err.message, 'error');
          } finally {
            uploadInput.value = '';
            AG.setButtonLoading(uploadBtn, false);
          }
        });
      }

      document.querySelectorAll('[data-plugin-details]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          AG.confirmModal({
            title: btn.getAttribute('data-name') || 'Plugin Details',
            message:
              'Version: ' +
              (btn.getAttribute('data-version') || 'unknown') +
              ' | Author: ' +
              (btn.getAttribute('data-author') || 'Unknown') +
              ' | File: ' +
              (btn.getAttribute('data-file') || '') +
              ' — ' +
              (btn.getAttribute('data-desc') || 'No description provided.'),
            confirmText: 'Close'
          });
        });
      });

      document.querySelectorAll('[data-plugin-delete]').forEach(function (btn) {
        btn.addEventListener('click', async function () {
          const pluginId = btn.getAttribute('data-plugin-delete');
          const name = btn.getAttribute('data-name') || 'plugin';
          const ok = await AG.confirmModal({
            title: 'Delete Plugin "' + name + '"',
            message: 'Remove "' + name + '" JAR file from the server? Server must be stopped.',
            confirmText: 'Delete Plugin',
            danger: true
          });
          if (!ok) return;

          AG.setButtonLoading(btn, true, '');
          try {
            const res = await AG.api(
              '/api/server/' + encodeURIComponent(uuid) + '/plugins/' + encodeURIComponent(pluginId),
              { method: 'DELETE' }
            );
            AG.toast(res.message, 'success');
            setTimeout(function () {
              window.location.reload();
            }, 500);
          } catch (err) {
            AG.toast(err.message, 'error');
          } finally {
            AG.setButtonLoading(btn, false);
          }
        });
      });
    }

    // --- MARKETPLACE ---
    if (marketRoot) {
      const uuid = marketRoot.getAttribute('data-uuid');
      const searchForm = document.getElementById('mp-search-form');
      const queryInput = document.getElementById('mp-query-input');
      const sourceSelect = document.getElementById('mp-source-select');
      const searchBtn = document.getElementById('mp-search-btn');
      const gridEl = document.getElementById('mp-results-grid');

      function attachInstallButtons() {
        if (!gridEl) return;
        gridEl.querySelectorAll('[data-mp-install]').forEach(function (btn) {
          btn.addEventListener('click', async function () {
            const projectId = btn.getAttribute('data-mp-install');
            const source = btn.getAttribute('data-source') || 'MODRINTH';
            const title = btn.getAttribute('data-title') || projectId;

            const ok = await AG.confirmModal({
              title: 'Install "' + title + '"',
              message:
                'Download and install "' +
                title +
                '" from ' +
                source +
                ' after verifying compatibility and file hash?',
              confirmText: 'Install Plugin'
            });
            if (!ok) return;

            AG.setButtonLoading(btn, true, 'Installing...');
            try {
              const res = await AG.api(
                '/api/server/' + encodeURIComponent(uuid) + '/plugins/install',
                {
                  method: 'POST',
                  body: { projectId: projectId, source: source }
                }
              );
              AG.toast(res.message, 'success');
              btn.innerHTML = '<i class="fa-solid fa-check"></i> Installed';
              btn.disabled = true;
            } catch (err) {
              AG.toast(err.message, 'error');
              AG.setButtonLoading(btn, false);
            }
          });
        });
      }

      attachInstallButtons();

      if (searchForm) {
        searchForm.addEventListener('submit', async function (e) {
          e.preventDefault();
          const q = queryInput ? queryInput.value.trim() : '';
          const src = sourceSelect ? sourceSelect.value : 'all';

          AG.setButtonLoading(searchBtn, true, 'Searching...');
          try {
            const res = await AG.api(
              '/api/server/' +
                encodeURIComponent(uuid) +
                '/plugins/search?q=' +
                encodeURIComponent(q) +
                '&source=' +
                encodeURIComponent(src)
            );
            const items = (res.data && res.data.items) || [];
            if (!res.data.compatible) {
              gridEl.innerHTML =
                '<div class="alert alert-warning" style="grid-column:1/-1"><i class="fa-solid fa-triangle-exclamation"></i><span>' +
                AG.escapeHtml(res.data.reason) +
                '</span></div>';
              return;
            }
            if (items.length === 0) {
              gridEl.innerHTML =
                '<div class="panel-card" style="grid-column:1/-1"><div class="empty-state"><div class="empty-state-icon"><i class="fa-solid fa-plug"></i></div><h3>No matching plugins found</h3><p>Try a broader search term or switch plugin sources.</p></div></div>';
              return;
            }

            gridEl.innerHTML = items
              .map(function (p) {
                const iconHtml = p.iconUrl
                  ? '<img class="plugin-icon" src="' +
                    AG.escapeHtml(p.iconUrl) +
                    '" alt="" loading="lazy">'
                  : '<div class="plugin-icon"><i class="fa-solid fa-puzzle-piece"></i></div>';

                return (
                  '<div class="plugin-card">' +
                  '<div>' +
                  iconHtml +
                  '<h4 class="plugin-title">' +
                  AG.escapeHtml(p.name) +
                  '</h4>' +
                  '<div class="plugin-author">by ' +
                  AG.escapeHtml(p.author) +
                  '</div>' +
                  '<p class="plugin-desc">' +
                  AG.escapeHtml(p.description) +
                  '</p>' +
                  '</div>' +
                  '<div>' +
                  '<div class="plugin-meta-row" style="margin-bottom:10px">' +
                  '<span><i class="fa-solid fa-download"></i> ' +
                  Number(p.downloads || 0).toLocaleString() +
                  '</span>' +
                  '<span class="pill">' +
                  AG.escapeHtml(p.source) +
                  '</span>' +
                  '</div>' +
                  '<button type="button" class="btn btn-success" style="width:100%" data-mp-install="' +
                  AG.escapeHtml(p.id) +
                  '" data-source="' +
                  AG.escapeHtml(p.source) +
                  '" data-title="' +
                  AG.escapeHtml(p.name) +
                  '"><i class="fa-solid fa-download"></i> Install</button>' +
                  '</div></div>'
                );
              })
              .join('');

            attachInstallButtons();
          } catch (err) {
            AG.toast(err.message, 'error');
          } finally {
            AG.setButtonLoading(searchBtn, false);
          }
        });
      }
    }
  });
})();
