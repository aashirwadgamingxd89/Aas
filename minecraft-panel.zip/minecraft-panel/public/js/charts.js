/* AashirwadGamerzz Panel v1.0.0 — Lightweight Real-Time Canvas Area Chart */
(function () {
  'use strict';

  function AGChart(canvas, options) {
    this.canvas = canvas;
    this.ctx = canvas ? canvas.getContext('2d') : null;
    this.color = (options && options.color) || '#e4e4e7';
    this.fillTop = (options && options.fillTop) || 'rgba(228, 228, 231, 0.22)';
    this.maxPoints = (options && options.maxPoints) || 30;
    this.maxValue = (options && options.maxValue) || 100;
    this.points = Array.isArray(options && options.initialPoints)
      ? options.initialPoints.slice(-this.maxPoints)
      : [];

    const self = this;
    window.addEventListener('resize', function () {
      self.draw();
    });
    this.draw();
  }

  AGChart.prototype.pushPoint = function (value, label) {
    const v = Math.max(0, Math.min(this.maxValue, Number(value || 0)));
    const timeStr =
      label ||
      new Date().toLocaleTimeString([], {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    this.points.push({ value: v, label: timeStr });
    if (this.points.length > this.maxPoints) {
      this.points.shift();
    }
    this.draw();
  };

  AGChart.prototype.draw = function () {
    if (!this.canvas || !this.ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    const width = Math.max(200, rect.width || 320);
    const height = Math.max(120, rect.height || 175);

    if (this.canvas.width !== Math.round(width * dpr) || this.canvas.height !== Math.round(height * dpr)) {
      this.canvas.width = Math.round(width * dpr);
      this.canvas.height = Math.round(height * dpr);
    }

    const ctx = this.ctx;
    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    const padLeft = 36;
    const padRight = 10;
    const padTop = 10;
    const padBottom = 22;
    const plotW = width - padLeft - padRight;
    const plotH = height - padTop - padBottom;

    // Horizontal percentage gridlines (0%..100%)
    ctx.font = '10px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillStyle = '#5f5f70';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';

    const steps = 5;
    for (let i = 0; i <= steps; i++) {
      const pct = (i / steps) * 100;
      const y = padTop + plotH - (i / steps) * plotH;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.045)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(padLeft + plotW, y);
      ctx.stroke();
      ctx.fillText(Math.round(pct) + '%', padLeft - 6, y);
    }

    if (this.points.length === 0) {
      ctx.fillStyle = '#5f5f70';
      ctx.textAlign = 'center';
      ctx.fillText('Awaiting live metrics...', padLeft + plotW / 2, padTop + plotH / 2);
      ctx.restore();
      return;
    }

    const pts = this.points;
    const coords = pts.map(function (pt, idx) {
      const x =
        pts.length === 1
          ? padLeft + plotW
          : padLeft + (idx / Math.max(1, pts.length - 1)) * plotW;
      const norm = Math.max(0, Math.min(1, pt.value / 100));
      const y = padTop + plotH - norm * plotH;
      return { x: x, y: y, label: pt.label };
    });

    // Area gradient fill
    if (coords.length >= 2) {
      const grad = ctx.createLinearGradient(0, padTop, 0, padTop + plotH);
      grad.addColorStop(0, this.fillTop);
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.beginPath();
      ctx.moveTo(coords[0].x, padTop + plotH);
      for (let i = 0; i < coords.length; i++) {
        ctx.lineTo(coords[i].x, coords[i].y);
      }
      ctx.lineTo(coords[coords.length - 1].x, padTop + plotH);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();
    }

    // Stroke line
    ctx.beginPath();
    for (let i = 0; i < coords.length; i++) {
      if (i === 0) ctx.moveTo(coords[i].x, coords[i].y);
      else ctx.lineTo(coords[i].x, coords[i].y);
    }
    ctx.strokeStyle = this.color;
    ctx.lineWidth = 1.8;
    ctx.lineJoin = 'round';
    ctx.stroke();

    // X-axis time labels
    ctx.fillStyle = '#5f5f70';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const labelStride = Math.max(1, Math.ceil(coords.length / 5));
    for (let i = 0; i < coords.length; i += labelStride) {
      ctx.fillText(coords[i].label || '', coords[i].x, padTop + plotH + 6);
    }

    ctx.restore();
  };

  window.AGChart = AGChart;
})();
