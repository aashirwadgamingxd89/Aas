/* AashirwadGamerzz Panel v1.0.0 — Full Live Console Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('full-console-root');
    if (!root) return;

    const uuid = root.getAttribute('data-uuid');
    const outputEl = document.getElementById('console-output');
    const formEl = document.getElementById('console-form');
    const inputEl = document.getElementById('console-input');
    const sendBtn = document.getElementById('console-send-btn');
    const pauseBtn = document.getElementById('console-pause-btn');
    const clearBtn = document.getElementById('console-clear-btn');
    const offlineBanner = document.getElementById('console-offline-banner');

    let autoScroll = true;
    const commandHistory = [];
    let historyCursor = -1;

    function formatShortTime(iso) {
      if (!iso) return '';
      const d = new Date(iso);
      return isNaN(d.getTime())
        ? ''
        : d.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }

    function appendLine(entry) {
      if (!outputEl || !entry) return;
      const lineDiv = document.createElement('div');
      let cls = 'console-line ' + (entry.stream || 'stdout');
      if (/WARN/i.test(entry.line)) cls += ' warn';
      if (/ERROR|Exception/i.test(entry.line) && entry.stream !== 'command') cls += ' stderr';
      lineDiv.className = cls;

      const tsSpan = document.createElement('span');
      tsSpan.className = 'ts';
      tsSpan.textContent = '[' + formatShortTime(entry.timestamp) + ']';
      lineDiv.appendChild(tsSpan);
      lineDiv.appendChild(document.createTextNode(entry.line));

      outputEl.appendChild(lineDiv);
      while (outputEl.children.length > 600) {
        outputEl.removeChild(outputEl.firstChild);
      }

      if (autoScroll) {
        outputEl.scrollTop = outputEl.scrollHeight;
      }
    }

    if (outputEl) {
      outputEl.scrollTop = outputEl.scrollHeight;
    }

    if (pauseBtn) {
      pauseBtn.addEventListener('click', function () {
        autoScroll = !autoScroll;
        pauseBtn.innerHTML = autoScroll
          ? '<i class="fa-solid fa-pause"></i> Pause Scroll'
          : '<i class="fa-solid fa-angles-down"></i> Resume Scroll';
        if (autoScroll && outputEl) {
          outputEl.scrollTop = outputEl.scrollHeight;
        }
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        if (outputEl) outputEl.innerHTML = '';
        AG.toast('Console view cleared.', 'info');
      });
    }

    if (inputEl) {
      inputEl.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowUp') {
          if (commandHistory.length === 0) return;
          e.preventDefault();
          if (historyCursor < commandHistory.length - 1) {
            historyCursor++;
          }
          inputEl.value = commandHistory[commandHistory.length - 1 - historyCursor] || '';
        } else if (e.key === 'ArrowDown') {
          if (commandHistory.length === 0) return;
          e.preventDefault();
          if (historyCursor > 0) {
            historyCursor--;
            inputEl.value = commandHistory[commandHistory.length - 1 - historyCursor] || '';
          } else {
            historyCursor = -1;
            inputEl.value = '';
          }
        }
      });
    }

    if (formEl) {
      formEl.addEventListener('submit', async function (e) {
        e.preventDefault();
        const cmd = inputEl.value.trim();
        if (!cmd) return;

        commandHistory.push(cmd);
        if (commandHistory.length > 50) commandHistory.shift();
        historyCursor = -1;

        sendBtn.disabled = true;
        try {
          await AG.api('/api/server/' + encodeURIComponent(uuid) + '/command', {
            method: 'POST',
            body: { command: cmd }
          });
          inputEl.value = '';
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          sendBtn.disabled = false;
          inputEl.focus();
        }
      });
    }

    function updateConsoleOnline(status) {
      const online = status === 'running' || status === 'starting';
      if (offlineBanner) offlineBanner.style.display = online ? 'none' : 'flex';
      if (inputEl) inputEl.disabled = !online;
      if (sendBtn) sendBtn.disabled = !online;
    }

    function initSocket() {
      if (!AG.socket) {
        setTimeout(initSocket, 200);
        return;
      }
      AG.socket.emit('subscribe:server', uuid);

      AG.socket.on('server:console', function (entry) {
        if (entry && entry.uuid === uuid) {
          appendLine(entry);
        }
      });

      AG.socket.on('server:status', function (payload) {
        if (payload && payload.uuid === uuid) {
          updateConsoleOnline(payload.status);
        }
      });
    }

    initSocket();
  });
})();
