/* AashirwadGamerzz Panel v1.0.0 — Core Frontend Utilities & Real-Time Client */
(function () {
  'use strict';

  const csrfMeta = document.querySelector('meta[name="csrf-token"]');
  const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatBytes(bytes) {
    const b = Number(bytes || 0);
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(2) + ' KB';
    if (b < 1073741824) return (b / 1048576).toFixed(2) + ' MB';
    return (b / 1073741824).toFixed(2) + ' GB';
  }

  function formatMb(mb) {
    const val = Number(mb || 0);
    if (val >= 1024 && val % 1024 === 0) return val / 1024 + ' GB';
    if (val >= 2048) return (val / 1024).toFixed(2) + ' GB';
    return Math.round(val * 100) / 100 + ' MB';
  }

  function formatUptime(sec) {
    const s = Math.max(0, Math.floor(Number(sec || 0)));
    if (s === 0) return '0s';
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const rem = s % 60;
    const parts = [];
    if (d > 0) parts.push(d + 'd');
    if (h > 0) parts.push(h + 'h');
    if (m > 0) parts.push(m + 'm');
    if (rem > 0 && d === 0) parts.push(rem + 's');
    return parts.join(' ');
  }

  function toast(message, type) {
    const kind = type || 'info';
    let container = document.getElementById('ag-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'ag-toast-container';
      container.className = 'toast-container';
      container.setAttribute('aria-live', 'polite');
      document.body.appendChild(container);
    }

    const icons = {
      success: 'fa-circle-check',
      error: 'fa-circle-exclamation',
      warning: 'fa-triangle-exclamation',
      info: 'fa-circle-info'
    };

    const el = document.createElement('div');
    el.className = 'toast ' + kind;
    el.innerHTML =
      '<i class="fa-solid ' +
      (icons[kind] || icons.info) +
      '"></i><span>' +
      escapeHtml(message) +
      '</span>';
    container.appendChild(el);

    setTimeout(function () {
      el.style.opacity = '0';
      el.style.transition = 'opacity 200ms ease';
      setTimeout(function () {
        if (el.parentNode) el.parentNode.removeChild(el);
      }, 220);
    }, 4200);
  }

  function setButtonLoading(btn, isLoading, loadingText) {
    if (!btn) return;
    if (isLoading) {
      if (!btn.dataset.originalHtml) {
        btn.dataset.originalHtml = btn.innerHTML;
      }
      btn.disabled = true;
      btn.innerHTML =
        '<i class="fa-solid fa-spinner fa-spin"></i> ' +
        escapeHtml(loadingText || 'Working...');
    } else {
      btn.disabled = false;
      if (btn.dataset.originalHtml) {
        btn.innerHTML = btn.dataset.originalHtml;
        delete btn.dataset.originalHtml;
      }
    }
  }

  async function api(url, opts) {
    const options = opts || {};
    const method = (options.method || 'GET').toUpperCase();
    const headers = Object.assign(
      {
        Accept: 'application/json',
        'X-CSRF-Token': csrfToken
      },
      options.headers || {}
    );

    const fetchOpts = {
      method,
      headers,
      credentials: 'same-origin'
    };

    if (options.body !== undefined) {
      if (options.body instanceof FormData) {
        fetchOpts.body = options.body;
      } else {
        headers['Content-Type'] = 'application/json';
        fetchOpts.body = JSON.stringify(options.body);
      }
    }

    const res = await fetch(url, fetchOpts);
    let data = null;
    try {
      data = await res.json();
    } catch (_) {
      throw new Error('Unexpected server response (HTTP ' + res.status + ').');
    }

    if (!res.ok || !data.success) {
      throw new Error(data.message || 'Request failed (HTTP ' + res.status + ').');
    }
    return data;
  }

  function uploadWithProgress(url, formData, onProgress) {
    return new Promise(function (resolve, reject) {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.withCredentials = true;
      xhr.setRequestHeader('X-CSRF-Token', csrfToken);
      xhr.setRequestHeader('Accept', 'application/json');

      if (xhr.upload && typeof onProgress === 'function') {
        xhr.upload.onprogress = function (ev) {
          if (ev.lengthComputable) {
            const pct = Math.round((ev.loaded / ev.total) * 100);
            onProgress(pct, ev.loaded, ev.total);
          }
        };
      }

      xhr.onload = function () {
        let payload = null;
        try {
          payload = JSON.parse(xhr.responseText);
        } catch (_) {
          return reject(new Error('Invalid response from server during upload.'));
        }
        if (xhr.status >= 200 && xhr.status < 300 && payload.success) {
          resolve(payload);
        } else {
          reject(new Error(payload.message || 'Upload failed.'));
        }
      };

      xhr.onerror = function () {
        reject(new Error('Network error during file upload.'));
      };

      xhr.send(formData);
    });
  }

  /**
   * Reusable modal dialog supporting confirmation and single-field input prompts.
   */
  function confirmModal(opts) {
    const options = opts || {};
    return new Promise(function (resolve) {
      const backdrop = document.getElementById('ag-modal-backdrop');
      const titleEl = document.getElementById('ag-modal-title');
      const bodyEl = document.getElementById('ag-modal-body');
      const inputWrap = document.getElementById('ag-modal-input-wrap');
      const inputLabel = document.getElementById('ag-modal-input-label');
      const inputEl = document.getElementById('ag-modal-input');
      const cancelBtn = document.getElementById('ag-modal-cancel');
      const confirmBtn = document.getElementById('ag-modal-confirm');
      const closeBtn = document.getElementById('ag-modal-close');

      if (!backdrop) {
        return resolve(window.confirm(options.message || 'Are you sure?') ? true : null);
      }

      titleEl.textContent = options.title || 'Confirm Action';
      bodyEl.textContent = options.message || 'Are you sure you want to continue?';

      if (options.input) {
        inputWrap.style.display = 'block';
        inputLabel.textContent = options.inputLabel || 'Value';
        inputEl.value = options.defaultValue || '';
        inputEl.placeholder = options.placeholder || '';
        inputEl.type = options.inputType || 'text';
      } else {
        inputWrap.style.display = 'none';
        inputEl.value = '';
      }

      confirmBtn.textContent = options.confirmText || 'Confirm';
      confirmBtn.className = 'btn ' + (options.danger ? 'btn-danger' : 'btn-primary');

      function cleanup(result) {
        backdrop.classList.remove('open');
        cancelBtn.onclick = null;
        confirmBtn.onclick = null;
        closeBtn.onclick = null;
        document.removeEventListener('keydown', onKey);
        resolve(result);
      }

      function onKey(e) {
        if (e.key === 'Escape') cleanup(null);
        if (e.key === 'Enter' && options.input && document.activeElement === inputEl) {
          e.preventDefault();
          confirmBtn.click();
        }
      }

      cancelBtn.onclick = function () { cleanup(null); };
      closeBtn.onclick = function () { cleanup(null); };
      confirmBtn.onclick = function () {
        if (options.input) {
          cleanup(inputEl.value);
        } else {
          cleanup(true);
        }
      };

      document.addEventListener('keydown', onKey);
      backdrop.classList.add('open');
      if (options.input) {
        setTimeout(function () { inputEl.focus(); }, 40);
      } else {
        setTimeout(function () { confirmBtn.focus(); }, 40);
      }
    });
  }

  // Mobile sidebar navigation drawer
  document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('ag-sidebar');
    const overlay = document.getElementById('ag-sidebar-overlay');
    const toggleBtn = document.getElementById('ag-mobile-menu-btn');

    if (toggleBtn && sidebar && overlay) {
      toggleBtn.addEventListener('click', function () {
        sidebar.classList.toggle('mobile-open');
        overlay.classList.toggle('open');
      });
      overlay.addEventListener('click', function () {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('open');
      });
    }

    // Initialize Socket.IO if loaded on authenticated pages
    if (typeof window.io === 'function') {
      const socket = window.io({
        path: '/socket.io',
        withCredentials: true
      });
      window.AG.socket = socket;

      const updateLiveIndicators = function (connected) {
        document.querySelectorAll('[data-live-indicator]').forEach(function (el) {
          if (connected) {
            el.classList.remove('disconnected');
            el.innerHTML = '<span class="status-dot running"></span> LIVE';
          } else {
            el.classList.add('disconnected');
            el.innerHTML = '<span class="status-dot offline"></span> RECONNECTING';
          }
        });
      };

      socket.on('connect', function () {
        updateLiveIndicators(true);
        if (window.AG.activeServerUuid) {
          socket.emit('subscribe:server', window.AG.activeServerUuid);
        }
      });

      socket.on('disconnect', function () {
        updateLiveIndicators(false);
      });

      socket.on('notification:new', function (payload) {
        if (!payload) return;
        const count = Number(payload.unreadCount || 0);
        window.AG.updateUnreadBadges(count);
        if (payload.notification && payload.notification.title) {
          const mapType = {
            success: 'success',
            danger: 'error',
            warning: 'warning',
            info: 'info'
          };
          toast(
            payload.notification.title + ': ' + payload.notification.message,
            mapType[payload.notification.type] || 'info'
          );
        }
      });

      socket.on('server:status', function (payload) {
        if (!payload || !payload.uuid) return;
        document
          .querySelectorAll('[data-sidebar-server-dot="' + payload.uuid + '"]')
          .forEach(function (dot) {
            dot.className = 'status-dot ' + payload.status;
          });
        if (window.AG.activeServerUuid === payload.uuid) {
          syncHeaderServerStatus(payload.status);
        }
      });
    }

    const headerWrap = document.querySelector('[data-active-server-uuid]');
    if (headerWrap) {
      const activeUuid = headerWrap.getAttribute('data-active-server-uuid');
      window.AG.activeServerUuid = activeUuid;
      if (window.AG.socket && window.AG.socket.connected) {
        window.AG.socket.emit('subscribe:server', activeUuid);
      }
    }

    // Universal server header power actions (Start, Stop, Restart, Kill)
    document.querySelectorAll('[data-server-power]').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        const action = btn.getAttribute('data-server-power');
        const uuid = btn.getAttribute('data-uuid');
        const srvName = btn.getAttribute('data-server-name') || 'server';

        if (action === 'stop' || action === 'restart' || action === 'kill') {
          const labels = {
            stop: {
              title: 'Stop Server',
              msg: 'Gracefully save worlds and stop "' + srvName + '"?',
              btn: 'Stop Server',
              danger: true
            },
            restart: {
              title: 'Restart Server',
              msg: 'Gracefully restart "' + srvName + '"? Connected players will be disconnected.',
              btn: 'Restart Server',
              danger: false
            },
            kill: {
              title: 'Force Kill Process (SIGKILL)',
              msg: 'Force-terminate "' + srvName + '" immediately? Unsaved world chunks since last autosave may be lost.',
              btn: 'Force Kill',
              danger: true
            }
          };
          const cfg = labels[action];
          const confirmed = await confirmModal({
            title: cfg.title,
            message: cfg.msg,
            confirmText: cfg.btn,
            danger: cfg.danger
          });
          if (!confirmed) return;
        }

        setButtonLoading(btn, true, action.charAt(0).toUpperCase() + action.slice(1) + '...');
        try {
          const res = await api('/api/server/' + encodeURIComponent(uuid) + '/power', {
            method: 'POST',
            body: { action: action }
          });
          toast(res.message, 'success');
          if (res.data && res.data.status) {
            syncHeaderServerStatus(res.data.status);
          }
        } catch (err) {
          toast(err.message, 'error');
        } finally {
          setButtonLoading(btn, false);
        }
      });
    });
  });

  function syncHeaderServerStatus(status) {
    const labelMap = {
      running: 'Running',
      starting: 'Starting',
      stopping: 'Stopping',
      offline: 'Offline',
      crashed: 'Crashed',
      installing: 'Installing',
      install_failed: 'Install Failed'
    };
    const text = labelMap[status] || status;
    document.querySelectorAll('[data-header-status]').forEach(function (el) {
      el.innerHTML =
        '<span class="status-dot ' +
        escapeHtml(status) +
        '"></span> ' +
        escapeHtml(text);
    });
    const btnStart = document.getElementById('header-btn-start');
    const btnRestart = document.getElementById('header-btn-restart');
    const btnStop = document.getElementById('header-btn-stop');
    const btnKill = document.getElementById('header-btn-kill');

    const isActive = status === 'running' || status === 'starting';
    const isBusy = status === 'installing' || status === 'stopping';
    if (btnStart) btnStart.style.display = isActive ? 'none' : '';
    if (btnStart) btnStart.disabled = isBusy;
    if (btnRestart) btnRestart.disabled = status === 'installing';
    if (btnStop) btnStop.style.display = isActive || status === 'stopping' ? '' : 'none';
    if (btnKill) btnKill.style.display = isActive || status === 'stopping' ? '' : 'none';
  }

  function updateUnreadBadges(count) {
    document.querySelectorAll('[data-unread-badge]').forEach(function (badge) {
      if (count > 0) {
        badge.textContent = count > 99 ? '99+' : String(count);
        badge.style.display = '';
      } else {
        badge.style.display = 'none';
      }
    });
  }

  window.AG = {
    csrfToken,
    escapeHtml,
    formatBytes,
    formatMb,
    formatUptime,
    toast,
    setButtonLoading,
    api,
    uploadWithProgress,
    confirmModal,
    updateUnreadBadges,
    socket: null,
    activeServerUuid: null
  };
})();
