/* AashirwadGamerzz Panel v1.0.0 — World Manager & World Installer Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('worlds-root');
    if (!root) return;

    const uuid = root.getAttribute('data-uuid');
    const uploadToggleBtn = document.getElementById('world-upload-toggle-btn');
    const installerCard = document.getElementById('world-installer-card');
    const uploadForm = document.getElementById('world-upload-form');
    const uploadFileInput = document.getElementById('world-archive-input');
    const uploadNameInput = document.getElementById('world-name-input');
    const uploadSubmitBtn = document.getElementById('world-upload-submit');
    const progressWrap = document.getElementById('world-upload-progress-wrap');
    const progressBar = document.getElementById('world-upload-progress-bar');
    const progressText = document.getElementById('world-upload-progress-text');

    if (uploadToggleBtn && installerCard) {
      uploadToggleBtn.addEventListener('click', function () {
        installerCard.style.display = installerCard.style.display === 'none' ? 'block' : 'none';
      });
    }

    if (uploadForm) {
      uploadForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        if (!uploadFileInput.files || !uploadFileInput.files[0]) {
          AG.toast('Select a .zip world archive to upload.', 'warning');
          return;
        }

        const fd = new FormData();
        fd.append('worldArchive', uploadFileInput.files[0]);
        fd.append('worldName', uploadNameInput ? uploadNameInput.value.trim() : '');

        if (progressWrap) progressWrap.style.display = 'block';
        AG.setButtonLoading(uploadSubmitBtn, true, 'Importing World...');

        try {
          const res = await AG.uploadWithProgress(
            '/api/server/' + encodeURIComponent(uuid) + '/worlds/upload',
            fd,
            function (pct) {
              if (progressBar) progressBar.style.width = pct + '%';
              if (progressText) {
                progressText.textContent =
                  pct < 100
                    ? 'Uploading archive... ' + pct + '%'
                    : 'Validating & safely extracting world files...';
              }
            }
          );
          AG.toast(res.message, 'success');
          setTimeout(function () {
            window.location.reload();
          }, 700);
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          AG.setButtonLoading(uploadSubmitBtn, false);
        }
      });
    }

    document.querySelectorAll('[data-world-activate]').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        const wName = btn.getAttribute('data-world-activate');
        const ok = await AG.confirmModal({
          title: 'Activate World "' + wName + '"',
          message:
            'Set "' +
            wName +
            '" as level-name in server.properties? Restart the server afterwards to load this world.',
          confirmText: 'Activate World'
        });
        if (!ok) return;

        AG.setButtonLoading(btn, true, '');
        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/worlds/activate', {
            method: 'POST',
            body: { worldName: wName }
          });
          AG.toast(res.message, 'success');
          setTimeout(function () {
            window.location.reload();
          }, 600);
        } catch (err) {
          AG.toast(err.message, 'error');
          AG.setButtonLoading(btn, false);
        }
      });
    });

    document.querySelectorAll('[data-world-rename]').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        const oldName = btn.getAttribute('data-world-rename');
        const newName = await AG.confirmModal({
          title: 'Rename World "' + oldName + '"',
          message: 'Enter a new world directory name (server must be stopped):',
          input: true,
          inputLabel: 'New World Name',
          defaultValue: oldName,
          confirmText: 'Rename World'
        });
        if (!newName || newName.trim() === oldName) return;

        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/worlds/rename', {
            method: 'POST',
            body: { oldName: oldName, newName: newName.trim() }
          });
          AG.toast(res.message, 'success');
          setTimeout(function () {
            window.location.reload();
          }, 600);
        } catch (err) {
          AG.toast(err.message, 'error');
        }
      });
    });

    document.querySelectorAll('[data-world-delete]').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        const wDir = btn.getAttribute('data-world-delete');
        const isActive = btn.getAttribute('data-is-active') === '1';

        const ok = await AG.confirmModal({
          title: 'Delete World "' + wDir + '"',
          message: isActive
            ? 'WARNING: "' +
              wDir +
              '" is currently the ACTIVE world! Deleting it permanently erases all terrain and player data in this folder. Server must be stopped.'
            : 'Permanently delete world "' + wDir + '" and all its region files?',
          confirmText: isActive ? 'Confirm Active World Deletion' : 'Delete World',
          danger: true
        });
        if (!ok) return;

        AG.setButtonLoading(btn, true, '');
        try {
          const res = await AG.api(
            '/api/server/' + encodeURIComponent(uuid) + '/worlds/' + encodeURIComponent(wDir),
            {
              method: 'DELETE',
              body: { confirmActive: isActive }
            }
          );
          AG.toast(res.message, 'success');
          setTimeout(function () {
            window.location.reload();
          }, 600);
        } catch (err) {
          AG.toast(err.message, 'error');
          AG.setButtonLoading(btn, false);
        }
      });
    });
  });
})();
