/* AashirwadGamerzz Panel v1.0.0 — Player Manager Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('players-root');
    if (!root) return;

    const uuid = root.getAttribute('data-uuid');
    const quickForm = document.getElementById('player-quick-form');
    const quickUsername = document.getElementById('player-quick-username');
    const quickAction = document.getElementById('player-quick-action');
    const quickSubmit = document.getElementById('player-quick-submit');

    async function runPlayerAction(action, username, btn) {
      let reason = '';
      if (action === 'kick' || action === 'ban') {
        const resPrompt = await AG.confirmModal({
          title: (action === 'ban' ? 'Ban ' : 'Kick ') + username,
          message: 'Optional reason shown to "' + username + '":',
          input: true,
          inputLabel: 'Reason (optional)',
          placeholder: action === 'ban' ? 'Violating server rules' : 'Kicked by operator',
          confirmText: action === 'ban' ? 'Ban Player' : 'Kick Player',
          danger: true
        });
        if (resPrompt === null) return;
        reason = resPrompt;
      } else {
        const ok = await AG.confirmModal({
          title: 'Confirm Player Action',
          message: 'Execute "' + action + '" for player "' + username + '"?',
          confirmText: 'Execute'
        });
        if (!ok) return;
      }

      if (btn) AG.setButtonLoading(btn, true, '');
      try {
        const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/players/action', {
          method: 'POST',
          body: { action: action, username: username, reason: reason }
        });
        AG.toast(res.message, 'success');
        setTimeout(function () {
          window.location.reload();
        }, 700);
      } catch (err) {
        AG.toast(err.message, 'error');
        if (btn) AG.setButtonLoading(btn, false);
      }
    }

    document.querySelectorAll('[data-player-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const action = btn.getAttribute('data-player-action');
        const username = btn.getAttribute('data-username');
        runPlayerAction(action, username, btn);
      });
    });

    if (quickForm) {
      quickForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const user = quickUsername.value.trim();
        const act = quickAction.value;
        if (!user) {
          AG.toast('Enter a valid Minecraft username.', 'warning');
          return;
        }
        runPlayerAction(act, user, quickSubmit);
      });
    }

    function bindSocket() {
      if (!AG.socket) {
        setTimeout(bindSocket, 250);
        return;
      }
      AG.socket.emit('subscribe:server', uuid);
      AG.socket.on('server:players', function (payload) {
        if (payload && payload.uuid === uuid) {
          window.location.reload();
        }
      });
    }
    bindSocket();
  });
})();
