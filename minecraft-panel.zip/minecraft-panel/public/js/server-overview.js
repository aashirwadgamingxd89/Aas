/* AashirwadGamerzz Panel v1.0.0 — Server Overview Live Metrics, Charts & Mini Console */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('server-overview-root');
    if (!root) return;

    const uuid = root.getAttribute('data-uuid');
    const ramLimitMb = Number(root.getAttribute('data-ram-limit') || 1024);
    const diskLimitMb = Number(root.getAttribute('data-disk-limit') || 2048);
    const maxPlayers = Number(root.getAttribute('data-max-players') || 20);

    let historyData = [];
    try {
      const raw = document.getElementById('initial-metrics-json');
      if (raw && raw.textContent) {
        historyData = JSON.parse(raw.textContent);
      }
    } catch (_) {}

    const toTimeLabel = function (iso) {
      if (!iso) return '';
      const d = new Date(iso.endsWith('Z') ? iso : iso + 'Z');
      return isNaN(d.getTime())
        ? ''
        : d.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    };

    const cpuChart = new window.AGChart(document.getElementById('chart-cpu'), {
      color: '#e4e4e7',
      fillTop: 'rgba(228, 228, 231, 0.20)',
      initialPoints: historyData.map(function (r) {
        return { value: Number(r.cpu_usage || 0), label: toTimeLabel(r.recorded_at) };
      })
    });

    const memChart = new window.AGChart(document.getElementById('chart-memory'), {
      color: '#3b82f6',
      fillTop: 'rgba(59, 130, 246, 0.25)',
      initialPoints: historyData.map(function (r) {
        const pct = ramLimitMb > 0 ? (Number(r.ram_usage || 0) / ramLimitMb) * 100 : 0;
        return { value: pct, label: toTimeLabel(r.recorded_at) };
      })
    });

    const diskChart = new window.AGChart(document.getElementById('chart-disk'), {
      color: '#ef4444',
      fillTop: 'rgba(239, 68, 68, 0.22)',
      initialPoints: historyData.map(function (r) {
        const pct = diskLimitMb > 0 ? (Number(r.disk_usage || 0) / diskLimitMb) * 100 : 0;
        return { value: pct, label: toTimeLabel(r.recorded_at) };
      })
    });

    const consoleBox = document.getElementById('mini-console-output');
    const cmdForm = document.getElementById('mini-console-form');
    const cmdInput = document.getElementById('mini-console-input');
    const cmdBtn = document.getElementById('mini-console-send');
    const offlineBanner = document.getElementById('mini-console-offline');
    const installBanner = document.getElementById('install-progress-banner');
    const installMsg = document.getElementById('install-progress-msg');
    const installBar = document.getElementById('install-progress-bar');

    if (consoleBox) {
      consoleBox.scrollTop = consoleBox.scrollHeight;
    }

    function appendMiniConsole(entry) {
      if (!consoleBox || !entry) return;
      const div = document.createElement('div');
      let cls = 'console-line ' + (entry.stream || 'stdout');
      if (/WARN/i.test(entry.line)) cls += ' warn';
      div.className = cls;
      div.textContent = entry.line;
      consoleBox.appendChild(div);
      while (consoleBox.children.length > 180) {
        consoleBox.removeChild(consoleBox.firstChild);
      }
      consoleBox.scrollTop = consoleBox.scrollHeight;
    }

    if (cmdForm) {
      cmdForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const command = cmdInput.value.trim();
        if (!command) return;
        cmdBtn.disabled = true;
        try {
          await AG.api('/api/server/' + encodeURIComponent(uuid) + '/command', {
            method: 'POST',
            body: { command: command }
          });
          cmdInput.value = '';
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          cmdBtn.disabled = false;
          cmdInput.focus();
        }
      });
    }

    function applyMetrics(stats) {
      if (!stats) return;
      const cpuPct = Math.min(100, Number(stats.cpuPercent || 0));
      const memMb = Number(stats.memoryMb || 0);
      const memPct = ramLimitMb > 0 ? Math.min(100, (memMb / ramLimitMb) * 100) : 0;
      const diskMb = Number(stats.diskMb || 0);
      const diskPct = diskLimitMb > 0 ? Math.min(100, (diskMb / diskLimitMb) * 100) : 0;
      const players = Number(stats.playerCount || 0);
      const uptime = Number(stats.uptimeSeconds || 0);

      const elCpu = document.getElementById('ov-cpu-val');
      const elCpuBar = document.getElementById('ov-cpu-bar');
      const elCpuChartBadge = document.getElementById('chart-cpu-badge');

      const elMem = document.getElementById('ov-mem-val');
      const elMemSub = document.getElementById('ov-mem-sub');
      const elMemBar = document.getElementById('ov-mem-bar');
      const elMemChartBadge = document.getElementById('chart-mem-badge');

      const elPl = document.getElementById('ov-players-val');
      const elDisk = document.getElementById('ov-disk-val');
      const elDiskSub = document.getElementById('ov-disk-sub');
      const elDiskBar = document.getElementById('ov-disk-bar');
      const elDiskChartBadge = document.getElementById('chart-disk-badge');

      const elUptime = document.getElementById('ov-uptime-val');

      if (elCpu) elCpu.textContent = cpuPct.toFixed(1) + '%';
      if (elCpuBar) elCpuBar.style.width = cpuPct + '%';
      if (elCpuChartBadge) elCpuChartBadge.textContent = cpuPct.toFixed(1) + '%';

      if (elMem) elMem.textContent = Math.round(memMb) + ' MB';
      if (elMemSub) elMemSub.textContent = 'Used ' + Math.round(memMb) + ' / ' + ramLimitMb + ' MB';
      if (elMemBar) elMemBar.style.width = memPct + '%';
      if (elMemChartBadge) elMemChartBadge.textContent = memPct.toFixed(1) + '%';

      if (elPl) elPl.textContent = players + ' / ' + maxPlayers;

      if (elDisk) elDisk.textContent = Math.round(diskPct) + '%';
      if (elDiskSub) elDiskSub.textContent = 'Used ' + diskMb.toFixed(1) + ' MB / ' + diskLimitMb + ' MB';
      if (elDiskBar) elDiskBar.style.width = diskPct + '%';
      if (elDiskChartBadge) elDiskChartBadge.textContent = diskPct.toFixed(1) + '%';

      if (elUptime) elUptime.textContent = AG.formatUptime(uptime);

      cpuChart.pushPoint(cpuPct);
      memChart.pushPoint(memPct);
      diskChart.pushPoint(diskPct);
    }

    function applyStatusUI(status) {
      const online = status === 'running' || status === 'starting';
      if (offlineBanner) {
        offlineBanner.style.display = online ? 'none' : 'flex';
      }
      if (cmdInput) cmdInput.disabled = !online;
      if (cmdBtn) cmdBtn.disabled = !online;
      const infoStatus = document.getElementById('info-server-status');
      if (infoStatus) {
        infoStatus.innerHTML =
          '<span class="status-dot ' +
          AG.escapeHtml(status) +
          '"></span> ' +
          AG.escapeHtml(status.charAt(0).toUpperCase() + status.slice(1));
      }
      if (status === 'offline' || status === 'crashed') {
        applyMetrics({
          cpuPercent: 0,
          memoryMb: 0,
          diskMb: parseFloat(root.getAttribute('data-current-disk') || '0'),
          playerCount: 0,
          uptimeSeconds: 0
        });
      }
    }

    function connectRealtime() {
      if (!AG.socket) {
        setTimeout(connectRealtime, 200);
        return;
      }
      AG.socket.emit('subscribe:server', uuid);

      AG.socket.on('server:console', function (entry) {
        if (entry && entry.uuid === uuid) {
          appendMiniConsole(entry);
        }
      });

      AG.socket.on('server:metrics', function (stats) {
        if (stats && stats.uuid === uuid) {
          root.setAttribute('data-current-disk', String(stats.diskMb || 0));
          applyMetrics(stats);
        }
      });

      AG.socket.on('server:status', function (payload) {
        if (payload && payload.uuid === uuid) {
          applyStatusUI(payload.status);
          if (installBanner && payload.status === 'offline') {
            installBanner.style.display = 'none';
          }
        }
      });

      AG.socket.on('server:install', function (payload) {
        if (!payload || payload.uuid !== uuid) return;
        if (installBanner) installBanner.style.display = 'block';
        if (installMsg) installMsg.textContent = payload.message || 'Installing...';
        if (installBar && payload.percent != null) {
          installBar.style.width = Math.min(100, Math.max(2, Number(payload.percent))) + '%';
        }
        if (payload.status === 'completed') {
          setTimeout(function () {
            window.location.reload();
          }, 900);
        }
      });
    }

    connectRealtime();
  });
})();
