/* AashirwadGamerzz Panel v1.0.0 — Live User Dashboard Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    // Quick power buttons on server cards
    document.querySelectorAll('[data-card-power]').forEach(function (btn) {
      btn.addEventListener('click', async function (e) {
        e.preventDefault();
        const uuid = btn.getAttribute('data-uuid');
        const action = btn.getAttribute('data-card-power');
        const serverName = btn.getAttribute('data-server-name') || 'server';

        if (action === 'stop' || action === 'restart') {
          const ok = await AG.confirmModal({
            title: (action === 'stop' ? 'Stop ' : 'Restart ') + serverName,
            message: 'Are you sure you want to ' + action + ' "' + serverName + '"?',
            confirmText: action === 'stop' ? 'Stop Server' : 'Restart Server',
            danger: action === 'stop'
          });
          if (!ok) return;
        }

        AG.setButtonLoading(btn, true, action === 'start' ? 'Starting' : 'Working');
        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/power', {
            method: 'POST',
            body: { action: action }
          });
          AG.toast(res.message, 'success');
          if (res.data && res.data.status) {
            updateCardStatus(uuid, res.data.status);
          }
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          AG.setButtonLoading(btn, false);
        }
      });
    });

    // Copy server address helper
    document.querySelectorAll('[data-copy-address]').forEach(function (el) {
      el.addEventListener('click', function () {
        const addr = el.getAttribute('data-copy-address');
        if (navigator.clipboard && addr) {
          navigator.clipboard.writeText(addr).then(function () {
            AG.toast('Copied address: ' + addr, 'info');
          });
        }
      });
    });

    function recalcSummaryCounts() {
      const cards = document.querySelectorAll('[data-server-card]');
      let running = 0;
      let offline = 0;
      cards.forEach(function (c) {
        const st = c.getAttribute('data-status');
        if (st === 'running' || st === 'starting') running++;
        else offline++;
      });
      const runEl = document.getElementById('summary-running-count');
      const offEl = document.getElementById('summary-offline-count');
      if (runEl) runEl.textContent = String(running);
      if (offEl) offEl.textContent = String(offline);
    }

    function updateCardStatus(uuid, status) {
      const card = document.querySelector('[data-server-card="' + uuid + '"]');
      if (!card) return;
      card.setAttribute('data-status', status);

      const pill = card.querySelector('[data-card-status-pill]');
      if (pill) {
        pill.className = 'pill ' + status;
        pill.innerHTML =
          '<span class="status-dot ' +
          status +
          '"></span> ' +
          AG.escapeHtml(status.toUpperCase());
      }

      if (status === 'offline' || status === 'crashed') {
        const cpuTxt = card.querySelector('[data-card-cpu]');
        const ramTxt = card.querySelector('[data-card-ram]');
        const cpuBar = card.querySelector('[data-card-cpu-bar]');
        const ramBar = card.querySelector('[data-card-ram-bar]');
        const plTxt = card.querySelector('[data-card-players]');
        if (cpuTxt) cpuTxt.textContent = '0.0%';
        if (ramTxt) ramTxt.textContent = '0 MB';
        if (cpuBar) cpuBar.style.width = '0%';
        if (ramBar) ramBar.style.width = '0%';
        if (plTxt) plTxt.textContent = '0';
      }

      recalcSummaryCounts();
    }

    function bindSocketListeners() {
      if (!AG.socket) {
        setTimeout(bindSocketListeners, 250);
        return;
      }

      AG.socket.on('server:status', function (payload) {
        if (payload && payload.uuid && payload.status) {
          updateCardStatus(payload.uuid, payload.status);
        }
      });

      AG.socket.on('server:metrics', function (stats) {
        if (!stats || !stats.uuid) return;
        const card = document.querySelector('[data-server-card="' + stats.uuid + '"]');
        if (!card) return;

        if (stats.status) updateCardStatus(stats.uuid, stats.status);

        const cpuTxt = card.querySelector('[data-card-cpu]');
        const ramTxt = card.querySelector('[data-card-ram]');
        const diskTxt = card.querySelector('[data-card-disk]');
        const cpuBar = card.querySelector('[data-card-cpu-bar]');
        const ramBar = card.querySelector('[data-card-ram-bar]');
        const diskBar = card.querySelector('[data-card-disk-bar]');
        const plTxt = card.querySelector('[data-card-players]');

        const cpuPct = Math.min(100, Number(stats.cpuPercent || 0));
        const ramPct =
          stats.ramLimitMb > 0
            ? Math.min(100, (Number(stats.memoryMb || 0) / stats.ramLimitMb) * 100)
            : 0;
        const diskPct =
          stats.diskLimitMb > 0
            ? Math.min(100, (Number(stats.diskMb || 0) / stats.diskLimitMb) * 100)
            : 0;

        if (cpuTxt) cpuTxt.textContent = cpuPct.toFixed(1) + '%';
        if (ramTxt) ramTxt.textContent = Number(stats.memoryMb || 0).toFixed(1) + ' MB';
        if (diskTxt) diskTxt.textContent = Number(stats.diskMb || 0).toFixed(1) + ' MB';
        if (cpuBar) cpuBar.style.width = cpuPct + '%';
        if (ramBar) ramBar.style.width = ramPct + '%';
        if (diskBar) diskBar.style.width = diskPct + '%';
        if (plTxt) plTxt.textContent = String(stats.playerCount || 0);
      });
    }

    bindSocketListeners();
  });
})();
