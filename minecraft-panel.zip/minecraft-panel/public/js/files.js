/* AashirwadGamerzz Panel v1.0.0 — File Manager & Code Editor Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('file-manager-root');
    if (!root) return;

    const uuid = root.getAttribute('data-uuid');
    let currentPath = root.getAttribute('data-initial-path') || '';
    let currentItems = [];
    const selectedPaths = new Set();

    // Editor state
    let editingPath = null;
    let savedContent = '';
    let isDirty = false;

    const tbody = document.getElementById('fm-tbody');
    const breadcrumbsEl = document.getElementById('fm-breadcrumbs');
    const backBtn = document.getElementById('fm-back-btn');
    const selectAllBtn = document.getElementById('fm-select-all-btn');
    const bulkBar = document.getElementById('fm-bulk-bar');
    const bulkCountEl = document.getElementById('fm-bulk-count');
    const bulkDownloadBtn = document.getElementById('fm-bulk-download');
    const bulkZipBtn = document.getElementById('fm-bulk-zip');
    const bulkDeleteBtn = document.getElementById('fm-bulk-delete');
    const bulkClearBtn = document.getElementById('fm-bulk-clear');

    const uploadInput = document.getElementById('fm-upload-input');
    const uploadBtn = document.getElementById('fm-upload-btn');
    const uploadProgressWrap = document.getElementById('fm-upload-progress-wrap');
    const uploadProgressBar = document.getElementById('fm-upload-progress-bar');
    const uploadProgressText = document.getElementById('fm-upload-progress-text');

    const newFileBtn = document.getElementById('fm-new-file-btn');
    const newFolderBtn = document.getElementById('fm-new-folder-btn');

    // Editor DOM
    const managerCard = document.getElementById('fm-browser-card');
    const editorCard = document.getElementById('fm-editor-card');
    const editorPathEl = document.getElementById('editor-file-path');
    const editorLangBadge = document.getElementById('editor-lang-badge');
    const editorDirtyBadge = document.getElementById('editor-dirty-badge');
    const editorSearchInput = document.getElementById('editor-search-input');
    const editorFindBtn = document.getElementById('editor-find-btn');
    const editorSaveBtn = document.getElementById('editor-save-btn');
    const editorCloseBtn = document.getElementById('editor-close-btn');
    const editorTextarea = document.getElementById('editor-textarea');
    const editorGutter = document.getElementById('editor-gutter');

    try {
      const initialScript = document.getElementById('fm-initial-items-json');
      if (initialScript && initialScript.textContent) {
        currentItems = JSON.parse(initialScript.textContent);
      }
    } catch (_) {}

    function fileIconClass(item) {
      if (item.isDirectory) return 'fa-solid fa-folder" style="color:#eab308';
      if (item.type === 'java-archive') return 'fa-solid fa-Box-archive fa-cube" style="color:#a855f7';
      if (item.type === 'archive') return 'fa-solid fa-file-zipper" style="color:#eab308';
      if (['yml', 'yaml', 'json', 'properties', 'toml', 'conf', 'cfg', 'sh'].includes(item.type)) {
        return 'fa-solid fa-file-code" style="color:#3b82f6';
      }
      return 'fa-solid fa-file-lines" style="color:#9898a6';
    }

    function updateBulkBar() {
      const count = selectedPaths.size;
      if (bulkCountEl) bulkCountEl.textContent = count + ' selected';
      if (bulkBar) {
        bulkBar.style.display = count > 0 ? 'flex' : 'none';
      }
    }

    function renderBreadcrumbs() {
      if (!breadcrumbsEl) return;
      const parts = currentPath ? currentPath.split('/').filter(Boolean) : [];
      let html =
        '<button type="button" class="btn btn-sm btn-ghost" data-crumb=""><i class="fa-solid fa-house"></i> /</button>';
      let accum = '';
      for (let i = 0; i < parts.length; i++) {
        accum = accum ? accum + '/' + parts[i] : parts[i];
        html +=
          ' <span style="color:var(--text-muted)">/</span> <button type="button" class="btn btn-sm btn-ghost" data-crumb="' +
          AG.escapeHtml(accum) +
          '">' +
          AG.escapeHtml(parts[i]) +
          '</button>';
      }
      breadcrumbsEl.innerHTML = html;
      breadcrumbsEl.querySelectorAll('[data-crumb]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          loadDirectory(btn.getAttribute('data-crumb') || '');
        });
      });

      if (backBtn) {
        backBtn.style.display = parts.length > 0 ? '' : 'none';
      }
    }

    function renderTable() {
      renderBreadcrumbs();
      updateBulkBar();
      if (!tbody) return;

      if (currentItems.length === 0) {
        tbody.innerHTML =
          '<tr><td colspan="6"><div class="empty-state" style="padding:30px 16px"><div class="empty-state-icon"><i class="fa-regular fa-folder-open"></i></div><h3>Directory is empty</h3><p>Upload files, create a configuration file, or create a subfolder.</p></div></td></tr>';
        return;
      }

      tbody.innerHTML = currentItems
        .map(function (item) {
          const checked = selectedPaths.has(item.path) ? 'checked' : '';
          const sizeStr = item.isDirectory ? '-' : AG.formatBytes(item.size);
          return (
            '<tr data-row-path="' +
            AG.escapeHtml(item.path) +
            '">' +
            '<td style="width:36px"><input type="checkbox" class="fm-row-check" data-path="' +
            AG.escapeHtml(item.path) +
            '" ' +
            checked +
            '></td>' +
            '<td><button type="button" class="fm-open-item" data-path="' +
            AG.escapeHtml(item.path) +
            '" data-isdir="' +
            (item.isDirectory ? '1' : '0') +
            '" data-editable="' +
            (item.editable ? '1' : '0') +
            '" style="background:none;border:none;padding:0;cursor:pointer;display:inline-flex;align-items:center;gap:10px;text-align:left;color:var(--text-primary);font-weight:500">' +
            '<i class="' +
            fileIconClass(item) +
            '"></i><span>' +
            AG.escapeHtml(item.name) +
            '</span></button></td>' +
            '<td style="color:var(--text-muted);font-size:12px">' +
            AG.escapeHtml(item.type) +
            ' &bull; <span style="font-family:var(--font-mono)">' +
            AG.escapeHtml(item.permissions) +
            '</span></td>' +
            '<td style="color:var(--text-secondary);white-space:nowrap">' +
            AG.escapeHtml(sizeStr) +
            '</td>' +
            '<td style="color:var(--text-muted);font-size:12px;white-space:nowrap">' +
            AG.escapeHtml(item.modifiedAt) +
            '</td>' +
            '<td style="text-align:right;white-space:nowrap">' +
            (item.editable
              ? '<button type="button" class="icon-btn fm-edit-btn" title="Edit File" data-path="' +
                AG.escapeHtml(item.path) +
                '"><i class="fa-regular fa-pen-to-square"></i></button>'
              : '') +
            (item.isZip
              ? '<button type="button" class="icon-btn fm-unzip-btn" title="Extract ZIP" data-path="' +
                AG.escapeHtml(item.path) +
                '"><i class="fa-solid fa-box-open"></i></button>'
              : '') +
            '<a class="icon-btn" title="Download" href="/api/server/' +
            encodeURIComponent(uuid) +
            '/files/download?path=' +
            encodeURIComponent(item.path) +
            '"><i class="fa-solid fa-download"></i></a>' +
            '<button type="button" class="icon-btn fm-rename-btn" title="Rename" data-path="' +
            AG.escapeHtml(item.path) +
            '" data-name="' +
            AG.escapeHtml(item.name) +
            '"><i class="fa-solid fa-i-cursor"></i></button>' +
            '<button type="button" class="icon-btn fm-delete-btn" title="Delete" data-path="' +
            AG.escapeHtml(item.path) +
            '" data-name="' +
            AG.escapeHtml(item.name) +
            '" style="color:var(--status-red)"><i class="fa-regular fa-trash-can"></i></button>' +
            '</td></tr>'
          );
        })
        .join('');

      // Attach row events
      tbody.querySelectorAll('.fm-row-check').forEach(function (chk) {
        chk.addEventListener('change', function () {
          const p = chk.getAttribute('data-path');
          if (chk.checked) selectedPaths.add(p);
          else selectedPaths.delete(p);
          updateBulkBar();
        });
      });

      tbody.querySelectorAll('.fm-open-item').forEach(function (btn) {
        btn.addEventListener('click', function () {
          const p = btn.getAttribute('data-path');
          const isDir = btn.getAttribute('data-isdir') === '1';
          const editable = btn.getAttribute('data-editable') === '1';
          if (isDir) {
            loadDirectory(p);
          } else if (editable) {
            openEditor(p);
          } else {
            window.location.href =
              '/api/server/' + encodeURIComponent(uuid) + '/files/download?path=' + encodeURIComponent(p);
          }
        });
      });

      tbody.querySelectorAll('.fm-edit-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          openEditor(btn.getAttribute('data-path'));
        });
      });

      tbody.querySelectorAll('.fm-unzip-btn').forEach(function (btn) {
        btn.addEventListener('click', async function () {
          const p = btn.getAttribute('data-path');
          const ok = await AG.confirmModal({
            title: 'Extract ZIP Archive',
            message: 'Extract "' + p + '" into the current directory?',
            confirmText: 'Extract Archive'
          });
          if (!ok) return;
          try {
            const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/unzip', {
              method: 'POST',
              body: { path: p, targetPath: currentPath }
            });
            AG.toast(res.message, 'success');
            loadDirectory(currentPath);
          } catch (err) {
            AG.toast(err.message, 'error');
          }
        });
      });

      tbody.querySelectorAll('.fm-rename-btn').forEach(function (btn) {
        btn.addEventListener('click', async function () {
          const p = btn.getAttribute('data-path');
          const curName = btn.getAttribute('data-name');
          const newName = await AG.confirmModal({
            title: 'Rename Item',
            message: 'Enter a new name for "' + curName + '":',
            input: true,
            inputLabel: 'New Name',
            defaultValue: curName,
            confirmText: 'Rename'
          });
          if (!newName || newName.trim() === curName) return;
          try {
            const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/rename', {
              method: 'POST',
              body: { path: p, newName: newName.trim() }
            });
            AG.toast(res.message, 'success');
            loadDirectory(currentPath);
          } catch (err) {
            AG.toast(err.message, 'error');
          }
        });
      });

      tbody.querySelectorAll('.fm-delete-btn').forEach(function (btn) {
        btn.addEventListener('click', async function () {
          const p = btn.getAttribute('data-path');
          const name = btn.getAttribute('data-name');
          const ok = await AG.confirmModal({
            title: 'Delete "' + name + '"',
            message: 'Permanently delete "' + name + '"? This action cannot be undone.',
            confirmText: 'Delete',
            danger: true
          });
          if (!ok) return;
          try {
            const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/delete', {
              method: 'POST',
              body: { paths: [p] }
            });
            selectedPaths.delete(p);
            AG.toast(res.message, 'success');
            loadDirectory(currentPath);
          } catch (err) {
            AG.toast(err.message, 'error');
          }
        });
      });
    }

    async function loadDirectory(relPath) {
      try {
        const res = await AG.api(
          '/api/server/' + encodeURIComponent(uuid) + '/files/list?path=' + encodeURIComponent(relPath || '')
        );
        currentPath = res.data.currentPath || '';
        currentItems = res.data.items || [];
        selectedPaths.clear();
        renderTable();
      } catch (err) {
        AG.toast(err.message, 'error');
      }
    }

    if (backBtn) {
      backBtn.addEventListener('click', function () {
        if (!currentPath) return;
        const parts = currentPath.split('/').filter(Boolean);
        parts.pop();
        loadDirectory(parts.join('/'));
      });
    }

    if (selectAllBtn) {
      selectAllBtn.addEventListener('click', function () {
        if (selectedPaths.size === currentItems.length) {
          selectedPaths.clear();
        } else {
          currentItems.forEach(function (item) {
            selectedPaths.add(item.path);
          });
        }
        renderTable();
      });
    }

    if (bulkClearBtn) {
      bulkClearBtn.addEventListener('click', function () {
        selectedPaths.clear();
        renderTable();
      });
    }

    if (bulkDeleteBtn) {
      bulkDeleteBtn.addEventListener('click', async function () {
        const count = selectedPaths.size;
        if (count === 0) return;
        const ok = await AG.confirmModal({
          title: 'Delete Selected Items',
          message: 'Permanently delete ' + count + ' selected item(s)? This cannot be undone.',
          confirmText: 'Delete ' + count + ' Item(s)',
          danger: true
        });
        if (!ok) return;
        AG.setButtonLoading(bulkDeleteBtn, true, 'Deleting...');
        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/delete', {
            method: 'POST',
            body: { paths: Array.from(selectedPaths) }
          });
          selectedPaths.clear();
          AG.toast(res.message, 'success');
          loadDirectory(currentPath);
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          AG.setButtonLoading(bulkDeleteBtn, false);
        }
      });
    }

    if (bulkZipBtn) {
      bulkZipBtn.addEventListener('click', async function () {
        if (selectedPaths.size === 0) return;
        const zipName = await AG.confirmModal({
          title: 'Compress Selected Files (.zip)',
          message: 'Enter a filename for the new ZIP archive:',
          input: true,
          inputLabel: 'Archive Filename',
          defaultValue: 'server-files.zip',
          confirmText: 'Create ZIP'
        });
        if (!zipName) return;
        AG.setButtonLoading(bulkZipBtn, true, 'Zipping...');
        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/zip', {
            method: 'POST',
            body: {
              paths: Array.from(selectedPaths),
              currentPath: currentPath,
              archiveName: zipName
            }
          });
          selectedPaths.clear();
          AG.toast(res.message, 'success');
          loadDirectory(currentPath);
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          AG.setButtonLoading(bulkZipBtn, false);
        }
      });
    }

    if (bulkDownloadBtn) {
      bulkDownloadBtn.addEventListener('click', function () {
        if (selectedPaths.size === 0) return;
        const arr = Array.from(selectedPaths);
        if (arr.length === 1) {
          window.location.href =
            '/api/server/' + encodeURIComponent(uuid) + '/files/download?path=' + encodeURIComponent(arr[0]);
        } else {
          window.location.href =
            '/api/server/' +
            encodeURIComponent(uuid) +
            '/files/download?paths=' +
            encodeURIComponent(JSON.stringify(arr));
        }
      });
    }

    if (newFolderBtn) {
      newFolderBtn.addEventListener('click', async function () {
        const folderName = await AG.confirmModal({
          title: 'Create New Folder',
          message: 'Enter a folder name inside /' + currentPath + ':',
          input: true,
          inputLabel: 'Folder Name',
          placeholder: 'e.g. datapacks',
          confirmText: 'Create Folder'
        });
        if (!folderName) return;
        try {
          await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/mkdir', {
            method: 'POST',
            body: { parentPath: currentPath, name: folderName.trim() }
          });
          AG.toast('Folder created.', 'success');
          loadDirectory(currentPath);
        } catch (err) {
          AG.toast(err.message, 'error');
        }
      });
    }

    if (newFileBtn) {
      newFileBtn.addEventListener('click', async function () {
        const fileName = await AG.confirmModal({
          title: 'Create New File',
          message: 'Enter a filename inside /' + currentPath + ':',
          input: true,
          inputLabel: 'File Name',
          placeholder: 'e.g. config.yml',
          confirmText: 'Create & Edit'
        });
        if (!fileName) return;
        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/touch', {
            method: 'POST',
            body: { parentPath: currentPath, name: fileName.trim(), content: '' }
          });
          AG.toast('File created.', 'success');
          await loadDirectory(currentPath);
          if (res.data && res.data.path) {
            openEditor(res.data.path);
          }
        } catch (err) {
          AG.toast(err.message, 'error');
        }
      });
    }

    if (uploadBtn && uploadInput) {
      uploadBtn.addEventListener('click', function () {
        uploadInput.click();
      });

      uploadInput.addEventListener('change', async function () {
        if (!uploadInput.files || uploadInput.files.length === 0) return;
        const fd = new FormData();
        fd.append('path', currentPath);
        for (let i = 0; i < uploadInput.files.length; i++) {
          fd.append('files', uploadInput.files[i]);
        }

        if (uploadProgressWrap) uploadProgressWrap.style.display = 'block';
        AG.setButtonLoading(uploadBtn, true, 'Uploading...');
        try {
          const res = await AG.uploadWithProgress(
            '/api/server/' + encodeURIComponent(uuid) + '/files/upload',
            fd,
            function (pct) {
              if (uploadProgressBar) uploadProgressBar.style.width = pct + '%';
              if (uploadProgressText) uploadProgressText.textContent = 'Uploading... ' + pct + '%';
            }
          );
          AG.toast(res.message, 'success');
          loadDirectory(currentPath);
        } catch (err) {
          AG.toast(err.message, 'error');
        } finally {
          uploadInput.value = '';
          AG.setButtonLoading(uploadBtn, false);
          setTimeout(function () {
            if (uploadProgressWrap) uploadProgressWrap.style.display = 'none';
          }, 800);
        }
      });
    }

    // --- CODE / TEXT EDITOR ---

    function updateLineNumbers() {
      if (!editorTextarea || !editorGutter) return;
      const linesCount = editorTextarea.value.split('\n').length;
      const nums = [];
      for (let i = 1; i <= linesCount; i++) {
        nums.push(i);
      }
      editorGutter.textContent = nums.join('\n');
    }

    function setDirtyState(dirty) {
      isDirty = dirty;
      if (editorDirtyBadge) {
        editorDirtyBadge.style.display = dirty ? 'inline-flex' : 'none';
      }
    }

    async function openEditor(relPath) {
      try {
        const res = await AG.api(
          '/api/server/' + encodeURIComponent(uuid) + '/files/read?path=' + encodeURIComponent(relPath)
        );
        const f = res.data;
        editingPath = f.path;
        savedContent = f.content;
        editorTextarea.value = f.content;
        if (editorPathEl) editorPathEl.textContent = '/' + f.path;
        if (editorLangBadge) editorLangBadge.textContent = (f.extension || 'text').replace('.', '').toUpperCase();
        setDirtyState(false);
        updateLineNumbers();

        if (managerCard) managerCard.style.display = 'none';
        if (editorCard) editorCard.classList.add('open');
        editorTextarea.focus();
      } catch (err) {
        AG.toast(err.message, 'error');
      }
    }

    async function saveEditorFile() {
      if (!editingPath) return;
      AG.setButtonLoading(editorSaveBtn, true, 'Saving...');
      try {
        const content = editorTextarea.value;
        const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/files/write', {
          method: 'POST',
          body: { path: editingPath, content: content }
        });
        savedContent = content;
        setDirtyState(false);
        AG.toast(res.message, 'success');
      } catch (err) {
        AG.toast(err.message, 'error');
      } finally {
        AG.setButtonLoading(editorSaveBtn, false);
      }
    }

    async function closeEditor() {
      if (isDirty) {
        const discard = await AG.confirmModal({
          title: 'Unsaved Changes',
          message: 'You have unsaved edits in "' + editingPath + '". Discard your changes?',
          confirmText: 'Discard Changes',
          danger: true
        });
        if (!discard) return;
      }
      editingPath = null;
      setDirtyState(false);
      if (editorCard) editorCard.classList.remove('open');
      if (managerCard) managerCard.style.display = '';
      loadDirectory(currentPath);
    }

    if (editorTextarea) {
      editorTextarea.addEventListener('input', function () {
        updateLineNumbers();
        setDirtyState(editorTextarea.value !== savedContent);
      });

      editorTextarea.addEventListener('scroll', function () {
        if (editorGutter) editorGutter.scrollTop = editorTextarea.scrollTop;
      });

      editorTextarea.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
          e.preventDefault();
          saveEditorFile();
        } else if (e.key === 'Tab') {
          e.preventDefault();
          const start = editorTextarea.selectionStart;
          const end = editorTextarea.selectionEnd;
          editorTextarea.value =
            editorTextarea.value.substring(0, start) + '  ' + editorTextarea.value.substring(end);
          editorTextarea.selectionStart = editorTextarea.selectionEnd = start + 2;
          setDirtyState(editorTextarea.value !== savedContent);
        }
      });
    }

    if (editorFindBtn && editorSearchInput) {
      const findNext = function () {
        const term = editorSearchInput.value;
        if (!term || !editorTextarea) return;
        const text = editorTextarea.value.toLowerCase();
        const needle = term.toLowerCase();
        let idx = text.indexOf(needle, editorTextarea.selectionEnd);
        if (idx === -1) {
          idx = text.indexOf(needle, 0);
        }
        if (idx !== -1) {
          editorTextarea.focus();
          editorTextarea.setSelectionRange(idx, idx + term.length);
        } else {
          AG.toast('No match found for "' + term + '".', 'warning');
        }
      };
      editorFindBtn.addEventListener('click', findNext);
      editorSearchInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          findNext();
        }
      });
    }

    if (editorSaveBtn) editorSaveBtn.addEventListener('click', saveEditorFile);
    if (editorCloseBtn) editorCloseBtn.addEventListener('click', closeEditor);

    window.addEventListener('beforeunload', function (e) {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    });

    renderTable();
  });
})();
