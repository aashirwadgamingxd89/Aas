/* AashirwadGamerzz Panel v1.0.0 — Backup Manager Controller */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('backups-root');
    if (!root) return;

    const uuid = root.getAttribute('data-uuid');
    const createBtn = document.getElementById('backup-create-btn');
    const liveProgressBanner = document.getElementById('backup-live-banner');
    const liveProgressText = document.getElementById('backup-live-text');
    const liveProgressBar = document.getElementById('backup-live-bar');

    if (createBtn) {
      createBtn.addEventListener('click', async function () {
        const label = await AG.confirmModal({
          title: 'Create Server Backup',
          message: 'Archive the entire server directory into a compressed .tar.gz backup:',
          input: true,
          inputLabel: 'Backup Name (optional)',
          placeholder: 'Pre-update snapshot',
          confirmText: 'Create Backup'
        });
        if (label === null) return;

        AG.setButtonLoading(createBtn, true, 'Starting Backup...');
        try {
          const res = await AG.api('/api/server/' + encodeURIComponent(uuid) + '/backups', {
            method: 'POST',
            body: { name: label.trim() }
          });
          AG.toast(res.message, 'info');
          if (liveProgressBanner) liveProgressBanner.style.display = 'block';
        } catch (err) {
          AG.toast(err.message, 'error');
          AG.setButtonLoading(createBtn, false);
        }
      });
    }

    document.querySelectorAll('[data-backup-restore]').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        const id = btn.getAttribute('data-backup-restore');
        const name = btn.getAttribute('data-name') || 'backup';
        const ok = await AG.confirmModal({
          title: 'Restore Backup "' + name + '"',
          message:
            'WARNING: Restoring "' +
            name +
            '" will overwrite current files in the server directory! The server must be stopped.',
          confirmText: 'Restore Backup',
          danger: true
        });
        if (!ok) return;

        AG.setButtonLoading(btn, true, 'Restoring...');
        try {
          const res = await AG.api(
            '/api/server/' +
              encodeURIComponent(uuid) +
              '/backups/' +
              encodeURIComponent(id) +
              '/restore',
            { method: 'POST' }
          );
          AG.toast(res.message, 'success');
          setTimeout(function () {
            window.location.reload();
          }, 700);
        } catch (err) {
          AG.toast(err.message, 'error');
          AG.setButtonLoading(btn, false);
        }
      });
    });

    document.querySelectorAll('[data-backup-delete]').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        const id = btn.getAttribute('data-backup-delete');
        const name = btn.getAttribute('data-name') || 'backup';
        const ok = await AG.confirmModal({
          title: 'Delete Backup "' + name + '"',
          message: 'Permanently delete backup archive "' + name + '" from storage?',
          confirmText: 'Delete Backup',
          danger: true
        });
        if (!ok) return;

        AG.setButtonLoading(btn, true, '');
        try {
          const res = await AG.api(
            '/api/server/' + encodeURIComponent(uuid) + '/backups/' + encodeURIComponent(id),
            { method: 'DELETE' }
          );
          AG.toast(res.message, 'success');
          setTimeout(function () {
            window.location.reload();
          }, 500);
        } catch (err) {
          AG.toast(err.message, 'error');
          AG.setButtonLoading(btn, false);
        }
      });
    });

    function bindSocket() {
      if (!AG.socket) {
        setTimeout(bindSocket, 250);
        return;
      }
      AG.socket.emit('subscribe:server', uuid);
      AG.socket.on('backup:update', function (payload) {
        if (!payload || payload.uuid !== uuid) return;
        if (liveProgressBanner) liveProgressBanner.style.display = 'block';
        if (liveProgressText) liveProgressText.textContent = payload.message || 'Processing backup...';
        if (liveProgressBar && payload.percent != null) {
          liveProgressBar.style.width = Math.min(100, Math.max(5, Number(payload.percent))) + '%';
        }
        if (payload.status === 'completed' || payload.status === 'failed') {
          setTimeout(function () {
            window.location.reload();
          }, 900);
        }
      });
    }
    bindSocket();
  });
})();
