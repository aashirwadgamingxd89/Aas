# AashirwadGamerzz Minecraft Server Management Panel

**Panel Version:** `v1.0.0` | **Daemon Version:** `v1.0.0` | **Developer:** `AashirwadGamerzz`

A complete, production-ready, self-hosted **Minecraft Server Management Control Panel** and **Multi-Node Daemon** built with **Node.js, Express.js, EJS, SQLite (WAL), Socket.IO, and Vanilla HTML5/CSS3/JS**. Designed from the ground up to run smoothly on standard Linux hosts, unprivileged LXC/OpenVZ/Docker containers, and **PRoot VPS environments** — with zero dependency on Docker-in-Docker, `systemd`, KVM virtualization, or root privileges.

---

## Key Capabilities

### 1. Separated Panel + Multi-Node Daemon Architecture
- **Web Control Panel (`app.js`)**: Express + EJS + SQLite WAL + Socket.IO control plane managing users, RBAC (`user` / `admin`), server allocations, security audit trails, notifications, and real-time browser telemetry.
- **Standalone Daemon (`daemon/daemon.js`)**: Lightweight Node.js execution agent communicating with the Panel over token-authenticated REST (`X-Daemon-Token`) and Socket.IO streams. Supports both a co-located **Local Daemon Node** and unlimited **Remote Daemon Nodes**.
- **Container & PRoot Ready**: Reads cgroup v1/v2 memory limits when inside containers, inspects `/proc/<pid>` telemetry with graceful fallbacks, and spawns Java processes directly via `child_process.spawn(..., { shell: false })`.

### 2. Real Server Creation & Verified Upstream Installers
- Supports **Paper** (PaperMC Fill v3 API + SHA-256 verification), **Purpur** (Purpur v2 API), **Vanilla** (Mojang Piston Meta API + SHA-1 verification), **Fabric** (Fabric Meta v2 server launcher), and **Forge** (Installer `--installServer` execution).
- Automatic port allocation, node RAM/Disk capacity checks, `eula.txt` & `server.properties` provisioning, and real-time installation progress streamed over WebSockets.

### 3. Complete 9-Tab Server Control Plane
- **Overview**: Live CPU %, RAM usage, Online Players, Disk usage, Uptime, Copyable connection address, Recent Console tail, Server Information card, and 3 real-time HTML5 Canvas area charts (CPU, Memory, Disk).
- **Console**: Live streaming `stdout`/`stderr` terminal with ANSI color stripping/formatting, command history (`Up`/`Down`), Pause/Resume auto-scroll, Clear, and Start/Stop/Restart/Kill power controls.
- **File Manager & Code Editor**: Directory breadcrumbs, multi-select, create file/folder, upload with live progress bar, download, rename, delete, ZIP/Unzip archive extraction, and full in-browser code editor (`Ctrl+S` / `Cmd+S`, search, unsaved-changes guard).
- **Plugins & Real Marketplace**: Inspects `.jar` metadata (`plugin.yml`, `paper-plugin.yml`, `fabric.mod.json`), toggles `.jar` / `.jar.disabled`, uploads `.jar` files, and searches/installs real plugins live from **Modrinth v2** and **Hangar v1** with SHA-512 / SHA-256 verification.
- **Players**: Parses live online player state plus `ops.json`, `whitelist.json`, `banned-players.json`, and `usercache.json`, and dispatches real `kick`, `ban`, `pardon`, `whitelist`, `op`, and `deop` commands.
- **Worlds & World Installer**: Detects active `level-name` and valid `level.dat` directories, switches active worlds, creates/renames/downloads/deletes worlds, imports custom `.zip` worlds with strict **Zip-Slip** protection, and installs curated Modrinth worlds.
- **Backups**: Creates, restores, downloads, and deletes real `.zip` server archives with configurable per-server backup retention limits.
- **Startup Configuration**: Safe JVM startup flag builder + preset templates (Standard & Aikar's Flags) with command-injection validation, plus a structured + raw `server.properties` editor.
- **Settings**: Rename server, edit MOTD, view node/resource allocations, reinstall server software, or permanently delete via Danger Zone confirmation.

### 4. Dedicated Administrator Panel (`/admin`)
- **Admin Dashboard**: Host & node health overview, total users/servers, and recent security events.
- **User Management**: Create/edit/suspend/delete users, toggle `user`/`admin` roles, and set per-user Server, RAM, Disk, and CPU quotas.
- **Server Management**: Inspect every server across all users, adjust RAM/CPU/Disk/Port allocations, reassign nodes, suspend/unsuspend, or force-delete.
- **Daemon Nodes**: Add/edit/remove remote nodes, test live connectivity, inspect node JVM/hardware health, and rotate node authentication tokens.
- **System Diagnostics**: Live container/PRoot detection, Java JDK 21+ runtime probe, SQLite database metrics, and `/health` JSON endpoint.
- **Panel Settings & Audit Logs**: Persist global branding, registration policy, upload/backup limits, rate limits, and maintenance mode in SQLite, backed by searchable audit logs.

---

## Requirements

- **Node.js**: `v18.18.0+` (`v20 LTS` recommended)
- **Java Runtime**: **OpenJDK 21+** (`openjdk-21-jdk-headless` or `openjdk-21-jre-headless`) on each Daemon host running Minecraft 1.20.5+ / 1.21.x servers
- **Build Tools** (only if compiling `better-sqlite3` / `argon2` from source): `python3`, `make`, `g++`

Install OpenJDK 21 on Debian/Ubuntu:
```bash
sudo apt-get update && sudo apt-get install -y openjdk-21-jdk-headless
```

---

## Quick Start (Single Host — Panel + Local Daemon)

1. **Install dependencies:**
   ```bash
   cd minecraft-panel
   npm install
   ```
   *(On first run, `config/config.js` automatically generates `.env` with `0600` permissions and cryptographically random `SESSION_SECRET`, `CSRF_SECRET`, and `NODE_AUTH_SECRET` values if `.env` is absent.)*

2. **Verify system & Java 21+ readiness:**
   ```bash
   npm run check
   ```

3. **Run SQLite migrations:**
   ```bash
   npm run migrate
   ```

4. **Start both the Daemon and Web Panel together:**
   ```bash
   npm start
   ```
   - **Web Control Panel**: `http://0.0.0.0:8081`
   - **Local Daemon API**: `http://127.0.0.1:18081`

5. **Create your Administrator account:**
   - Open `http://localhost:8081/auth/register` in your browser.
   - **The very first registered account on a fresh database is automatically granted the `admin` role** (no hardcoded default passwords exist). Subsequent registrations receive the standard `user` role.

---

## Running Panel & Remote Daemon Separately (Multi-Node Setup)

1. Copy the repository onto your remote game host and install Node.js 20+ and OpenJDK 21+.
2. In your Web Panel, navigate to **Admin Panel → Daemon Nodes → Add Daemon Node**, enter the remote host IP/port (e.g., `18081`), and copy the generated 64-character token.
3. On the remote game host, configure `.env`:
   ```env
   DAEMON_HOST=0.0.0.0
   DAEMON_PORT=18081
   NODE_AUTH_SECRET=<paste-64-char-token-from-panel>
   ```
4. Start only the Daemon on the remote host:
   ```bash
   npm run daemon
   ```
5. Click **Test Connection** in **Admin Panel → Daemon Nodes** to verify live telemetry and Java readiness.

---

## Security Architecture

- **Password Hashing**: `argon2id` (`memoryCost: 19456`, `timeCost: 2`, `parallelism: 1`).
- **Session & CSRF Protection**: SQLite-backed `HttpOnly` sessions + HMAC-SHA256 per-session CSRF tokens validated on every state-mutating endpoint.
- **Filesystem & Archive Isolation**: `utils/pathGuard.js` enforces `fs.realpathSync` boundary checks per server UUID directory, blocks null bytes/traversal (`..`), rejects symlinks escaping the server root, and inspects every `.zip` entry before extraction to prevent **Zip-Slip** attacks.
- **Shell-Free Process Execution**: Java and installer processes are spawned exclusively via `child_process.spawn(binary, argsArray, { shell: false })` with strict JVM flag whitelisting/metacharacter rejection.
- **Authenticated Daemon API**: Every Panel ↔ Daemon HTTP request and Socket.IO handshake verifies `X-Daemon-Token` using constant-time comparison (`crypto.timingSafeEqual`).

---

## Project Layout

```text
minecraft-panel/
├── app.js                     # Express + Socket.IO Web Control Panel entrypoint
├── start-all.js               # Unified launcher (Local Daemon + Web Panel)
├── config/                    # Auto-initializing .env config & structured logger
├── daemon/                    # Standalone Daemon (monitor, installer, serverProcess, API)
├── database/                  # SQLite WAL connection, schema migrations, default seeds
├── middleware/                # Session store, RBAC, CSRF, rate limiting, safe error handler
├── public/                    # Self-hosted Font Awesome, brand SVG, CSS, Vanilla JS modules
├── routes/                    # 12 modular Express routers (auth, servers, files, admin, etc.)
├── scripts/                   # CLI migration & environment/Java diagnostic tools
├── services/                  # Business logic & multi-node Daemon event bridge
├── storage/                   # Runtime SQLite DB, server directories, backups, logs
└── views/                     # 33 EJS templates (partials, auth, user, server, admin)
```
