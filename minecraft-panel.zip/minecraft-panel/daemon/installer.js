'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { detectJavaRuntime } = require('../utils/systemCheck');

const USER_AGENT = 'AashirwadGamerzz-Panel/1.0.0 (Minecraft-Server-Management-Panel)';

const TRUSTED_HOSTS = new Set([
  'fill.papermc.io',
  'fill-data.papermc.io',
  'api.papermc.io',
  'api.purpurmc.org',
  'piston-meta.mojang.com',
  'piston-data.mojang.com',
  'launcher.mojang.com',
  'meta.fabricmc.net',
  'maven.fabricmc.net',
  'files.minecraftforge.net',
  'maven.minecraftforge.net'
]);

const versionCache = new Map();
const VERSION_CACHE_TTL_MS = 10 * 60 * 1000;

function assertTrustedUrl(urlStr) {
  const parsed = new URL(urlStr);
  if (parsed.protocol !== 'https:') {
    throw new Error(`Untrusted protocol "${parsed.protocol}" rejected.`);
  }
  if (!TRUSTED_HOSTS.has(parsed.hostname)) {
    throw new Error(`Untrusted download host "${parsed.hostname}" rejected.`);
  }
  return parsed.toString();
}

async function fetchJson(urlStr) {
  assertTrustedUrl(urlStr);
  const res = await fetch(urlStr, {
    headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
    signal: AbortSignal.timeout(20000)
  });
  if (!res.ok) {
    throw new Error(`Upstream API returned HTTP ${res.status} for ${urlStr}`);
  }
  return res.json();
}

async function getSupportedVersions(software) {
  const type = String(software || 'paper').toLowerCase();
  const cached = versionCache.get(type);
  if (cached && Date.now() - cached.fetchedAt < VERSION_CACHE_TTL_MS) {
    return cached.versions;
  }

  let versions = [];
  if (type === 'paper') {
    const data = await fetchJson('https://fill.papermc.io/v3/projects/paper');
    const grouped = data.versions || {};
    const all = [];
    for (const group of Object.values(grouped)) {
      if (Array.isArray(group)) {
        for (const v of group) {
          if (!v.includes('-rc') && !v.includes('-pre') && !v.includes('snapshot')) {
            all.push(v);
          }
        }
      }
    }
    versions = all;
  } else if (type === 'purpur') {
    const data = await fetchJson('https://api.purpurmc.org/v2/purpur');
    versions = Array.isArray(data.versions) ? [...data.versions].reverse() : [];
  } else if (type === 'vanilla') {
    const data = await fetchJson('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
    versions = (data.versions || [])
      .filter((v) => v.type === 'release')
      .map((v) => v.id);
  } else if (type === 'fabric') {
    const data = await fetchJson('https://meta.fabricmc.net/v2/versions/game');
    versions = (data || [])
      .filter((v) => v.stable)
      .map((v) => v.version);
  } else if (type === 'forge') {
    const data = await fetchJson(
      'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'
    );
    const promos = data.promos || {};
    const mcSet = new Set();
    for (const key of Object.keys(promos)) {
      const m = key.match(/^([0-9.]+)-(recommended|latest)$/);
      if (m) mcSet.add(m[1]);
    }
    versions = Array.from(mcSet).reverse();
  } else {
    throw new Error(`Unsupported server software: ${software}`);
  }

  versionCache.set(type, { versions, fetchedAt: Date.now() });
  return versions;
}

function requiredJavaMajorForMc(mcVersion) {
  const v = String(mcVersion || '').trim();
  // Minecraft 26.x and 1.20.5+ / 1.21.x require Java 21+
  if (/^2[6-9]\./.test(v)) return 21;
  const m = v.match(/^1\.(\d+)(?:\.(\d+))?/);
  if (!m) return 21;
  const minor = parseInt(m[1], 10);
  const patch = parseInt(m[2] || '0', 10);
  if (minor >= 21) return 21;
  if (minor === 20 && patch >= 5) return 21;
  if (minor >= 18) return 17;
  if (minor === 17) return 16;
  return 8;
}

async function resolveDownloadDescriptor(software, mcVersion) {
  const type = String(software || '').toLowerCase();
  const ver = String(mcVersion || '').trim();

  const supported = await getSupportedVersions(type);
  if (!supported.includes(ver)) {
    throw new Error(`Minecraft version "${ver}" is not available for ${type.toUpperCase()}.`);
  }

  if (type === 'paper') {
    const build = await fetchJson(
      `https://fill.papermc.io/v3/projects/paper/versions/${encodeURIComponent(ver)}/builds/latest`
    );
    const dl = build.downloads && build.downloads['server:default'];
    if (!dl || !dl.url) {
      throw new Error(`No Paper server JAR found for version ${ver}.`);
    }
    return {
      url: assertTrustedUrl(dl.url),
      expectedSha256: dl.checksums && dl.checksums.sha256 ? dl.checksums.sha256 : null,
      expectedSha1: null,
      expectedSize: dl.size || null,
      targetJar: 'server.jar',
      isForgeInstaller: false
    };
  }

  if (type === 'purpur') {
    const url = assertTrustedUrl(
      `https://api.purpurmc.org/v2/purpur/${encodeURIComponent(ver)}/latest/download`
    );
    return {
      url,
      expectedSha256: null,
      expectedSha1: null,
      expectedSize: null,
      targetJar: 'server.jar',
      isForgeInstaller: false
    };
  }

  if (type === 'vanilla') {
    const manifest = await fetchJson(
      'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'
    );
    const entry = (manifest.versions || []).find((v) => v.id === ver);
    if (!entry || !entry.url) {
      throw new Error(`Mojang manifest entry missing for version ${ver}.`);
    }
    const verData = await fetchJson(entry.url);
    const srv = verData.downloads && verData.downloads.server;
    if (!srv || !srv.url) {
      throw new Error(`Mojang server download unavailable for version ${ver}.`);
    }
    return {
      url: assertTrustedUrl(srv.url),
      expectedSha256: null,
      expectedSha1: srv.sha1 || null,
      expectedSize: srv.size || null,
      targetJar: 'server.jar',
      isForgeInstaller: false
    };
  }

  if (type === 'fabric') {
    const loaders = await fetchJson('https://meta.fabricmc.net/v2/versions/loader');
    const installers = await fetchJson('https://meta.fabricmc.net/v2/versions/installer');
    const stableLoader = (loaders.find((l) => l.stable) || loaders[0]);
    const stableInstaller = (installers.find((i) => i.stable) || installers[0]);
    if (!stableLoader || !stableInstaller) {
      throw new Error('Unable to resolve stable Fabric loader/installer metadata.');
    }
    const url = assertTrustedUrl(
      `https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(ver)}/${encodeURIComponent(
        stableLoader.version
      )}/${encodeURIComponent(stableInstaller.version)}/server/jar`
    );
    return {
      url,
      expectedSha256: null,
      expectedSha1: null,
      expectedSize: null,
      targetJar: 'server.jar',
      isForgeInstaller: false
    };
  }

  if (type === 'forge') {
    const data = await fetchJson(
      'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'
    );
    const promos = data.promos || {};
    const forgeBuild = promos[`${ver}-recommended`] || promos[`${ver}-latest`];
    if (!forgeBuild) {
      throw new Error(`No Forge build found for Minecraft ${ver}.`);
    }
    const fullVer = `${ver}-${forgeBuild}`;
    const url = assertTrustedUrl(
      `https://maven.minecraftforge.net/net/minecraftforge/forge/${fullVer}/forge-${fullVer}-installer.jar`
    );
    return {
      url,
      expectedSha256: null,
      expectedSha1: null,
      expectedSize: null,
      targetJar: 'forge-installer.jar',
      isForgeInstaller: true
    };
  }

  throw new Error(`Unsupported software type: ${software}`);
}

async function streamDownloadWithChecksum(url, destFile, { expectedSha256, expectedSha1, expectedSize }, onProgress) {
  assertTrustedUrl(url);
  const res = await fetch(url, {
    headers: { 'User-Agent': USER_AGENT },
    redirect: 'follow',
    signal: AbortSignal.timeout(300000)
  });

  if (!res.ok || !res.body) {
    throw new Error(`Download failed with HTTP ${res.status}`);
  }

  const totalBytes = parseInt(res.headers.get('content-length') || '0', 10) || expectedSize || 0;
  const tempFile = `${destFile}.part-${Date.now()}`;
  const fileStream = fs.createWriteStream(tempFile);
  const sha256Hash = expectedSha256 ? crypto.createHash('sha256') : null;
  const sha1Hash = expectedSha1 ? crypto.createHash('sha1') : null;

  let downloadedBytes = 0;
  let lastEmit = 0;

  try {
    for await (const chunk of res.body) {
      const buf = Buffer.from(chunk);
      downloadedBytes += buf.length;
      if (sha256Hash) sha256Hash.update(buf);
      if (sha1Hash) sha1Hash.update(buf);

      if (!fileStream.write(buf)) {
        await new Promise((resolve) => fileStream.once('drain', resolve));
      }

      const now = Date.now();
      if (onProgress && (now - lastEmit >= 250 || (totalBytes && downloadedBytes >= totalBytes))) {
        lastEmit = now;
        const percent = totalBytes > 0 ? Math.min(99, Math.round((downloadedBytes / totalBytes) * 100)) : null;
        onProgress({
          stage: 'downloading',
          downloadedBytes,
          totalBytes,
          percent,
          message: totalBytes > 0
            ? `Downloading server JAR (${(downloadedBytes / 1048576).toFixed(1)} / ${(totalBytes / 1048576).toFixed(1)} MB)`
            : `Downloading server JAR (${(downloadedBytes / 1048576).toFixed(1)} MB)`
        });
      }
    }

    await new Promise((resolve, reject) => {
      fileStream.end((err) => (err ? reject(err) : resolve()));
    });

    if (downloadedBytes < 1024) {
      throw new Error('Downloaded server binary is unexpectedly small or invalid.');
    }

    if (sha256Hash) {
      const actual = sha256Hash.digest('hex');
      if (actual.toLowerCase() !== expectedSha256.toLowerCase()) {
        throw new Error(`SHA-256 checksum mismatch (expected ${expectedSha256}, got ${actual}).`);
      }
    }

    if (sha1Hash) {
      const actual = sha1Hash.digest('hex');
      if (actual.toLowerCase() !== expectedSha1.toLowerCase()) {
        throw new Error(`SHA-1 checksum mismatch (expected ${expectedSha1}, got ${actual}).`);
      }
    }

    await fsp.rename(tempFile, destFile);
    return { downloadedBytes };
  } catch (err) {
    try {
      fileStream.destroy();
      if (fs.existsSync(tempFile)) await fsp.unlink(tempFile);
    } catch (_) {}
    throw err;
  }
}

function writeDefaultServerFiles(serverDir, { port = 25565, motd = 'A Minecraft Server', maxPlayers = 20 }) {
  fs.mkdirSync(serverDir, { recursive: true });
  fs.mkdirSync(path.join(serverDir, 'plugins'), { recursive: true });

  const eulaPath = path.join(serverDir, 'eula.txt');
  if (!fs.existsSync(eulaPath)) {
    fs.writeFileSync(
      eulaPath,
      `#Generated by AashirwadGamerzz Minecraft Server Management Panel v1.0.0\n#${new Date().toUTCString()}\neula=true\n`,
      'utf8'
    );
  }

  const propsPath = path.join(serverDir, 'server.properties');
  if (!fs.existsSync(propsPath)) {
    const defaultProps = [
      '#Minecraft server properties',
      `#${new Date().toUTCString()}`,
      `server-port=${port}`,
      `query.port=${port}`,
      `motd=${String(motd).replace(/[\r\n]/g, ' ')}`,
      `max-players=${maxPlayers}`,
      'view-distance=10',
      'simulation-distance=10',
      'gamemode=survival',
      'difficulty=easy',
      'spawn-protection=16',
      'op-permission-level=4',
      'max-build-height=256',
      'level-name=world',
      'level-seed=',
      'entity-broadcast-range-percentage=100',
      'online-mode=true',
      'pvp=true',
      'allow-flight=false',
      'enable-command-block=false',
      'allow-nether=true',
      'spawn-monsters=true',
      'spawn-animals=true',
      'spawn-npcs=true',
      'announce-player-achievements=true',
      'white-list=false',
      'enforce-secure-profile=false'
    ].join('\n') + '\n';
    fs.writeFileSync(propsPath, defaultProps, 'utf8');
  } else {
    // Ensure server-port matches assigned port
    let existing = fs.readFileSync(propsPath, 'utf8');
    if (/^server-port=/m.test(existing)) {
      existing = existing.replace(/^server-port=.*$/m, `server-port=${port}`);
    } else {
      existing += `\nserver-port=${port}\n`;
    }
    fs.writeFileSync(propsPath, existing, 'utf8');
  }
}

async function installServerSoftware({
  serverDir,
  software,
  mcVersion,
  port,
  motd,
  maxPlayers,
  onProgress
}) {
  const emit = (payload) => {
    if (typeof onProgress === 'function') onProgress(payload);
  };

  const reqJava = requiredJavaMajorForMc(mcVersion);
  const javaInfo = detectJavaRuntime();
  if (!javaInfo.available) {
    throw new Error('Java JDK runtime is missing on this node. Install OpenJDK 21+ to install/run servers.');
  }
  if (javaInfo.major < reqJava) {
    throw new Error(
      `Minecraft ${mcVersion} requires Java ${reqJava}+, but node currently has Java ${javaInfo.version}.`
    );
  }

  emit({
    stage: 'resolving',
    percent: 5,
    message: `Resolving ${software.toUpperCase()} ${mcVersion} metadata...`
  });

  const descriptor = await resolveDownloadDescriptor(software, mcVersion);
  fs.mkdirSync(serverDir, { recursive: true });

  const destFile = path.join(serverDir, descriptor.targetJar);
  await streamDownloadWithChecksum(descriptor.url, destFile, descriptor, emit);

  if (descriptor.isForgeInstaller) {
    emit({
      stage: 'installing_forge',
      percent: 85,
      message: 'Running Forge headless server installer...'
    });
    await new Promise((resolve, reject) => {
      const proc = spawn(javaInfo.binary, ['-jar', 'forge-installer.jar', '--installServer'], {
        cwd: serverDir,
        stdio: ['ignore', 'pipe', 'pipe']
      });
      proc.on('error', reject);
      proc.on('close', (code) => {
        if (code === 0) resolve();
        else reject(new Error(`Forge installer exited with code ${code}`));
      });
    });
    // Locate runnable jar if created
    const files = await fsp.readdir(serverDir);
    const forgeShim = files.find((f) => /^forge-.*-shim\.jar$/.test(f) || /^forge-.*-universal\.jar$/.test(f));
    if (forgeShim && !fs.existsSync(path.join(serverDir, 'server.jar'))) {
      await fsp.copyFile(path.join(serverDir, forgeShim), path.join(serverDir, 'server.jar'));
    }
  }

  writeDefaultServerFiles(serverDir, { port, motd, maxPlayers });

  emit({
    stage: 'completed',
    percent: 100,
    message: `Installed ${software.toUpperCase()} ${mcVersion} successfully.`
  });

  return {
    jarFile: 'server.jar',
    javaVersion: String(javaInfo.major)
  };
}

module.exports = {
  getSupportedVersions,
  requiredJavaMajorForMc,
  installServerSoftware,
  writeDefaultServerFiles
};
