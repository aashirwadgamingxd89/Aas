'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { EventEmitter } = require('events');
const { detectJavaRuntime } = require('../utils/systemCheck');
const { resolveSafePath } = require('../utils/pathGuard');
const { parseAndValidateStartupCommand, sanitizeConsoleCommand } = require('../utils/validators');
const { getProcessMetrics, clearProcessHistory, getDirectorySize } = require('./monitor');
const { requiredJavaMajorForMc, writeDefaultServerFiles } = require('./installer');

const MAX_CONSOLE_BUFFER = 600;

class ServerProcessRegistry extends EventEmitter {
  constructor(logger) {
    super();
    this.logger = logger;
    // uuid -> instance state
    this.instances = new Map();
  }

  _ensureRecord(uuid, serverDir = null) {
    let rec = this.instances.get(uuid);
    if (!rec) {
      rec = {
        uuid,
        serverDir,
        proc: null,
        pid: null,
        status: 'offline',
        startedAt: null,
        stopIntent: false,
        exitCode: null,
        consoleBuffer: [],
        onlinePlayers: new Map(), // username -> { username, uuid, joinedAt }
        pendingUuids: new Map(),  // username -> uuid
        ramLimitMb: 1024,
        diskLimitMb: 2048,
        cpuLimit: 1
      };
      this.instances.set(uuid, rec);
    } else if (serverDir) {
      rec.serverDir = serverDir;
    }
    return rec;
  }

  _appendConsole(rec, stream, rawLine) {
    const cleanLine = String(rawLine).replace(/\r$/, '');
    if (!cleanLine) return;
    const entry = {
      timestamp: new Date().toISOString(),
      stream,
      line: cleanLine
    };
    rec.consoleBuffer.push(entry);
    if (rec.consoleBuffer.length > MAX_CONSOLE_BUFFER) {
      rec.consoleBuffer.shift();
    }
    this.emit('console', { uuid: rec.uuid, ...entry });
    this._parseMinecraftLine(rec, cleanLine);
  }

  _parseMinecraftLine(rec, line) {
    // Detect server ready state: [Server thread/INFO]: Done (4.213s)! For help, type "help"
    if (rec.status === 'starting' && /Done\s*\([0-9.,]+s\)!\s*For help/i.test(line)) {
      rec.status = 'running';
      if (!rec.startedAt) rec.startedAt = Date.now();
      this.emit('status', {
        uuid: rec.uuid,
        status: 'running',
        pid: rec.pid,
        startedAt: new Date(rec.startedAt).toISOString()
      });
    }

    // Detect UUID of player: UUID of player Steve is 069a79f4-44e9-4726-a5be-fca90e38aaf5
    const uuidMatch = line.match(/UUID of player ([A-Za-z0-9_.\-]{1,32}) is ([0-9a-fA-F-]{32,36})/);
    if (uuidMatch) {
      rec.pendingUuids.set(uuidMatch[1], uuidMatch[2]);
    }

    // Detect player login / join
    const joinMatch =
      line.match(/:\s*([A-Za-z0-9_.\-]{1,32})\[\/[^\]]+\]\s+logged in with entity id/i) ||
      line.match(/:\s*([A-Za-z0-9_.\-]{1,32})\s+joined the game/i);
    if (joinMatch) {
      const username = joinMatch[1];
      if (!rec.onlinePlayers.has(username)) {
        const playerUuid = rec.pendingUuids.get(username) || '';
        const info = {
          username,
          uuid: playerUuid,
          joinedAt: new Date().toISOString()
        };
        rec.onlinePlayers.set(username, info);
        this.emit('player_join', {
          uuid: rec.uuid,
          player: info,
          playerCount: rec.onlinePlayers.size
        });
      }
    }

    // Detect player leave
    const leaveMatch =
      line.match(/:\s*([A-Za-z0-9_.\-]{1,32})\s+left the game/i) ||
      line.match(/:\s*([A-Za-z0-9_.\-]{1,32})\s+lost connection:/i);
    if (leaveMatch) {
      const username = leaveMatch[1];
      if (rec.onlinePlayers.has(username)) {
        rec.onlinePlayers.delete(username);
        this.emit('player_leave', {
          uuid: rec.uuid,
          username,
          playerCount: rec.onlinePlayers.size
        });
      }
    }
  }

  async start(cfg) {
    const {
      uuid,
      serverDir,
      startupCommand,
      ramLimitMb = 1024,
      diskLimitMb = 2048,
      cpuLimit = 1,
      mcVersion = '1.21.4',
      port = 25565,
      motd = 'A Minecraft Server',
      maxPlayers = 20
    } = cfg;

    const rec = this._ensureRecord(uuid, serverDir);
    if (rec.proc && (rec.status === 'running' || rec.status === 'starting' || rec.status === 'stopping')) {
      throw new Error(`Server is currently ${rec.status}.`);
    }

    if (!fs.existsSync(serverDir)) {
      throw new Error('Server directory does not exist on this node.');
    }

    // Enforce disk allocation limit before boot
    const disk = await getDirectorySize(serverDir, true);
    if (diskLimitMb > 0 && disk.mb > diskLimitMb) {
      throw new Error(
        `Disk limit exceeded (${disk.mb.toFixed(1)} MB used / ${diskLimitMb} MB allocated). Free up space before starting.`
      );
    }

    const javaInfo = detectJavaRuntime();
    if (!javaInfo.available || !javaInfo.binary) {
      throw new Error('Java JDK 21+ runtime was not found on this daemon node.');
    }

    const reqJava = requiredJavaMajorForMc(mcVersion);
    if (javaInfo.major < reqJava) {
      throw new Error(
        `Minecraft ${mcVersion} requires Java ${reqJava}+, but this node has Java ${javaInfo.version}.`
      );
    }

    const parsedCmd = parseAndValidateStartupCommand(startupCommand, ramLimitMb, 'server.jar');
    const jarArgIdx = parsedCmd.args.indexOf('-jar');
    const jarName = jarArgIdx !== -1 ? parsedCmd.args[jarArgIdx + 1] : 'server.jar';
    const jarPath = resolveSafePath(serverDir, jarName);

    if (!fs.existsSync(jarPath)) {
      throw new Error(
        `Minecraft JAR file "${jarName}" is missing in server directory. Reinstall server software or upload "${jarName}".`
      );
    }

    writeDefaultServerFiles(serverDir, { port, motd, maxPlayers });

    rec.ramLimitMb = ramLimitMb;
    rec.diskLimitMb = diskLimitMb;
    rec.cpuLimit = cpuLimit;
    rec.stopIntent = false;
    rec.exitCode = null;
    rec.onlinePlayers.clear();
    rec.status = 'starting';
    rec.startedAt = Date.now();

    this._appendConsole(
      rec,
      'daemon',
      `[AashirwadGamerzz Daemon] Starting server using Java ${javaInfo.version}: java ${parsedCmd.args.join(' ')}`
    );

    const safeEnv = {
      PATH: process.env.PATH || '/usr/local/bin:/usr/bin:/bin',
      HOME: serverDir,
      LANG: process.env.LANG || 'C.UTF-8',
      TERM: 'xterm-256color'
    };

    const child = spawn(javaInfo.binary, parsedCmd.args, {
      cwd: serverDir,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: safeEnv
    });

    rec.proc = child;
    rec.pid = child.pid;

    this.emit('status', {
      uuid,
      status: 'starting',
      pid: child.pid,
      startedAt: new Date(rec.startedAt).toISOString()
    });

    let stdoutRemainder = '';
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdoutRemainder += chunk;
      const lines = stdoutRemainder.split('\n');
      stdoutRemainder = lines.pop();
      for (const line of lines) {
        this._appendConsole(rec, 'stdout', line);
      }
    });

    let stderrRemainder = '';
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', (chunk) => {
      stderrRemainder += chunk;
      const lines = stderrRemainder.split('\n');
      stderrRemainder = lines.pop();
      for (const line of lines) {
        this._appendConsole(rec, 'stderr', line);
      }
    });

    child.on('error', (err) => {
      this.logger.error('serverProcess', `Failed to spawn JVM for ${uuid}`, { error: err.message });
      this._appendConsole(rec, 'stderr', `[AashirwadGamerzz Daemon] Process error: ${err.message}`);
    });

    child.on('close', (code, signal) => {
      if (stdoutRemainder) this._appendConsole(rec, 'stdout', stdoutRemainder);
      if (stderrRemainder) this._appendConsole(rec, 'stderr', stderrRemainder);

      const oldPid = rec.pid;
      clearProcessHistory(oldPid);
      rec.proc = null;
      rec.pid = null;
      rec.startedAt = null;
      rec.exitCode = code;
      rec.onlinePlayers.clear();

      const crashed = !rec.stopIntent && code !== 0;
      rec.status = crashed ? 'crashed' : 'offline';

      this._appendConsole(
        rec,
        'daemon',
        crashed
          ? `[AashirwadGamerzz Daemon] Server process exited unexpectedly (code=${code}, signal=${signal || 'none'}). Marked as CRASHED.`
          : `[AashirwadGamerzz Daemon] Server stopped cleanly (code=${code ?? 0}).`
      );

      this.emit('status', {
        uuid,
        status: rec.status,
        pid: null,
        exitCode: code,
        signal: signal || null
      });

      if (crashed) {
        this.emit('crash', {
          uuid,
          exitCode: code,
          signal: signal || null
        });
      }
    });

    return {
      uuid,
      status: rec.status,
      pid: rec.pid
    };
  }

  async stop(uuid, timeoutMs = 20000) {
    const rec = this.instances.get(uuid);
    if (!rec || !rec.proc) {
      if (rec) rec.status = 'offline';
      return { uuid, status: 'offline' };
    }

    rec.stopIntent = true;
    rec.status = 'stopping';
    this.emit('status', { uuid, status: 'stopping', pid: rec.pid });
    this._appendConsole(rec, 'daemon', '[AashirwadGamerzz Daemon] Sending graceful stop signal to server...');

    await new Promise((resolve) => {
      let finished = false;
      const done = () => {
        if (finished) return;
        finished = true;
        clearTimeout(sigtermTimer);
        clearTimeout(sigkillTimer);
        resolve();
      };

      rec.proc.once('close', done);

      try {
        if (rec.proc.stdin && !rec.proc.stdin.destroyed) {
          rec.proc.stdin.write('save-all\nstop\n');
        } else {
          rec.proc.kill('SIGTERM');
        }
      } catch (_) {
        try {
          rec.proc.kill('SIGTERM');
        } catch (__) {}
      }

      const sigtermTimer = setTimeout(() => {
        if (!finished && rec.proc) {
          this._appendConsole(rec, 'daemon', '[AashirwadGamerzz Daemon] Graceful timeout elapsed; sending SIGTERM...');
          try {
            rec.proc.kill('SIGTERM');
          } catch (_) {}
        }
      }, timeoutMs);

      const sigkillTimer = setTimeout(() => {
        if (!finished && rec.proc) {
          this._appendConsole(rec, 'daemon', '[AashirwadGamerzz Daemon] Process unresponsive; sending SIGKILL...');
          try {
            rec.proc.kill('SIGKILL');
          } catch (_) {}
        }
      }, timeoutMs + 5000);
    });

    return { uuid, status: 'offline' };
  }

  async kill(uuid) {
    const rec = this.instances.get(uuid);
    if (!rec || !rec.proc) {
      if (rec) rec.status = 'offline';
      return { uuid, status: 'offline' };
    }

    rec.stopIntent = true;
    this._appendConsole(rec, 'daemon', '[AashirwadGamerzz Daemon] Force-killing server process (SIGKILL)...');
    await new Promise((resolve) => {
      rec.proc.once('close', () => resolve());
      try {
        rec.proc.kill('SIGKILL');
      } catch (_) {
        resolve();
      }
    });
    return { uuid, status: 'offline' };
  }

  async restart(cfg) {
    await this.stop(cfg.uuid);
    return this.start(cfg);
  }

  sendCommand(uuid, rawCommand) {
    const rec = this.instances.get(uuid);
    if (!rec || !rec.proc || (rec.status !== 'running' && rec.status !== 'starting')) {
      throw new Error('Server is offline. Start the server before sending console commands.');
    }
    const clean = sanitizeConsoleCommand(rawCommand);
    if (!rec.proc.stdin || rec.proc.stdin.destroyed) {
      throw new Error('Server stdin stream is unavailable.');
    }
    this._appendConsole(rec, 'command', `> ${clean}`);
    rec.proc.stdin.write(clean + '\n');
    return { sent: clean };
  }

  getLogs(uuid) {
    const rec = this.instances.get(uuid);
    if (!rec) return [];
    return rec.consoleBuffer;
  }

  async getTelemetry(uuid, serverDir, ramLimitMb = 1024, diskLimitMb = 2048) {
    const rec = this.instances.get(uuid);
    const dirToMeasure = serverDir || (rec && rec.serverDir);
    const disk = dirToMeasure ? await getDirectorySize(dirToMeasure) : { bytes: 0, mb: 0 };

    if (!rec || !rec.proc || !rec.pid) {
      return {
        uuid,
        status: rec ? rec.status : 'offline',
        pid: null,
        cpuPercent: 0,
        memoryMb: 0,
        memoryBytes: 0,
        ramLimitMb,
        diskMb: disk.mb,
        diskBytes: disk.bytes,
        diskLimitMb,
        uptimeSeconds: 0,
        playerCount: 0,
        players: []
      };
    }

    const procStats = getProcessMetrics(rec.pid);
    const uptimeSeconds = rec.startedAt ? Math.max(0, Math.floor((Date.now() - rec.startedAt) / 1000)) : 0;

    return {
      uuid,
      status: rec.status,
      pid: rec.pid,
      cpuPercent: procStats.cpuPercent,
      memoryMb: procStats.memoryMb,
      memoryBytes: procStats.memoryBytes,
      ramLimitMb: rec.ramLimitMb || ramLimitMb,
      diskMb: disk.mb,
      diskBytes: disk.bytes,
      diskLimitMb: rec.diskLimitMb || diskLimitMb,
      uptimeSeconds,
      playerCount: rec.onlinePlayers.size,
      players: Array.from(rec.onlinePlayers.values())
    };
  }

  async shutdownAll() {
    const activeUuids = [];
    for (const [uuid, rec] of this.instances.entries()) {
      if (rec.proc) activeUuids.push(uuid);
    }
    await Promise.all(activeUuids.map((uuid) => this.stop(uuid, 8000)));
  }
}

module.exports = {
  ServerProcessRegistry
};
