'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const os = require('os');

// Per-PID CPU tick tracking: pid -> { procTicks, timeMs }
const pidCpuHistory = new Map();
// Directory size cache: dirPath -> { bytes, computedAt }
const dirSizeCache = new Map();

let clkTck = 100;
try {
  const { spawnSync } = require('child_process');
  const res = spawnSync('getconf', ['CLK_TCK'], { encoding: 'utf8', timeout: 1500 });
  if (res.status === 0 && res.stdout) {
    const parsed = parseInt(res.stdout.trim(), 10);
    if (parsed > 0) clkTck = parsed;
  }
} catch (_) {}

/**
 * Reads RSS memory and CPU % for a running PID using portable Linux /proc files.
 * Works inside Docker, LXC, unprivileged VPS containers, and proot environments.
 */
function getProcessMetrics(pid) {
  if (!pid || pid <= 0) {
    return { cpuPercent: 0, memoryBytes: 0, memoryMb: 0 };
  }

  let memoryBytes = 0;
  let cpuPercent = 0;

  try {
    const statusPath = `/proc/${pid}/status`;
    if (fs.existsSync(statusPath)) {
      const content = fs.readFileSync(statusPath, 'utf8');
      const rssMatch = content.match(/^VmRSS:\s*(\d+)\s*kB/m);
      if (rssMatch) {
        memoryBytes = parseInt(rssMatch[1], 10) * 1024;
      }
    }
  } catch (_) {}

  try {
    const statPath = `/proc/${pid}/stat`;
    if (fs.existsSync(statPath)) {
      const raw = fs.readFileSync(statPath, 'utf8');
      // comm field in /proc/pid/stat is enclosed in parentheses and may contain spaces
      const closeParen = raw.lastIndexOf(')');
      if (closeParen !== -1) {
        const fields = raw.slice(closeParen + 2).trim().split(/\s+/);
        // fields[11] = utime, fields[12] = stime, fields[13] = cutime, fields[14] = cstime
        const utime = parseInt(fields[11] || '0', 10);
        const stime = parseInt(fields[12] || '0', 10);
        const procTicks = utime + stime;
        const nowMs = Date.now();

        const prev = pidCpuHistory.get(pid);
        if (prev && nowMs > prev.timeMs) {
          const deltaTicks = Math.max(0, procTicks - prev.procTicks);
          const deltaSec = (nowMs - prev.timeMs) / 1000;
          const cpuSec = deltaTicks / clkTck;
          const cores = Math.max(1, (os.cpus() || []).length);
          // Normalize relative to 1 core = 100% or system total; standard hosting panel displays % of 1 core or capped to cores*100
          const rawPct = (cpuSec / deltaSec) * 100;
          cpuPercent = Math.max(0, Math.min(cores * 100, Number(rawPct.toFixed(1))));
        }
        pidCpuHistory.set(pid, { procTicks, timeMs: nowMs });
      }
    }
  } catch (_) {}

  return {
    cpuPercent,
    memoryBytes,
    memoryMb: Number((memoryBytes / 1048576).toFixed(2))
  };
}

function clearProcessHistory(pid) {
  if (pid) pidCpuHistory.delete(pid);
}

async function computeDirectoryBytes(dirPath, depth = 0) {
  if (depth > 16) return 0;
  let total = 0;
  let entries;
  try {
    entries = await fsp.readdir(dirPath, { withFileTypes: true });
  } catch (_) {
    return 0;
  }

  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue;
    const full = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      total += await computeDirectoryBytes(full, depth + 1);
    } else if (entry.isFile()) {
      try {
        const st = await fsp.lstat(full);
        total += st.size;
      } catch (_) {}
    }
  }
  return total;
}

async function getDirectorySize(dirPath, forceRefresh = false, ttlMs = 5000) {
  if (!dirPath || !fs.existsSync(dirPath)) {
    return { bytes: 0, mb: 0 };
  }
  const now = Date.now();
  const cached = dirSizeCache.get(dirPath);
  if (!forceRefresh && cached && now - cached.computedAt < ttlMs) {
    return { bytes: cached.bytes, mb: Number((cached.bytes / 1048576).toFixed(2)) };
  }
  const bytes = await computeDirectoryBytes(dirPath);
  dirSizeCache.set(dirPath, { bytes, computedAt: now });
  return { bytes, mb: Number((bytes / 1048576).toFixed(2)) };
}

module.exports = {
  getProcessMetrics,
  clearProcessHistory,
  getDirectorySize
};
