'use strict';

const http = require('http');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const express = require('express');
const { Server: SocketIOServer } = require('socket.io');
const config = require('../config/config');
const { createLogger } = require('../config/logger');
const { safeCompare } = require('../utils/cryptoUtils');
const { resolveSafePath } = require('../utils/pathGuard');
const {
  detectEnvironmentCapabilities,
  detectJavaRuntime,
  getHostMetrics
} = require('../utils/systemCheck');
const { ServerProcessRegistry } = require('./serverProcess');
const { getSupportedVersions, installServerSoftware } = require('./installer');

const daemonLogger = createLogger('daemon');

function createDaemonServer(options = {}) {
  const host = options.host || config.daemonHost;
  const port = options.port || config.daemonPort;
  const getExpectedToken = options.getExpectedToken || (() => process.env.NODE_AUTH_SECRET || config.nodeAuthSecret);

  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '2mb' }));

  const httpServer = http.createServer(app);
  const io = new SocketIOServer(httpServer, {
    serveClient: false,
    pingInterval: 15000,
    pingTimeout: 10000
  });

  const registry = new ServerProcessRegistry(daemonLogger);
  // uuid -> { status: 'installing'|'completed'|'failed', percent, message, error, updatedAt }
  const installStates = new Map();

  function verifyToken(provided) {
    const expected = getExpectedToken();
    return Boolean(expected && provided && safeCompare(String(provided), String(expected)));
  }

  // Authenticate all Daemon REST requests
  app.use((req, res, next) => {
    const token = req.headers['x-daemon-token'];
    if (!verifyToken(token)) {
      daemonLogger.warn('auth', 'Rejected unauthorized daemon API request', { ip: req.ip, path: req.path });
      return res.status(401).json({
        success: false,
        message: 'Unauthorized daemon request.',
        error: 'INVALID_DAEMON_TOKEN'
      });
    }
    next();
  });

  // Authenticate Panel <-> Daemon WebSocket bridge
  io.use((socket, next) => {
    const token =
      (socket.handshake.auth && socket.handshake.auth.token) ||
      socket.handshake.headers['x-daemon-token'];
    if (!verifyToken(token)) {
      return next(new Error('INVALID_DAEMON_TOKEN'));
    }
    next();
  });

  io.on('connection', (socket) => {
    daemonLogger.info('ws', 'Panel connected to Daemon event stream', { socketId: socket.id });
  });

  // Forward real-time process events to connected Panel instance(s)
  registry.on('console', (payload) => io.emit('server:console', payload));
  registry.on('status', (payload) => io.emit('server:status', payload));
  registry.on('player_join', (payload) => io.emit('server:player_join', payload));
  registry.on('player_leave', (payload) => io.emit('server:player_leave', payload));
  registry.on('crash', (payload) => io.emit('server:crash', payload));

  // Periodic real telemetry broadcast for active servers every 2 seconds
  const telemetryInterval = setInterval(async () => {
    try {
      for (const [uuid, rec] of registry.instances.entries()) {
        if (rec.proc || rec.status === 'starting' || rec.status === 'running' || rec.status === 'stopping') {
          const stats = await registry.getTelemetry(
            uuid,
            rec.serverDir,
            rec.ramLimitMb,
            rec.diskLimitMb
          );
          io.emit('server:metrics', stats);
        }
      }
    } catch (_) {}
  }, 2000);
  telemetryInterval.unref();

  // --- REST API ---

  app.get('/api/v1/health', (req, res) => {
    const envCaps = detectEnvironmentCapabilities();
    const java = detectJavaRuntime();
    const hostMetrics = getHostMetrics(config.serversDir);
    let runningCount = 0;
    for (const rec of registry.instances.values()) {
      if (rec.proc) runningCount++;
    }

    res.json({
      success: true,
      message: 'Daemon healthy',
      data: {
        daemonVersion: config.daemonVersion,
        developer: config.developer,
        status: 'online',
        environment: envCaps,
        java,
        metrics: hostMetrics,
        runningServers: runningCount,
        trackedServers: registry.instances.size,
        timestamp: new Date().toISOString()
      }
    });
  });

  app.get('/api/v1/software/:type/versions', async (req, res) => {
    try {
      const versions = await getSupportedVersions(req.params.type);
      res.json({ success: true, message: 'Versions loaded', data: { versions } });
    } catch (err) {
      res.status(400).json({ success: false, message: err.message, error: 'SOFTWARE_VERSIONS_ERROR' });
    }
  });

  app.post('/api/v1/servers/:uuid/install', async (req, res) => {
    const { uuid } = req.params;
    const { software, mcVersion, port, motd, maxPlayers, serverDir } = req.body || {};

    try {
      const safeDir = serverDir
        ? resolveSafePath(config.serversDir, path.basename(serverDir))
        : resolveSafePath(config.serversDir, uuid);

      const rec = registry.instances.get(uuid);
      if (rec && rec.proc) {
        return res.status(409).json({
          success: false,
          message: 'Stop the server before reinstalling.',
          error: 'SERVER_RUNNING'
        });
      }

      installStates.set(uuid, {
        status: 'installing',
        percent: 0,
        message: 'Starting server installation...',
        error: null,
        updatedAt: Date.now()
      });

      io.emit('server:install_progress', {
        uuid,
        status: 'installing',
        percent: 1,
        message: 'Initializing installation on daemon node...'
      });

      // Kick off real asynchronous download & installation
      (async () => {
        try {
          const result = await installServerSoftware({
            serverDir: safeDir,
            software,
            mcVersion,
            port,
            motd,
            maxPlayers,
            onProgress: (prog) => {
              const state = {
                status: 'installing',
                percent: prog.percent ?? 50,
                downloadedBytes: prog.downloadedBytes || 0,
                totalBytes: prog.totalBytes || 0,
                message: prog.message || 'Installing...',
                error: null,
                updatedAt: Date.now()
              };
              installStates.set(uuid, state);
              io.emit('server:install_progress', { uuid, ...state });
            }
          });

          const doneState = {
            status: 'completed',
            percent: 100,
            message: `Successfully installed ${String(software).toUpperCase()} ${mcVersion}.`,
            javaVersion: result.javaVersion,
            error: null,
            updatedAt: Date.now()
          };
          installStates.set(uuid, doneState);
          io.emit('server:install_complete', { uuid, ...doneState });
          daemonLogger.info('install', `Installed ${software} ${mcVersion} for ${uuid}`);
        } catch (err) {
          const failState = {
            status: 'failed',
            percent: 0,
            message: err.message,
            error: err.message,
            updatedAt: Date.now()
          };
          installStates.set(uuid, failState);
          io.emit('server:install_failed', { uuid, ...failState });
          daemonLogger.error('install', `Installation failed for ${uuid}`, { error: err.message });
        }
      })();

      res.json({
        success: true,
        message: 'Installation started on daemon.',
        data: { uuid, serverDir: safeDir, status: 'installing' }
      });
    } catch (err) {
      res.status(400).json({ success: false, message: err.message, error: 'INSTALL_START_ERROR' });
    }
  });

  app.get('/api/v1/servers/:uuid/install-status', (req, res) => {
    const state = installStates.get(req.params.uuid) || null;
    res.json({ success: true, message: 'Install status', data: state });
  });

  app.post('/api/v1/servers/:uuid/power', async (req, res) => {
    const { uuid } = req.params;
    const { action, serverConfig = {} } = req.body || {};

    try {
      const safeDir = resolveSafePath(
        config.serversDir,
        serverConfig.serverDir ? path.basename(serverConfig.serverDir) : uuid
      );
      const cfg = { ...serverConfig, uuid, serverDir: safeDir };

      let result;
      if (action === 'start') {
        result = await registry.start(cfg);
      } else if (action === 'stop') {
        result = await registry.stop(uuid);
      } else if (action === 'restart') {
        result = await registry.restart(cfg);
      } else if (action === 'kill') {
        result = await registry.kill(uuid);
      } else {
        return res.status(400).json({
          success: false,
          message: `Invalid power action: ${action}`,
          error: 'INVALID_POWER_ACTION'
        });
      }

      daemonLogger.info('power', `Executed ${action} for server ${uuid}`, { status: result.status });
      res.json({ success: true, message: `Action "${action}" executed.`, data: result });
    } catch (err) {
      daemonLogger.warn('power', `Power action "${action}" failed for ${uuid}`, { error: err.message });
      res.status(400).json({ success: false, message: err.message, error: 'POWER_ACTION_FAILED' });
    }
  });

  app.post('/api/v1/servers/:uuid/command', (req, res) => {
    const { uuid } = req.params;
    const { command } = req.body || {};
    try {
      const out = registry.sendCommand(uuid, command);
      res.json({ success: true, message: 'Command dispatched.', data: out });
    } catch (err) {
      res.status(400).json({ success: false, message: err.message, error: 'COMMAND_ERROR' });
    }
  });

  app.get('/api/v1/servers/:uuid/logs', (req, res) => {
    const logs = registry.getLogs(req.params.uuid);
    res.json({ success: true, message: 'Console logs retrieved.', data: { logs } });
  });

  app.get('/api/v1/servers/:uuid/telemetry', async (req, res) => {
    const { uuid } = req.params;
    try {
      const safeDir = resolveSafePath(
        config.serversDir,
        req.query.dir ? path.basename(String(req.query.dir)) : uuid
      );
      const ramLimitMb = parseInt(req.query.ram || '1024', 10);
      const diskLimitMb = parseInt(req.query.disk || '2048', 10);
      const telemetry = await registry.getTelemetry(uuid, safeDir, ramLimitMb, diskLimitMb);
      res.json({ success: true, message: 'Telemetry retrieved.', data: telemetry });
    } catch (err) {
      res.status(400).json({ success: false, message: err.message, error: 'TELEMETRY_ERROR' });
    }
  });

  app.post('/api/v1/servers/telemetry-batch', async (req, res) => {
    const list = Array.isArray(req.body && req.body.servers) ? req.body.servers : [];
    const results = {};
    for (const item of list) {
      try {
        const safeDir = resolveSafePath(
          config.serversDir,
          item.dir ? path.basename(String(item.dir)) : item.uuid
        );
        results[item.uuid] = await registry.getTelemetry(
          item.uuid,
          safeDir,
          item.ramLimitMb || 1024,
          item.diskLimitMb || 2048
        );
      } catch (_) {}
    }
    res.json({ success: true, message: 'Batch telemetry retrieved.', data: { telemetry: results } });
  });

  app.delete('/api/v1/servers/:uuid', async (req, res) => {
    const { uuid } = req.params;
    try {
      await registry.stop(uuid, 6000);
      await registry.kill(uuid);
      registry.instances.delete(uuid);
      installStates.delete(uuid);

      const safeDir = resolveSafePath(config.serversDir, uuid);
      if (fs.existsSync(safeDir)) {
        await fsp.rm(safeDir, { recursive: true, force: true });
      }
      daemonLogger.info('server', `Deleted server directory for ${uuid}`);
      res.json({ success: true, message: 'Server resources removed from node.' });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message, error: 'SERVER_DELETE_ERROR' });
    }
  });

  async function start() {
    await new Promise((resolve, reject) => {
      httpServer.once('error', reject);
      httpServer.listen(port, host, () => {
        daemonLogger.info(
          'startup',
          `AashirwadGamerzz Daemon ${config.daemonVersion} listening on ${host}:${port}`
        );
        resolve();
      });
    });
    return { host, port };
  }

  async function shutdown() {
    daemonLogger.info('shutdown', 'Shutting down Daemon cleanly...');
    clearInterval(telemetryInterval);
    await registry.shutdownAll();
    await new Promise((resolve) => io.close(() => resolve()));
    await new Promise((resolve) => httpServer.close(() => resolve()));
    await daemonLogger.flush();
  }

  return { app, httpServer, io, registry, start, shutdown };
}

if (require.main === module) {
  const daemon = createDaemonServer();
  daemon.start().catch((err) => {
    daemonLogger.error('startup', 'Daemon failed to start', { error: err.message });
    process.exit(1);
  });

  let shuttingDown = false;
  const handleSignal = async (sig) => {
    if (shuttingDown) return;
    shuttingDown = true;
    daemonLogger.info('shutdown', `Received ${sig}`);
    await daemon.shutdown();
    process.exit(0);
  };
  process.on('SIGINT', () => handleSignal('SIGINT'));
  process.on('SIGTERM', () => handleSignal('SIGTERM'));
}

module.exports = { createDaemonServer };
