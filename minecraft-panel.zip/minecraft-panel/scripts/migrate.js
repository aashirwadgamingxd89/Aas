'use strict';

const { getDb, closeDb } = require('../database/database');

try {
  const db = getDb();
  const tables = db
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name ASC")
    .all()
    .map((r) => r.name);
  console.log('[AashirwadGamerzz Panel] SQLite migrations applied successfully.');
  console.log('[AashirwadGamerzz Panel] Active tables (' + tables.length + '):', tables.join(', '));
  closeDb();
  process.exit(0);
} catch (err) {
  console.error('[AashirwadGamerzz Panel] Migration error:', err.message);
  process.exit(1);
}
