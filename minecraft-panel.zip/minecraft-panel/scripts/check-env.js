'use strict';

const config = require('../config/config');
const {
  detectEnvironmentCapabilities,
  detectJavaRuntime,
  getHostMetrics
} = require('../utils/systemCheck');

const envCaps = detectEnvironmentCapabilities();
const javaInfo = detectJavaRuntime();
const metrics = getHostMetrics(config.serversDir);

console.log('==============================================================');
console.log(' AashirwadGamerzz Panel ' + config.panelVersion + ' — System Diagnostic');
console.log('==============================================================');
console.log('Developer         :', config.developer);
console.log('Node.js           : v' + envCaps.nodeVersion);
console.log('Platform / Arch   :', envCaps.platform + ' / ' + envCaps.arch + ' (' + envCaps.release + ')');
console.log('Container Runtime :', envCaps.containerRuntime + (envCaps.isProot ? ' [PRoot]' : ''));
console.log('/proc Telemetry   :', envCaps.procFsAvailable ? 'Available' : 'Fallback Mode');
console.log('Memory (Container):', metrics.memory.usedMb + ' / ' + metrics.memory.totalMb + ' MB');
console.log('Disk Capacity     :', metrics.disk.usedMb + ' / ' + metrics.disk.totalMb + ' MB');
console.log('Java Runtime      :', javaInfo.available ? 'JDK ' + javaInfo.version + ' (' + javaInfo.binary + ')' : 'NOT INSTALLED (Install OpenJDK 21+)');
console.log('==============================================================');

if (!javaInfo.available) {
  console.warn('[WARNING] Java JDK 21+ was not found on PATH. Minecraft servers require OpenJDK 21+ to start.');
}
