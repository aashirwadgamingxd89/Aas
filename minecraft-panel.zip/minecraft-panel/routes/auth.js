'use strict';

const express = require('express');
const crypto = require('crypto');
const argon2 = require('argon2');
const { getDb, getSetting } = require('../database/database');
const { logger } = require('../config/logger');
const {
  isValidUsername,
  isValidEmail,
  isValidPassword
} = require('../utils/validators');
const { requireAuth, guestOnly } = require('../middleware/auth');
const { loginRateLimiter, verifyCsrf } = require('../middleware/permissions');
const {
  createNotification,
  listNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification
} = require('../services/notificationService');
const { recordAudit } = require('../services/auditService');

const router = express.Router();

const AVATAR_COLORS = [
  '#7c3aed',
  '#2563eb',
  '#059669',
  '#d97706',
  '#dc2626',
  '#db2777',
  '#4f46e5'
];

function getTotalUsersCount() {
  const db = getDb();
  return db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
}

// --- LOGIN ---

router.get('/auth/login', guestOnly, (req, res) => {
  const isInitialSetup = getTotalUsersCount() === 0;
  res.render('auth/login', {
    pageTitle: 'Sign In',
    isInitialSetup,
    allowRegistration: isInitialSetup || getSetting('allow_registration', 'true') === 'true',
    error: null,
    formValues: {}
  });
});

router.post('/auth/login', guestOnly, loginRateLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const db = getDb();
    const identifier = String(req.body.identifier || '').trim();
    const password = String(req.body.password || '');
    const isInitialSetup = getTotalUsersCount() === 0;

    if (!identifier || !password) {
      return res.status(400).render('auth/login', {
        pageTitle: 'Sign In',
        isInitialSetup,
        allowRegistration: isInitialSetup || getSetting('allow_registration', 'true') === 'true',
        error: 'Enter your username/email and password.',
        formValues: { identifier }
      });
    }

    const user = db
      .prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1')
      .get(identifier, identifier);

    // Prevent timing oracle when user does not exist
    const dummyHash =
      '$argon2id$v=19$m=65536,t=3,p=4$c29tZXNhbHR2YWx1ZQ$RdescudvJCsgt3ub+b+dWRWJTmaaJObG';
    const validPassword = user
      ? await argon2.verify(user.password_hash, password).catch(() => false)
      : await argon2.verify(dummyHash, password).catch(() => false);

    if (!user || !validPassword) {
      recordAudit({
        username: identifier.slice(0, 48),
        action: 'auth.login',
        target: identifier.slice(0, 48),
        ip: req.ip,
        result: 'failed',
        details: 'Invalid credentials'
      });

      return res.status(401).render('auth/login', {
        pageTitle: 'Sign In',
        isInitialSetup,
        allowRegistration: isInitialSetup || getSetting('allow_registration', 'true') === 'true',
        error: 'Invalid username/email or password.',
        formValues: { identifier }
      });
    }

    if (user.status !== 'active') {
      recordAudit({
        userId: user.id,
        username: user.username,
        action: 'auth.login',
        target: user.username,
        ip: req.ip,
        result: 'denied',
        details: 'Account disabled'
      });

      return res.status(403).render('auth/login', {
        pageTitle: 'Sign In',
        isInitialSetup: false,
        allowRegistration: getSetting('allow_registration', 'true') === 'true',
        error: 'Your account has been disabled by an administrator.',
        formValues: { identifier }
      });
    }

    db.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?").run(user.id);

    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = user.id;
      req.session.csrfNonce = crypto.randomBytes(16).toString('hex');
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        recordAudit({
          userId: user.id,
          username: user.username,
          action: 'auth.login',
          target: user.username,
          ip: req.ip,
          result: 'success'
        });
        res.redirect('/dashboard');
      });
    });
  } catch (err) {
    next(err);
  }
});

// --- REGISTER ---

router.get('/auth/register', guestOnly, (req, res) => {
  const isInitialSetup = getTotalUsersCount() === 0;
  const allowRegistration = isInitialSetup || getSetting('allow_registration', 'true') === 'true';

  res.render('auth/register', {
    pageTitle: isInitialSetup ? 'Initial Administrator Setup' : 'Create Account',
    isInitialSetup,
    allowRegistration,
    error: null,
    formValues: {}
  });
});

router.post('/auth/register', guestOnly, loginRateLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const db = getDb();
    const userCount = getTotalUsersCount();
    const isInitialSetup = userCount === 0;
    const allowRegistration = isInitialSetup || getSetting('allow_registration', 'true') === 'true';

    if (!allowRegistration) {
      return res.status(403).render('auth/register', {
        pageTitle: 'Registration Closed',
        isInitialSetup: false,
        allowRegistration: false,
        error: 'Public account registration is currently disabled by the administrator.',
        formValues: {}
      });
    }

    const username = String(req.body.username || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const displayName = String(req.body.display_name || username).trim().slice(0, 48);
    const password = String(req.body.password || '');
    const confirmPassword = String(req.body.confirm_password || '');

    const renderErr = (msg) =>
      res.status(400).render('auth/register', {
        pageTitle: isInitialSetup ? 'Initial Administrator Setup' : 'Create Account',
        isInitialSetup,
        allowRegistration,
        error: msg,
        formValues: { username, email, display_name: displayName }
      });

    if (!isValidUsername(username)) {
      return renderErr('Username must be 3–32 characters (letters, numbers, _, ., -).');
    }
    if (!isValidEmail(email)) {
      return renderErr('Please enter a valid email address.');
    }
    if (!isValidPassword(password)) {
      return renderErr('Password must be between 8 and 128 characters.');
    }
    if (password !== confirmPassword) {
      return renderErr('Passwords do not match.');
    }

    const existing = db
      .prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1')
      .get(username, email);
    if (existing) {
      return renderErr('Username or email is already registered.');
    }

    const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
    const assignedRole = isInitialSetup ? 'admin' : 'user';
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

    const maxServers = isInitialSetup ? 50 : 5;
    const maxRamMb = isInitialSetup ? 65536 : 4096;
    const maxDiskMb = isInitialSetup ? 262144 : 10240;
    const maxCpuCores = isInitialSetup ? 32 : 4;

    const result = db
      .prepare(`
        INSERT INTO users (
          username, email, password_hash, display_name, role, status,
          avatar_color, max_servers, max_ram_mb, max_disk_mb, max_cpu_cores,
          created_at, last_login
        ) VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `)
      .run(
        username,
        email,
        passwordHash,
        displayName || username,
        assignedRole,
        color,
        maxServers,
        maxRamMb,
        maxDiskMb,
        maxCpuCores
      );

    const newUserId = result.lastInsertRowid;

    createNotification({
      userId: newUserId,
      type: 'info',
      title: isInitialSetup ? 'Administrator Account Initialized' : 'Welcome to AashirwadGamerzz Panel',
      message: isInitialSetup
        ? 'Your primary administrator account is active. You have full access to both the User Panel and Admin Panel.'
        : 'Your hosting control panel account has been created successfully.'
    });

    recordAudit({
      userId: newUserId,
      username,
      action: isInitialSetup ? 'auth.initial_admin_setup' : 'auth.register',
      target: username,
      ip: req.ip,
      result: 'success',
      details: { role: assignedRole }
    });

    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = newUserId;
      req.session.csrfNonce = crypto.randomBytes(16).toString('hex');
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        res.redirect('/dashboard');
      });
    });
  } catch (err) {
    next(err);
  }
});

// --- FORGOT & RESET PASSWORD ---

router.get('/auth/forgot-password', guestOnly, (req, res) => {
  res.render('auth/forgot-password', {
    pageTitle: 'Forgot Password',
    submitted: false,
    error: null
  });
});

router.post('/auth/forgot-password', guestOnly, loginRateLimiter, verifyCsrf, (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!isValidEmail(email)) {
    return res.status(400).render('auth/forgot-password', {
      pageTitle: 'Forgot Password',
      submitted: false,
      error: 'Please enter a valid email address.'
    });
  }

  const db = getDb();
  const user = db.prepare('SELECT id, username, email FROM users WHERE email = ?').get(email);
  if (user) {
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const expiresAt = Date.now() + 30 * 60 * 1000; // 30 minutes

    db.prepare(`
      INSERT INTO password_resets (user_id, token_hash, expires_at, used, created_at)
      VALUES (?, ?, ?, 0, datetime('now'))
    `).run(user.id, tokenHash, expiresAt);

    logger.info('auth', `Password reset requested for user ${user.username}. Reset path: /auth/reset-password/${rawToken}`);
    recordAudit({
      userId: user.id,
      username: user.username,
      action: 'auth.password_reset_request',
      target: user.email,
      ip: req.ip,
      result: 'success'
    });
  }

  res.render('auth/forgot-password', {
    pageTitle: 'Forgot Password',
    submitted: true,
    error: null
  });
});

router.get('/auth/reset-password/:token', guestOnly, (req, res) => {
  const rawToken = String(req.params.token || '');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const db = getDb();
  const resetRow = db
    .prepare('SELECT * FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > ?')
    .get(tokenHash, Date.now());

  res.render('auth/reset-password', {
    pageTitle: 'Reset Password',
    token: rawToken,
    validToken: Boolean(resetRow),
    error: resetRow ? null : 'This password reset link is invalid or has expired.'
  });
});

router.post('/auth/reset-password/:token', guestOnly, loginRateLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const rawToken = String(req.params.token || '');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const db = getDb();
    const resetRow = db
      .prepare('SELECT * FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > ?')
      .get(tokenHash, Date.now());

    if (!resetRow) {
      return res.status(400).render('auth/reset-password', {
        pageTitle: 'Reset Password',
        token: rawToken,
        validToken: false,
        error: 'This password reset link is invalid or has expired.'
      });
    }

    const password = String(req.body.password || '');
    const confirmPassword = String(req.body.confirm_password || '');
    if (!isValidPassword(password)) {
      return res.status(400).render('auth/reset-password', {
        pageTitle: 'Reset Password',
        token: rawToken,
        validToken: true,
        error: 'Password must be at least 8 characters.'
      });
    }
    if (password !== confirmPassword) {
      return res.status(400).render('auth/reset-password', {
        pageTitle: 'Reset Password',
        token: rawToken,
        validToken: true,
        error: 'Passwords do not match.'
      });
    }

    const hash = await argon2.hash(password, { type: argon2.argon2id });
    const tx = db.transaction(() => {
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, resetRow.user_id);
      db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(resetRow.id);
    });
    tx();

    const user = db.prepare('SELECT username FROM users WHERE id = ?').get(resetRow.user_id);
    recordAudit({
      userId: resetRow.user_id,
      username: user ? user.username : 'unknown',
      action: 'auth.password_reset_complete',
      target: user ? user.username : '',
      ip: req.ip,
      result: 'success'
    });

    res.redirect('/auth/login');
  } catch (err) {
    next(err);
  }
});

// --- PROFILE ---

router.get('/profile', requireAuth, (req, res) => {
  res.render('user/profile', {
    pageTitle: 'My Profile',
    avatarColors: AVATAR_COLORS
  });
});

router.post('/api/profile', requireAuth, verifyCsrf, (req, res) => {
  const db = getDb();
  const displayName = String(req.body.display_name || '').trim().slice(0, 48);
  const email = String(req.body.email || '').trim().toLowerCase();
  const avatarColor = AVATAR_COLORS.includes(req.body.avatar_color)
    ? req.body.avatar_color
    : req.user.avatar_color;

  if (!displayName || displayName.length < 2) {
    return res.status(400).json({
      success: false,
      message: 'Display name must be at least 2 characters.',
      error: 'VALIDATION_ERROR'
    });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({
      success: false,
      message: 'Please provide a valid email address.',
      error: 'VALIDATION_ERROR'
    });
  }

  const emailConflict = db
    .prepare('SELECT id FROM users WHERE email = ? AND id != ?')
    .get(email, req.user.id);
  if (emailConflict) {
    return res.status(409).json({
      success: false,
      message: 'Email address is already in use by another account.',
      error: 'EMAIL_CONFLICT'
    });
  }

  db.prepare('UPDATE users SET display_name = ?, email = ?, avatar_color = ? WHERE id = ?').run(
    displayName,
    email,
    avatarColor,
    req.user.id
  );

  recordAudit({
    userId: req.user.id,
    username: req.user.username,
    action: 'user.profile_update',
    target: req.user.username,
    ip: req.ip,
    result: 'success'
  });

  res.json({ success: true, message: 'Profile updated successfully.' });
});

router.post('/api/profile/password', requireAuth, verifyCsrf, async (req, res, next) => {
  try {
    const db = getDb();
    const currentPassword = String(req.body.current_password || '');
    const newPassword = String(req.body.new_password || '');
    const confirmPassword = String(req.body.confirm_password || '');

    if (!isValidPassword(newPassword)) {
      return res.status(400).json({
        success: false,
        message: 'New password must be between 8 and 128 characters.',
        error: 'VALIDATION_ERROR'
      });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'New passwords do not match.',
        error: 'VALIDATION_ERROR'
      });
    }

    const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
    const matches = await argon2.verify(row.password_hash, currentPassword).catch(() => false);
    if (!matches) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect.',
        error: 'INVALID_PASSWORD'
      });
    }

    const newHash = await argon2.hash(newPassword, { type: argon2.argon2id });
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, req.user.id);

    createNotification({
      userId: req.user.id,
      type: 'warning',
      title: 'Password Changed',
      message: 'Your account password was changed successfully.'
    });

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'user.password_change',
      target: req.user.username,
      ip: req.ip,
      result: 'success'
    });

    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err) {
    next(err);
  }
});

// --- NOTIFICATIONS ---

router.get('/notifications', requireAuth, (req, res) => {
  const notifications = listNotifications(req.user.id, 100);
  res.render('user/notifications', {
    pageTitle: 'Notifications',
    notifications
  });
});

router.post('/api/notifications/:id/read', requireAuth, verifyCsrf, (req, res) => {
  const unreadCount = markAsRead(req.user.id, parseInt(req.params.id, 10));
  res.json({ success: true, message: 'Notification marked read.', data: { unreadCount } });
});

router.post('/api/notifications/read-all', requireAuth, verifyCsrf, (req, res) => {
  markAllAsRead(req.user.id);
  res.json({ success: true, message: 'All notifications marked read.', data: { unreadCount: 0 } });
});

router.delete('/api/notifications/:id', requireAuth, verifyCsrf, (req, res) => {
  const unreadCount = deleteNotification(req.user.id, parseInt(req.params.id, 10));
  res.json({ success: true, message: 'Notification deleted.', data: { unreadCount } });
});

// --- LOGOUT ---

router.post('/auth/logout', requireAuth, verifyCsrf, (req, res) => {
  const username = req.user.username;
  const userId = req.user.id;
  req.session.destroy(() => {
    res.clearCookie('ag_panel_sid');
    recordAudit({
      userId,
      username,
      action: 'auth.logout',
      target: username,
      ip: req.ip,
      result: 'success'
    });
    res.redirect('/auth/login');
  });
});

module.exports = router;
