'use strict';

const express = require('express');
const { getSetting } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const {
  listBackups,
  createServerBackup,
  restoreServerBackup,
  deleteServerBackup,
  getBackupDownloadPath
} = require('../services/backupService');

const router = express.Router();

router.get('/server/:uuid/backups', requireAuth, requireServerAccess, (req, res) => {
  const backups = listBackups(req.server);
  const maxBackups = parseInt(getSetting('max_backups_per_server', '10'), 10) || 10;
  res.render('server/backups', {
    pageTitle: `${req.server.name} — Backups`,
    serverTab: 'backups',
    backups,
    maxBackups
  });
});

router.post(
  '/api/server/:uuid/backups',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const backup = await createServerBackup(
        req.server,
        String(req.body.name || ''),
        req.user,
        req.ip
      );
      res.status(201).json({
        success: true,
        message: 'Backup creation started.',
        data: backup
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'BACKUP_CREATE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/backups/:backupId/restore',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const restored = await restoreServerBackup(
        req.server,
        parseInt(req.params.backupId, 10),
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Restored backup "${restored.name}" successfully.`,
        data: restored
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'BACKUP_RESTORE_ERROR'
      });
    }
  }
);

router.get(
  '/api/server/:uuid/backups/:backupId/download',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  (req, res) => {
    try {
      const { safePath, downloadName } = getBackupDownloadPath(
        req.server,
        parseInt(req.params.backupId, 10)
      );
      res.download(safePath, downloadName);
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'BACKUP_DOWNLOAD_ERROR'
      });
    }
  }
);

router.delete(
  '/api/server/:uuid/backups/:backupId',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const deleted = await deleteServerBackup(
        req.server,
        parseInt(req.params.backupId, 10),
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Deleted backup "${deleted.name}".`,
        data: deleted
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'BACKUP_DELETE_ERROR'
      });
    }
  }
);

module.exports = router;
