'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const config = require('../config/config');
const { getDb, getSetting } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const { resolveSafePath, sanitizeFilename } = require('../utils/pathGuard');
const { assertDiskQuotaAvailable } = require('../services/fileService');
const {
  getPluginFolderName,
  inspectPluginJar,
  listInstalledPlugins,
  searchMarketplace,
  installMarketplacePlugin,
  deleteInstalledPlugin
} = require('../services/pluginService');
const { createNotification } = require('../services/notificationService');
const { recordAudit } = require('../services/auditService');

const router = express.Router();

function createPluginUploader() {
  const maxMb = Math.max(1, parseInt(getSetting('max_upload_mb', String(config.maxUploadMb)), 10) || 256);
  return multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => cb(null, config.uploadsDir),
      filename: (req, file, cb) => cb(null, `plugin-${crypto.randomUUID()}.jar`)
    }),
    limits: { fileSize: maxMb * 1048576, files: 1 }
  });
}

router.get('/server/:uuid/plugins', requireAuth, requireServerAccess, async (req, res, next) => {
  try {
    const plugins = await listInstalledPlugins(req.server);
    res.render('server/plugins', {
      pageTitle: `${req.server.name} — Plugins`,
      serverTab: 'plugins',
      plugins,
      pluginFolder: getPluginFolderName(req.server)
    });
  } catch (err) {
    next(err);
  }
});

router.get(
  '/server/:uuid/plugins/marketplace',
  requireAuth,
  requireServerAccess,
  async (req, res, next) => {
    try {
      const initialSearch = await searchMarketplace(req.server, {
        query: String(req.query.q || ''),
        source: String(req.query.source || 'all'),
        limit: 20
      });
      res.render('server/marketplace', {
        pageTitle: `${req.server.name} — Plugin Marketplace`,
        serverTab: 'plugins',
        initialSearch,
        query: String(req.query.q || ''),
        source: String(req.query.source || 'all')
      });
    } catch (err) {
      next(err);
    }
  }
);

router.get(
  '/api/server/:uuid/plugins/search',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  async (req, res) => {
    try {
      const data = await searchMarketplace(req.server, {
        query: String(req.query.q || ''),
        source: String(req.query.source || 'all'),
        limit: parseInt(req.query.limit || '20', 10),
        offset: parseInt(req.query.offset || '0', 10)
      });
      res.json({ success: true, message: 'Marketplace results loaded.', data });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'MARKETPLACE_SEARCH_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/plugins/install',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const installed = await installMarketplacePlugin(
        req.server,
        {
          projectId: String(req.body.projectId || ''),
          source: String(req.body.source || 'MODRINTH')
        },
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Installed "${installed.pluginName}" (${installed.version}).`,
        data: installed
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'PLUGIN_INSTALL_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/plugins/upload',
  requireAuth,
  verifyCsrf,
  requireServerAccess,
  (req, res, next) => createPluginUploader().single('plugin')(req, res, next),
  async (req, res) => {
    const file = req.file;
    try {
      if (!file) {
        return res.status(400).json({
          success: false,
          message: 'Select a valid .jar plugin file to upload.',
          error: 'NO_FILE'
        });
      }

      const cleanName = sanitizeFilename(file.originalname);
      if (!cleanName.toLowerCase().endsWith('.jar')) {
        throw new Error('Only .jar plugin/mod files are allowed.');
      }

      await assertDiskQuotaAvailable(req.server, file.size);

      const folder = getPluginFolderName(req.server);
      const pluginsDir = resolveSafePath(req.server.server_dir, folder);
      await fsp.mkdir(pluginsDir, { recursive: true });
      const targetJar = resolveSafePath(pluginsDir, cleanName);
      await fsp.copyFile(file.path, targetJar);

      const meta = inspectPluginJar(targetJar);
      const db = getDb();
      db.prepare(`
        INSERT INTO plugins (
          server_id, plugin_name, version, author, description,
          file_name, file_size, source, installed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'upload', datetime('now'))
        ON CONFLICT(server_id, file_name) DO UPDATE SET
          plugin_name = excluded.plugin_name,
          version = excluded.version,
          author = excluded.author,
          description = excluded.description,
          file_size = excluded.file_size,
          source = 'upload',
          installed_at = datetime('now')
      `).run(
        req.server.id,
        meta.name,
        meta.version,
        meta.author,
        meta.description,
        cleanName,
        file.size
      );

      createNotification({
        userId: req.server.owner_id,
        serverId: req.server.id,
        type: 'success',
        title: 'Plugin Uploaded',
        message: `Uploaded "${meta.name}" (${cleanName}) to "${req.server.name}".`
      });

      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'plugin.upload',
        target: `${req.server.name}: ${cleanName}`,
        ip: req.ip,
        result: 'success'
      });

      res.json({
        success: true,
        message: `Uploaded plugin "${meta.name}".`,
        data: { pluginName: meta.name, fileName: cleanName }
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'PLUGIN_UPLOAD_ERROR'
      });
    } finally {
      try {
        if (file && file.path && fs.existsSync(file.path)) await fsp.unlink(file.path);
      } catch (_) {}
    }
  }
);

router.get(
  '/api/server/:uuid/plugins/:pluginId/download',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  (req, res) => {
    try {
      const db = getDb();
      const plugin = db
        .prepare('SELECT * FROM plugins WHERE id = ? AND server_id = ?')
        .get(parseInt(req.params.pluginId, 10), req.server.id);
      if (!plugin) {
        return res.status(404).json({
          success: false,
          message: 'Plugin not found.',
          error: 'NOT_FOUND'
        });
      }
      const folder = getPluginFolderName(req.server);
      const fullJar = resolveSafePath(path.join(req.server.server_dir, folder), plugin.file_name);
      if (!fs.existsSync(fullJar)) {
        return res.status(404).json({
          success: false,
          message: 'Plugin JAR file not found on disk.',
          error: 'FILE_MISSING'
        });
      }
      res.download(fullJar, plugin.file_name);
    } catch (err) {
      res.status(400).json({ success: false, message: err.message, error: 'DOWNLOAD_ERROR' });
    }
  }
);

router.delete(
  '/api/server/:uuid/plugins/:pluginId',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const deleted = await deleteInstalledPlugin(
        req.server,
        parseInt(req.params.pluginId, 10),
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Deleted plugin "${deleted.plugin_name}".`,
        data: deleted
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'PLUGIN_DELETE_ERROR'
      });
    }
  }
);

module.exports = router;
