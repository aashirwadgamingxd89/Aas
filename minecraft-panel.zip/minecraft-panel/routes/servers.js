'use strict';

const express = require('express');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const { daemonManager } = require('../services/daemonManager');
const {
  performPowerAction,
  sendServerCommand
} = require('../services/serverManager');
const { getHistoricalMetrics } = require('../services/metricsService');

const router = express.Router();

router.get('/server/:uuid', requireAuth, requireServerAccess, async (req, res, next) => {
  try {
    let logs = [];
    let installState = null;

    try {
      const logRes = await daemonManager.requestNode(
        req.server.node_id,
        'GET',
        `/api/v1/servers/${req.server.uuid}/logs`,
        null,
        5000
      );
      logs = (logRes && logRes.logs) || [];
    } catch (_) {}

    if (req.server.status === 'installing' || req.server.status === 'install_failed') {
      try {
        installState = await daemonManager.requestNode(
          req.server.node_id,
          'GET',
          `/api/v1/servers/${req.server.uuid}/install-status`,
          null,
          4000
        );
      } catch (_) {}
    }

    const metricsHistory = getHistoricalMetrics(req.server.id, 30);

    res.render('server/overview', {
      pageTitle: `${req.server.name} — Overview`,
      serverTab: 'overview',
      initialLogs: logs.slice(-120),
      metricsHistory,
      installState
    });
  } catch (err) {
    next(err);
  }
});

router.get('/server/:uuid/console', requireAuth, requireServerAccess, async (req, res, next) => {
  try {
    let logs = [];
    try {
      const logRes = await daemonManager.requestNode(
        req.server.node_id,
        'GET',
        `/api/v1/servers/${req.server.uuid}/logs`,
        null,
        5000
      );
      logs = (logRes && logRes.logs) || [];
    } catch (_) {}

    res.render('server/console', {
      pageTitle: `${req.server.name} — Console`,
      serverTab: 'console',
      initialLogs: logs
    });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/api/server/:uuid/power',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const action = String(req.body.action || '').toLowerCase();
      const result = await performPowerAction(req.server, action, req.user, req.ip);
      res.json({
        success: true,
        message: `Power action "${action}" dispatched.`,
        data: result
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'POWER_ACTION_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/command',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const out = await sendServerCommand(req.server, req.body.command);
      res.json({
        success: true,
        message: 'Command sent to server console.',
        data: out
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'CONSOLE_COMMAND_ERROR'
      });
    }
  }
);

router.get(
  '/api/server/:uuid/telemetry',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  async (req, res) => {
    try {
      let telemetry = req.server.telemetry;
      try {
        telemetry = await daemonManager.requestNode(
          req.server.node_id,
          'GET',
          `/api/v1/servers/${req.server.uuid}/telemetry?dir=${encodeURIComponent(
            req.server.uuid
          )}&ram=${req.server.ram_limit}&disk=${req.server.disk_limit}`,
          null,
          5000
        );
      } catch (_) {}

      let installState = null;
      if (req.server.status === 'installing') {
        try {
          installState = await daemonManager.requestNode(
            req.server.node_id,
            'GET',
            `/api/v1/servers/${req.server.uuid}/install-status`,
            null,
            4000
          );
        } catch (_) {}
      }

      res.json({
        success: true,
        message: 'Telemetry retrieved.',
        data: {
          serverStatus: req.server.status,
          telemetry,
          installState
        }
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'TELEMETRY_ERROR'
      });
    }
  }
);

module.exports = router;
