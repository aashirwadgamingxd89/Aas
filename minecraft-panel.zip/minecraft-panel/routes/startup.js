'use strict';

const express = require('express');
const { getDb } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const { parseAndValidateStartupCommand } = require('../utils/validators');
const {
  readServerProperties,
  writeServerProperties,
  getMcVersionCapabilities
} = require('../services/serverManager');
const { recordAudit } = require('../services/auditService');

const router = express.Router();

function buildStartupTemplates(ramLimitMb) {
  const minMem = Math.min(512, ramLimitMb);
  const aikarMem = Math.max(512, ramLimitMb);
  return {
    default: `java -Xms${minMem}M -Xmx${ramLimitMb}M -jar server.jar nogui`,
    aikars: `java -Xms${aikarMem}M -Xmx${aikarMem}M -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:+AlwaysPreTouch -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1 -jar server.jar nogui`
  };
}

router.get('/server/:uuid/startup', requireAuth, requireServerAccess, (req, res) => {
  const properties = readServerProperties(req.server);
  const capabilities = getMcVersionCapabilities(req.server.mc_version);
  const templates = buildStartupTemplates(req.server.ram_limit);

  res.render('server/startup', {
    pageTitle: `${req.server.name} — Startup`,
    serverTab: 'startup',
    properties,
    capabilities,
    templates
  });
});

router.post(
  '/api/server/:uuid/startup/command',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  (req, res) => {
    try {
      const parsed = parseAndValidateStartupCommand(
        String(req.body.startup_command || ''),
        req.server.ram_limit,
        'server.jar'
      );

      const db = getDb();
      db.prepare('UPDATE servers SET startup_command = ? WHERE id = ?').run(
        parsed.normalizedCommand,
        req.server.id
      );

      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'server.startup_command_update',
        target: `${req.server.name} (${req.server.uuid})`,
        ip: req.ip,
        result: 'success'
      });

      res.json({
        success: true,
        message: 'Startup command saved. Restart the server to apply.',
        data: { startupCommand: parsed.normalizedCommand }
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'STARTUP_COMMAND_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/startup/properties',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  (req, res) => {
    try {
      const updates = req.body.properties && typeof req.body.properties === 'object'
        ? req.body.properties
        : {};
      const updated = writeServerProperties(req.server, updates);

      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'server.properties_update',
        target: `${req.server.name} (${req.server.uuid})`,
        ip: req.ip,
        result: 'success'
      });

      res.json({
        success: true,
        message: 'Server properties updated in server.properties. Restart server to apply changes.',
        data: { properties: updated }
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'PROPERTIES_UPDATE_ERROR'
      });
    }
  }
);

module.exports = router;
