'use strict';

const express = require('express');
const config = require('../config/config');
const { getDb } = require('../database/database');
const { daemonManager } = require('../services/daemonManager');
const { detectJavaRuntime, detectEnvironmentCapabilities } = require('../utils/systemCheck');

const router = express.Router();

async function buildHealthReport() {
  let dbHealthy = false;
  let nodesSummary = { total: 0, online: 0, offline: 0 };

  try {
    const db = getDb();
    const ping = db.prepare('SELECT 1 AS ok').get();
    dbHealthy = Boolean(ping && ping.ok === 1);

    const nodes = db.prepare('SELECT id, status FROM nodes').all();
    nodesSummary.total = nodes.length;
    nodesSummary.online = nodes.filter((n) => n.status === 'online').length;
    nodesSummary.offline = nodes.length - nodesSummary.online;
  } catch (_) {
    dbHealthy = false;
  }

  // Trigger quick fresh check if all nodes look offline
  if (dbHealthy && nodesSummary.online === 0 && nodesSummary.total > 0) {
    try {
      const checks = await daemonManager.checkAllNodesHealth();
      nodesSummary.online = checks.filter((c) => c.status === 'online').length;
      nodesSummary.offline = nodesSummary.total - nodesSummary.online;
    } catch (_) {}
  }

  const java = detectJavaRuntime();
  const envCaps = detectEnvironmentCapabilities();

  const overallHealthy = dbHealthy && nodesSummary.online > 0;

  return {
    status: overallHealthy ? 'healthy' : 'degraded',
    panel: {
      status: 'online',
      version: config.panelVersion,
      developer: config.developer,
      uptimeSeconds: Math.floor(process.uptime())
    },
    database: {
      status: dbHealthy ? 'connected' : 'error',
      engine: 'SQLite'
    },
    daemon: {
      version: config.daemonVersion,
      connected: nodesSummary.online > 0,
      nodes: nodesSummary
    },
    java: {
      available: java.available,
      version: java.version || null,
      major: java.major || 0,
      java21Compatible: Boolean(java.isJava21Plus)
    },
    environment: {
      container: envCaps.isContainer,
      proot: envCaps.isProot,
      runtime: envCaps.containerRuntime
    },
    timestamp: new Date().toISOString()
  };
}

router.get(['/health', '/api/health'], async (req, res) => {
  const report = await buildHealthReport();
  const code = report.database.status === 'connected' ? 200 : 503;
  res.status(code).json({
    success: code === 200,
    message: report.status === 'healthy' ? 'All core systems operational' : 'System degraded',
    data: report
  });
});

module.exports = router;
