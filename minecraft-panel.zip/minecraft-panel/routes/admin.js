'use strict';

const fs = require('fs');
const argon2 = require('argon2');
const express = require('express');
const config = require('../config/config');
const { getDb, getPanelSettings, updatePanelSettings } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/admin');
const { verifyCsrf, apiRateLimiter } = require('../middleware/permissions');
const {
  isValidUsername,
  isValidEmail,
  isValidPassword,
  isValidPort,
  isValidHost,
  parseAndValidateStartupCommand
} = require('../utils/validators');
const { generateToken } = require('../utils/cryptoUtils');
const {
  detectEnvironmentCapabilities,
  detectJavaRuntime,
  getHostMetrics
} = require('../utils/systemCheck');
const { daemonManager } = require('../services/daemonManager');
const {
  enrichServerWithTelemetry,
  performPowerAction,
  deleteServer
} = require('../services/serverManager');
const { recordAudit, listAuditLogs } = require('../services/auditService');

const router = express.Router();

// Protect every route in /admin with authentication + admin role
router.use('/admin', requireAuth, requireAdmin);

// --- 1. ADMIN DASHBOARD ---

router.get('/admin', async (req, res, next) => {
  try {
    const db = getDb();
    const totalUsers = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
    const allServersRaw = db.prepare('SELECT * FROM servers ORDER BY id DESC').all();
    const servers = await Promise.all(allServersRaw.map((s) => enrichServerWithTelemetry(s)));

    let runningServers = 0;
    let offlineServers = 0;
    let totalAllocatedRamMb = 0;
    let totalActualDiskMb = 0;
    let totalAllocatedDiskMb = 0;

    for (const s of servers) {
      if (s.status === 'running' || s.status === 'starting') runningServers++;
      else offlineServers++;
      totalAllocatedRamMb += s.ram_limit || 0;
      totalAllocatedDiskMb += s.disk_limit || 0;
      totalActualDiskMb += (s.telemetry && s.telemetry.diskMb) || 0;
    }

    const nodes = db.prepare('SELECT * FROM nodes ORDER BY is_local DESC, id ASC').all();
    const onlineNodes = nodes.filter((n) => n.status === 'online').length;
    const offlineNodes = nodes.length - onlineNodes;

    const hostMetrics = getHostMetrics(config.serversDir);
    const javaInfo = detectJavaRuntime();
    const envCaps = detectEnvironmentCapabilities();
    const { rows: recentAudits } = listAuditLogs({ limit: 8, offset: 0 });

    res.render('admin/dashboard', {
      pageTitle: 'Admin Dashboard',
      adminTab: 'dashboard',
      stats: {
        totalUsers,
        totalServers: servers.length,
        runningServers,
        offlineServers,
        totalAllocatedRamMb,
        totalAllocatedDiskMb,
        totalActualDiskMb: Number(totalActualDiskMb.toFixed(2)),
        onlineNodes,
        offlineNodes,
        totalNodes: nodes.length
      },
      hostMetrics,
      javaInfo,
      envCaps,
      recentServers: servers.slice(0, 6),
      recentAudits
    });
  } catch (err) {
    next(err);
  }
});

// --- 2. USER MANAGEMENT ---

router.get('/admin/users', (req, res) => {
  const db = getDb();
  const users = db
    .prepare(`
      SELECT
        u.id, u.username, u.email, u.display_name, u.role, u.status,
        u.avatar_color, u.max_servers, u.max_ram_mb, u.max_disk_mb, u.max_cpu_cores,
        u.created_at, u.last_login,
        COUNT(s.id) AS server_count,
        COALESCE(SUM(s.ram_limit), 0) AS used_ram_mb
      FROM users u
      LEFT JOIN servers s ON s.owner_id = u.id
      GROUP BY u.id
      ORDER BY u.id ASC
    `)
    .all();

  res.render('admin/users', {
    pageTitle: 'Admin — Users',
    adminTab: 'users',
    users
  });
});

router.post('/admin/api/users', apiRateLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const db = getDb();
    const username = String(req.body.username || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const displayName = String(req.body.display_name || username).trim().slice(0, 48);
    const password = String(req.body.password || '');
    const role = req.body.role === 'admin' ? 'admin' : 'user';
    const maxServers = Math.max(0, parseInt(req.body.max_servers || '5', 10));
    const maxRamMb = Math.max(256, parseInt(req.body.max_ram_mb || '4096', 10));
    const maxDiskMb = Math.max(256, parseInt(req.body.max_disk_mb || '10240', 10));
    const maxCpuCores = Math.max(0.25, Number(req.body.max_cpu_cores || 4));

    if (!isValidUsername(username)) {
      return res.status(400).json({ success: false, message: 'Invalid username (3–32 chars).' });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ success: false, message: 'Invalid email address.' });
    }
    if (!isValidPassword(password)) {
      return res.status(400).json({ success: false, message: 'Password must be 8–128 characters.' });
    }

    const exists = db
      .prepare('SELECT id FROM users WHERE username = ? OR email = ?')
      .get(username, email);
    if (exists) {
      return res.status(409).json({ success: false, message: 'Username or email already exists.' });
    }

    const hash = await argon2.hash(password, { type: argon2.argon2id });
    const info = db
      .prepare(`
        INSERT INTO users (
          username, email, password_hash, display_name, role, status,
          max_servers, max_ram_mb, max_disk_mb, max_cpu_cores, created_at
        ) VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, datetime('now'))
      `)
      .run(username, email, hash, displayName, role, maxServers, maxRamMb, maxDiskMb, maxCpuCores);

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'admin.user.create',
      target: `${username} (${role})`,
      ip: req.ip,
      result: 'success'
    });

    res.status(201).json({
      success: true,
      message: `Created user "${username}".`,
      data: { id: info.lastInsertRowid }
    });
  } catch (err) {
    next(err);
  }
});

router.put('/admin/api/users/:id', apiRateLimiter, verifyCsrf, (req, res) => {
  const db = getDb();
  const targetId = parseInt(req.params.id, 10);
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(targetId);
  if (!target) {
    return res.status(404).json({ success: false, message: 'User not found.' });
  }

  const displayName = String(req.body.display_name || target.display_name).trim().slice(0, 48);
  const email = String(req.body.email || target.email).trim().toLowerCase();
  const role = req.body.role === 'admin' ? 'admin' : 'user';
  const status = req.body.status === 'disabled' ? 'disabled' : 'active';
  const maxServers = Math.max(0, parseInt(req.body.max_servers ?? target.max_servers, 10));
  const maxRamMb = Math.max(256, parseInt(req.body.max_ram_mb ?? target.max_ram_mb, 10));
  const maxDiskMb = Math.max(256, parseInt(req.body.max_disk_mb ?? target.max_disk_mb, 10));
  const maxCpuCores = Math.max(0.25, Number(req.body.max_cpu_cores ?? target.max_cpu_cores));

  if (!isValidEmail(email)) {
    return res.status(400).json({ success: false, message: 'Invalid email address.' });
  }

  // Prevent locking out the last active administrator
  if (target.role === 'admin' && (role !== 'admin' || status !== 'active')) {
    const activeAdmins = db
      .prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND status = 'active'")
      .get().c;
    if (activeAdmins <= 1) {
      return res.status(400).json({
        success: false,
        message: 'Cannot demote or disable the only active administrator account.'
      });
    }
  }

  const conflict = db
    .prepare('SELECT id FROM users WHERE email = ? AND id != ?')
    .get(email, targetId);
  if (conflict) {
    return res.status(409).json({ success: false, message: 'Email already used by another user.' });
  }

  db.prepare(`
    UPDATE users
    SET display_name = ?, email = ?, role = ?, status = ?,
        max_servers = ?, max_ram_mb = ?, max_disk_mb = ?, max_cpu_cores = ?
    WHERE id = ?
  `).run(
    displayName,
    email,
    role,
    status,
    maxServers,
    maxRamMb,
    maxDiskMb,
    maxCpuCores,
    targetId
  );

  recordAudit({
    userId: req.user.id,
    username: req.user.username,
    action: 'admin.user.update',
    target: `${target.username} (role=${role}, status=${status})`,
    ip: req.ip,
    result: 'success'
  });

  res.json({ success: true, message: `Updated user "${target.username}".` });
});

router.post('/admin/api/users/:id/reset-password', apiRateLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const db = getDb();
    const targetId = parseInt(req.params.id, 10);
    const target = db.prepare('SELECT id, username FROM users WHERE id = ?').get(targetId);
    if (!target) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const newPassword = String(req.body.password || '');
    if (!isValidPassword(newPassword)) {
      return res.status(400).json({
        success: false,
        message: 'New password must be between 8 and 128 characters.'
      });
    }

    const hash = await argon2.hash(newPassword, { type: argon2.argon2id });
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, target.id);

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'admin.user.reset_password',
      target: target.username,
      ip: req.ip,
      result: 'success'
    });

    res.json({ success: true, message: `Password reset for "${target.username}".` });
  } catch (err) {
    next(err);
  }
});

router.delete('/admin/api/users/:id', apiRateLimiter, verifyCsrf, (req, res) => {
  const db = getDb();
  const targetId = parseInt(req.params.id, 10);
  if (targetId === req.user.id) {
    return res.status(400).json({
      success: false,
      message: 'You cannot delete your own active administrator account.'
    });
  }

  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(targetId);
  if (!target) {
    return res.status(404).json({ success: false, message: 'User not found.' });
  }

  const ownedServers = db
    .prepare('SELECT COUNT(*) AS c FROM servers WHERE owner_id = ?')
    .get(targetId).c;
  if (ownedServers > 0) {
    return res.status(400).json({
      success: false,
      message: `User "${target.username}" still owns ${ownedServers} server(s). Delete or reassign those servers first.`
    });
  }

  db.prepare('DELETE FROM users WHERE id = ?').run(targetId);

  recordAudit({
    userId: req.user.id,
    username: req.user.username,
    action: 'admin.user.delete',
    target: target.username,
    ip: req.ip,
    result: 'success'
  });

  res.json({ success: true, message: `Deleted user "${target.username}".` });
});

// --- 3. ADMIN SERVER MANAGEMENT ---

router.get('/admin/servers', async (req, res, next) => {
  try {
    const db = getDb();
    const rawServers = db
      .prepare(`
        SELECT s.*, u.username AS owner_username, u.email AS owner_email
        FROM servers s
        LEFT JOIN users u ON u.id = s.owner_id
        ORDER BY s.id DESC
      `)
      .all();

    const servers = await Promise.all(rawServers.map((s) => enrichServerWithTelemetry(s)));
    const nodes = db.prepare('SELECT id, name, status FROM nodes ORDER BY id ASC').all();
    const users = db.prepare('SELECT id, username, email FROM users ORDER BY username ASC').all();

    res.render('admin/servers', {
      pageTitle: 'Admin — Servers',
      adminTab: 'servers',
      servers,
      nodes,
      users
    });
  } catch (err) {
    next(err);
  }
});

router.post('/admin/api/servers/:id/power', apiRateLimiter, verifyCsrf, async (req, res) => {
  try {
    const db = getDb();
    const serverRow = db
      .prepare('SELECT * FROM servers WHERE id = ?')
      .get(parseInt(req.params.id, 10));
    if (!serverRow) {
      return res.status(404).json({ success: false, message: 'Server not found.' });
    }
    const action = String(req.body.action || '').toLowerCase();
    const out = await performPowerAction(serverRow, action, req.user, req.ip);
    res.json({ success: true, message: `Server ${action} executed.`, data: out });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

router.post('/admin/api/servers/:id/allocations', apiRateLimiter, verifyCsrf, (req, res) => {
  try {
    const db = getDb();
    const serverId = parseInt(req.params.id, 10);
    const serverRow = db.prepare('SELECT * FROM servers WHERE id = ?').get(serverId);
    if (!serverRow) {
      return res.status(404).json({ success: false, message: 'Server not found.' });
    }

    const ramLimit = Math.max(256, parseInt(req.body.ram_limit || serverRow.ram_limit, 10));
    const cpuLimit = Math.max(0.25, Number(req.body.cpu_limit || serverRow.cpu_limit));
    const diskLimit = Math.max(256, parseInt(req.body.disk_limit || serverRow.disk_limit, 10));
    const port = parseInt(req.body.port || serverRow.port, 10);
    const nodeId = parseInt(req.body.node_id || serverRow.node_id, 10);

    if (!isValidPort(port)) {
      return res.status(400).json({ success: false, message: 'Port must be 1024–65535.' });
    }

    const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);
    if (!node) {
      return res.status(404).json({ success: false, message: 'Target node not found.' });
    }

    const portConflict = db
      .prepare('SELECT id FROM servers WHERE node_id = ? AND port = ? AND id != ?')
      .get(nodeId, port, serverId);
    if (portConflict) {
      return res.status(409).json({
        success: false,
        message: `Port ${port} is already allocated on node "${node.name}".`
      });
    }

    const normalizedStartup = parseAndValidateStartupCommand(
      serverRow.startup_command,
      ramLimit,
      'server.jar'
    ).normalizedCommand;

    db.prepare(`
      UPDATE servers
      SET ram_limit = ?, cpu_limit = ?, disk_limit = ?, port = ?, node_id = ?, startup_command = ?
      WHERE id = ?
    `).run(ramLimit, cpuLimit, diskLimit, port, nodeId, normalizedStartup, serverId);

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'admin.server.allocations_update',
      target: `${serverRow.name} (${serverRow.uuid})`,
      ip: req.ip,
      result: 'success',
      details: { ramLimit, cpuLimit, diskLimit, port, nodeId }
    });

    res.json({ success: true, message: 'Server allocations updated.' });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

router.post('/admin/api/servers/:id/suspend', apiRateLimiter, verifyCsrf, async (req, res) => {
  try {
    const db = getDb();
    const serverId = parseInt(req.params.id, 10);
    const serverRow = db.prepare('SELECT * FROM servers WHERE id = ?').get(serverId);
    if (!serverRow) {
      return res.status(404).json({ success: false, message: 'Server not found.' });
    }

    const suspend = req.body.suspended === true || req.body.suspended === 'true' ? 1 : 0;
    if (suspend && (serverRow.status === 'running' || serverRow.status === 'starting')) {
      try {
        await performPowerAction(serverRow, 'stop', req.user, req.ip);
      } catch (_) {}
    }

    db.prepare('UPDATE servers SET suspended = ? WHERE id = ?').run(suspend, serverId);

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: suspend ? 'admin.server.suspend' : 'admin.server.unsuspend',
      target: `${serverRow.name} (${serverRow.uuid})`,
      ip: req.ip,
      result: 'success'
    });

    res.json({
      success: true,
      message: suspend ? 'Server suspended.' : 'Server unsuspended.'
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

router.delete('/admin/api/servers/:id', apiRateLimiter, verifyCsrf, async (req, res) => {
  try {
    const db = getDb();
    const serverRow = db
      .prepare('SELECT * FROM servers WHERE id = ?')
      .get(parseInt(req.params.id, 10));
    if (!serverRow) {
      return res.status(404).json({ success: false, message: 'Server not found.' });
    }

    await deleteServer(serverRow, req.user, req.ip);
    res.json({ success: true, message: `Deleted server "${serverRow.name}".` });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// --- 4. ADMIN NODE MANAGEMENT ---

router.get('/admin/nodes', async (req, res, next) => {
  try {
    const db = getDb();
    await daemonManager.checkAllNodesHealth();

    const nodes = db
      .prepare(`
        SELECT n.*,
          COUNT(s.id) AS server_count,
          COALESCE(SUM(s.ram_limit), 0) AS allocated_ram_mb,
          COALESCE(SUM(s.disk_limit), 0) AS allocated_disk_mb
        FROM nodes n
        LEFT JOIN servers s ON s.node_id = n.id
        GROUP BY n.id
        ORDER BY n.is_local DESC, n.id ASC
      `)
      .all()
      .map((n) => ({
        ...n,
        health: daemonManager.getNodeHealth(n.id)
      }));

    res.render('admin/nodes', {
      pageTitle: 'Admin — Nodes',
      adminTab: 'nodes',
      nodes
    });
  } catch (err) {
    next(err);
  }
});

router.post('/admin/api/nodes', apiRateLimiter, verifyCsrf, async (req, res) => {
  try {
    const db = getDb();
    const name = String(req.body.name || '').trim().slice(0, 64);
    const host = String(req.body.host || '').trim();
    const publicHost = String(req.body.public_host || host).trim();
    const port = parseInt(req.body.port || '8081', 10);
    const ramCapacity = Math.max(256, parseInt(req.body.ram_capacity || '4096', 10));
    const diskCapacity = Math.max(512, parseInt(req.body.disk_capacity || '20480', 10));
    const cpuCapacity = Math.max(0.5, Number(req.body.cpu_capacity || 4));
    const authToken =
      req.body.auth_token && String(req.body.auth_token).trim().length >= 24
        ? String(req.body.auth_token).trim()
        : generateToken(32);

    if (!name || name.length < 2) {
      return res.status(400).json({ success: false, message: 'Node name is required.' });
    }
    if (!isValidHost(host) || !isValidHost(publicHost)) {
      return res.status(400).json({ success: false, message: 'Invalid node hostname or IP.' });
    }
    if (!isValidPort(port)) {
      return res.status(400).json({ success: false, message: 'Invalid daemon port (1024–65535).' });
    }

    const info = db
      .prepare(`
        INSERT INTO nodes (
          name, host, public_host, port, status,
          ram_capacity, disk_capacity, cpu_capacity,
          daemon_version, auth_token, is_local, created_at
        ) VALUES (?, ?, ?, ?, 'offline', ?, ?, ?, ?, ?, 0, datetime('now'))
      `)
      .run(
        name,
        host,
        publicHost,
        port,
        ramCapacity,
        diskCapacity,
        cpuCapacity,
        config.daemonVersion,
        authToken
      );

    const newNode = db.prepare('SELECT * FROM nodes WHERE id = ?').get(info.lastInsertRowid);
    daemonManager.connectNodeSocket(newNode);
    const health = await daemonManager.checkSingleNodeHealth(newNode);

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'admin.node.create',
      target: `${name} (${host}:${port})`,
      ip: req.ip,
      result: 'success'
    });

    res.status(201).json({
      success: true,
      message: `Node "${name}" added (${health.status}).`,
      data: { id: newNode.id, authToken, status: health.status }
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

router.put('/admin/api/nodes/:id', apiRateLimiter, verifyCsrf, async (req, res) => {
  try {
    const db = getDb();
    const nodeId = parseInt(req.params.id, 10);
    const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);
    if (!node) {
      return res.status(404).json({ success: false, message: 'Node not found.' });
    }

    const name = String(req.body.name || node.name).trim().slice(0, 64);
    const host = String(req.body.host || node.host).trim();
    const publicHost = String(req.body.public_host || node.public_host || host).trim();
    const port = parseInt(req.body.port || node.port, 10);
    const ramCapacity = Math.max(256, parseInt(req.body.ram_capacity || node.ram_capacity, 10));
    const diskCapacity = Math.max(512, parseInt(req.body.disk_capacity || node.disk_capacity, 10));
    const cpuCapacity = Math.max(0.5, Number(req.body.cpu_capacity || node.cpu_capacity));

    if (!isValidHost(host) || !isValidHost(publicHost) || !isValidPort(port)) {
      return res.status(400).json({ success: false, message: 'Invalid host or port.' });
    }

    db.prepare(`
      UPDATE nodes
      SET name = ?, host = ?, public_host = ?, port = ?,
          ram_capacity = ?, disk_capacity = ?, cpu_capacity = ?
      WHERE id = ?
    `).run(name, host, publicHost, port, ramCapacity, diskCapacity, cpuCapacity, nodeId);

    const updatedNode = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);
    daemonManager.connectNodeSocket(updatedNode);
    const health = await daemonManager.checkSingleNodeHealth(updatedNode);

    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'admin.node.update',
      target: `${name} (${host}:${port})`,
      ip: req.ip,
      result: 'success'
    });

    res.json({ success: true, message: `Updated node "${name}".`, data: { health } });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

router.post('/admin/api/nodes/:id/test', apiRateLimiter, verifyCsrf, async (req, res) => {
  const db = getDb();
  const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(parseInt(req.params.id, 10));
  if (!node) {
    return res.status(404).json({ success: false, message: 'Node not found.' });
  }
  const health = await daemonManager.checkSingleNodeHealth(node);
  if (health.status === 'online') {
    return res.json({
      success: true,
      message: `Connected to "${node.name}" (Daemon ${health.daemonVersion}).`,
      data: health
    });
  }
  return res.status(502).json({
    success: false,
    message: health.error || `Node "${node.name}" is unreachable.`,
    data: health
  });
});

router.post('/admin/api/nodes/:id/regenerate-token', apiRateLimiter, verifyCsrf, async (req, res) => {
  const db = getDb();
  const nodeId = parseInt(req.params.id, 10);
  const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);
  if (!node) {
    return res.status(404).json({ success: false, message: 'Node not found.' });
  }

  const newToken = generateToken(48);
  db.prepare('UPDATE nodes SET auth_token = ? WHERE id = ?').run(newToken, nodeId);

  if (node.is_local) {
    process.env.NODE_AUTH_SECRET = newToken;
    config.nodeAuthSecret = newToken;
  }

  const updated = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);
  daemonManager.connectNodeSocket(updated);
  await daemonManager.checkSingleNodeHealth(updated);

  recordAudit({
    userId: req.user.id,
    username: req.user.username,
    action: 'admin.node.regenerate_token',
    target: node.name,
    ip: req.ip,
    result: 'success'
  });

  res.json({
    success: true,
    message: `Regenerated authentication credentials for "${node.name}".`,
    data: { authToken: newToken }
  });
});

router.delete('/admin/api/nodes/:id', apiRateLimiter, verifyCsrf, (req, res) => {
  const db = getDb();
  const nodeId = parseInt(req.params.id, 10);
  const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);
  if (!node) {
    return res.status(404).json({ success: false, message: 'Node not found.' });
  }

  const assignedCount = db
    .prepare('SELECT COUNT(*) AS c FROM servers WHERE node_id = ?')
    .get(nodeId).c;
  if (assignedCount > 0) {
    return res.status(400).json({
      success: false,
      message: `Cannot remove node "${node.name}" while ${assignedCount} server(s) are assigned to it. Delete or migrate those servers first.`
    });
  }

  if (node.is_local) {
    return res.status(400).json({
      success: false,
      message: 'The primary local daemon node cannot be removed.'
    });
  }

  daemonManager.disconnectNodeSocket(nodeId);
  db.prepare('DELETE FROM nodes WHERE id = ?').run(nodeId);

  recordAudit({
    userId: req.user.id,
    username: req.user.username,
    action: 'admin.node.delete',
    target: node.name,
    ip: req.ip,
    result: 'success'
  });

  res.json({ success: true, message: `Removed node "${node.name}".` });
});

// --- 5. SYSTEM DIAGNOSTICS ---

router.get('/admin/system', (req, res) => {
  const db = getDb();
  const sqliteVersion = db.prepare('SELECT sqlite_version() AS v').get().v;
  let dbSizeBytes = 0;
  try {
    dbSizeBytes = fs.statSync(config.databasePath).size;
  } catch (_) {}

  const envCaps = detectEnvironmentCapabilities();
  const javaInfo = detectJavaRuntime(true);
  const hostMetrics = getHostMetrics(config.serversDir);

  res.render('admin/system', {
    pageTitle: 'Admin — System Diagnostics',
    adminTab: 'system',
    sqliteVersion,
    dbSizeBytes,
    envCaps,
    javaInfo,
    hostMetrics
  });
});

// --- 6. PANEL SETTINGS ---

router.get('/admin/settings', (req, res) => {
  const settings = getPanelSettings();
  res.render('admin/settings', {
    pageTitle: 'Admin — Panel Settings',
    adminTab: 'settings',
    settings
  });
});

router.post('/admin/api/settings', apiRateLimiter, verifyCsrf, (req, res) => {
  const allowedKeys = [
    'panel_name',
    'panel_short_name',
    'panel_subtitle',
    'panel_description',
    'logo_url',
    'favicon_url',
    'footer_text',
    'default_language',
    'primary_color',
    'accent_color',
    'dark_theme',
    'sidebar_compact',
    'session_lifetime_hours',
    'max_upload_mb',
    'max_backups_per_server',
    'metrics_retention_hours',
    'maintenance_mode',
    'allow_registration',
    'login_rate_limit_max',
    'login_rate_limit_window_min',
    'api_rate_limit_max'
  ];

  const updates = {};
  for (const key of allowedKeys) {
    if (Object.prototype.hasOwnProperty.call(req.body, key)) {
      updates[key] = String(req.body[key]).trim().slice(0, 300);
    }
  }

  updatePanelSettings(updates);

  recordAudit({
    userId: req.user.id,
    username: req.user.username,
    action: 'admin.settings.update',
    target: 'panel_settings',
    ip: req.ip,
    result: 'success',
    details: Object.keys(updates)
  });

  res.json({ success: true, message: 'Panel settings saved to SQLite.' });
});

// --- 7. AUDIT LOGS ---

router.get('/admin/audit-logs', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  const limit = 50;
  const search = String(req.query.q || '').trim();
  const { rows, total } = listAuditLogs({
    limit,
    offset: (page - 1) * limit,
    search
  });

  res.render('admin/audit-logs', {
    pageTitle: 'Admin — Audit Logs',
    adminTab: 'audit',
    logs: rows,
    total,
    page,
    totalPages: Math.max(1, Math.ceil(total / limit)),
    search
  });
});

module.exports = router;
