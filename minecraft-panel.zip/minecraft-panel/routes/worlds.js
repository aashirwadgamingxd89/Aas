'use strict';

const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const config = require('../config/config');
const { getSetting } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const {
  listServerWorlds,
  activateWorld,
  renameWorld,
  buildWorldZipBuffer,
  deleteWorld,
  installWorldArchive
} = require('../services/worldService');

const router = express.Router();

function createWorldUploader() {
  const maxMb = Math.max(1, parseInt(getSetting('max_upload_mb', String(config.maxUploadMb)), 10) || 256);
  return multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => cb(null, config.worldsDir),
      filename: (req, file, cb) => cb(null, `world-${crypto.randomUUID()}.zip`)
    }),
    limits: { fileSize: maxMb * 1048576, files: 1 }
  });
}

router.get('/server/:uuid/worlds', requireAuth, requireServerAccess, async (req, res, next) => {
  try {
    const data = await listServerWorlds(req.server);
    res.render('server/worlds', {
      pageTitle: `${req.server.name} — Worlds`,
      serverTab: 'worlds',
      activeLevelName: data.activeLevelName,
      worlds: data.worlds
    });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/api/server/:uuid/worlds/activate',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const out = await activateWorld(
        req.server,
        String(req.body.worldName || ''),
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Set "${out.activeLevelName}" as active world. Restart server to apply if currently running.`,
        data: out
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'WORLD_ACTIVATE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/worlds/rename',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const out = await renameWorld(
        req.server,
        String(req.body.oldName || ''),
        String(req.body.newName || ''),
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Renamed world "${out.oldName}" to "${out.newName}".`,
        data: out
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'WORLD_RENAME_ERROR'
      });
    }
  }
);

router.get(
  '/api/server/:uuid/worlds/:worldDir/download',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  (req, res) => {
    try {
      const { fileName, buffer } = buildWorldZipBuffer(req.server, req.params.worldDir);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.send(buffer);
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'WORLD_DOWNLOAD_ERROR'
      });
    }
  }
);

router.delete(
  '/api/server/:uuid/worlds/:worldDir',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const confirmActive =
        req.body && (req.body.confirmActive === true || req.body.confirmActive === 'true');
      const out = await deleteWorld(
        req.server,
        req.params.worldDir,
        confirmActive,
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Deleted world "${out.deleted}".`,
        data: out
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'WORLD_DELETE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/worlds/upload',
  requireAuth,
  verifyCsrf,
  requireServerAccess,
  (req, res, next) => createWorldUploader().single('worldArchive')(req, res, next),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: 'Please select a valid .zip Minecraft world archive.',
          error: 'NO_FILE'
        });
      }
      if (!req.file.originalname.toLowerCase().endsWith('.zip')) {
        throw new Error('Only .zip world archives are supported.');
      }

      const installed = await installWorldArchive(
        req.server,
        req.file.path,
        req.body.worldName || '',
        req.user,
        req.ip
      );

      res.json({
        success: true,
        message: `Imported world "${installed.worldName}" (${installed.sizeMb} MB).`,
        data: installed
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'WORLD_INSTALL_ERROR'
      });
    }
  }
);

module.exports = router;
