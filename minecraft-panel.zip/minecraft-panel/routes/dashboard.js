'use strict';

const express = require('express');
const { getDb } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const { verifyCsrf, apiRateLimiter } = require('../middleware/permissions');
const {
  SUPPORTED_SOFTWARE,
  getUserAllocatedResources,
  getNodeAllocatedResources,
  listVersionsForSoftware,
  createServer,
  enrichServerWithTelemetry
} = require('../services/serverManager');
const { detectJavaRuntime } = require('../utils/systemCheck');

const router = express.Router();

router.get('/', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  return res.redirect('/auth/login');
});

router.get('/dashboard', requireAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const rawServers = db
      .prepare('SELECT * FROM servers WHERE owner_id = ? ORDER BY id DESC')
      .all(req.user.id);

    const servers = await Promise.all(rawServers.map((s) => enrichServerWithTelemetry(s)));

    let runningCount = 0;
    let offlineCount = 0;
    let totalRamMb = 0;
    let totalDiskMb = 0;
    let totalCpu = 0;

    for (const s of servers) {
      if (s.status === 'running' || s.status === 'starting') {
        runningCount++;
      } else {
        offlineCount++;
      }
      totalRamMb += s.ram_limit || 0;
      totalDiskMb += s.disk_limit || 0;
      totalCpu += s.cpu_limit || 0;
    }

    res.render('user/dashboard', {
      pageTitle: 'Dashboard',
      servers,
      summary: {
        totalServers: servers.length,
        runningServers: runningCount,
        offlineServers: offlineCount,
        allocatedRamMb: totalRamMb,
        allocatedDiskMb: totalDiskMb,
        allocatedCpuCores: Number(totalCpu.toFixed(2))
      }
    });
  } catch (err) {
    next(err);
  }
});

router.get('/servers/create', requireAuth, (req, res) => {
  const db = getDb();
  const nodes = db.prepare('SELECT id, name, public_host, host, status, ram_capacity, disk_capacity, cpu_capacity FROM nodes ORDER BY is_local DESC, id ASC').all();
  const nodesWithRemaining = nodes.map((n) => {
    const used = getNodeAllocatedResources(n.id);
    return {
      ...n,
      freeRamMb: Math.max(0, n.ram_capacity - used.ramMb),
      freeDiskMb: Math.max(0, n.disk_capacity - used.diskMb),
      freeCpuCores: Math.max(0, Number((n.cpu_capacity - used.cpuCores).toFixed(2)))
    };
  });

  const userUsed = getUserAllocatedResources(req.user.id);
  const javaInfo = detectJavaRuntime();

  res.render('user/create-server', {
    pageTitle: 'Create Server',
    nodes: nodesWithRemaining,
    softwareOptions: SUPPORTED_SOFTWARE,
    javaInfo,
    quota: {
      usedServers: userUsed.serverCount,
      maxServers: req.user.max_servers,
      freeRamMb: Math.max(0, req.user.max_ram_mb - userUsed.ramMb),
      maxRamMb: req.user.max_ram_mb,
      freeDiskMb: Math.max(0, req.user.max_disk_mb - userUsed.diskMb),
      maxDiskMb: req.user.max_disk_mb,
      freeCpuCores: Math.max(0, Number((req.user.max_cpu_cores - userUsed.cpuCores).toFixed(2))),
      maxCpuCores: req.user.max_cpu_cores
    }
  });
});

router.get('/api/software/:type/versions', requireAuth, apiRateLimiter, async (req, res) => {
  try {
    const nodeId = req.query.nodeId ? parseInt(req.query.nodeId, 10) : null;
    const versions = await listVersionsForSoftware(req.params.type, nodeId);
    res.json({ success: true, message: 'Supported versions loaded.', data: { versions } });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message, error: 'VERSIONS_ERROR' });
  }
});

router.post('/api/servers', requireAuth, apiRateLimiter, verifyCsrf, async (req, res) => {
  try {
    const serverRow = await createServer({
      actor: req.user,
      ownerId: req.user.id,
      name: req.body.name,
      description: req.body.description,
      software: req.body.software,
      mcVersion: req.body.mc_version,
      ramLimitMb: req.body.ram_limit,
      diskLimitMb: req.body.disk_limit,
      cpuLimit: req.body.cpu_limit,
      nodeId: req.body.node_id ? parseInt(req.body.node_id, 10) : null,
      port: req.body.port ? parseInt(req.body.port, 10) : null,
      ip: req.ip
    });

    res.status(201).json({
      success: true,
      message: 'Server created. Software installation has started.',
      data: {
        id: serverRow.id,
        uuid: serverRow.uuid,
        status: serverRow.status
      }
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      message: err.message,
      error: 'SERVER_CREATE_FAILED'
    });
  }
});

module.exports = router;
