'use strict';

const express = require('express');
const { getDb } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const { isValidServerName } = require('../utils/validators');
const {
  SUPPORTED_SOFTWARE,
  listVersionsForSoftware,
  reinstallServer,
  deleteServer
} = require('../services/serverManager');
const { recordAudit } = require('../services/auditService');

const router = express.Router();

router.get('/server/:uuid/settings', requireAuth, requireServerAccess, async (req, res, next) => {
  try {
    let versions = [];
    try {
      versions = await listVersionsForSoftware(req.server.server_type, req.server.node_id);
    } catch (_) {
      versions = [req.server.mc_version];
    }

    res.render('server/settings', {
      pageTitle: `${req.server.name} — Settings`,
      serverTab: 'settings',
      softwareOptions: SUPPORTED_SOFTWARE,
      availableVersions: versions
    });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/api/server/:uuid/settings',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  (req, res) => {
    try {
      const name = String(req.body.name || '').trim();
      const description = String(req.body.description || '').trim().slice(0, 250);

      if (!isValidServerName(name)) {
        return res.status(400).json({
          success: false,
          message: 'Server name must be 2–64 characters.',
          error: 'VALIDATION_ERROR'
        });
      }

      const db = getDb();
      db.prepare('UPDATE servers SET name = ?, description = ? WHERE id = ?').run(
        name,
        description,
        req.server.id
      );

      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'server.settings_update',
        target: `${name} (${req.server.uuid})`,
        ip: req.ip,
        result: 'success'
      });

      res.json({
        success: true,
        message: 'Server settings saved successfully.'
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'SETTINGS_UPDATE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/settings/reinstall',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const software = String(req.body.software || req.server.server_type).toLowerCase();
      const mcVersion = String(req.body.mc_version || req.server.mc_version).trim();

      await reinstallServer(req.server, { software, mcVersion }, req.user, req.ip);

      res.json({
        success: true,
        message: `Reinstallation started (${software.toUpperCase()} ${mcVersion}).`,
        data: { software, mcVersion }
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'REINSTALL_ERROR'
      });
    }
  }
);

router.delete(
  '/api/server/:uuid',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const confirmName = String((req.body && req.body.confirmName) || '').trim();
      if (confirmName !== req.server.name) {
        return res.status(400).json({
          success: false,
          message: `Confirmation failed. Please type the exact server name "${req.server.name}" to confirm permanent deletion.`,
          error: 'CONFIRMATION_MISMATCH'
        });
      }

      await deleteServer(req.server, req.user, req.ip);

      res.json({
        success: true,
        message: `Server "${req.server.name}" has been permanently deleted.`
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'SERVER_DELETE_ERROR'
      });
    }
  }
);

module.exports = router;
