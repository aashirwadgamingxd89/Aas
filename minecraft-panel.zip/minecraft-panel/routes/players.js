'use strict';

const express = require('express');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const {
  getPlayersOverview,
  executePlayerAction
} = require('../services/playerService');

const router = express.Router();

router.get('/server/:uuid/players', requireAuth, requireServerAccess, (req, res) => {
  const playerData = getPlayersOverview(req.server);
  res.render('server/players', {
    pageTitle: `${req.server.name} — Players`,
    serverTab: 'players',
    playerData
  });
});

router.get('/api/server/:uuid/players', requireAuth, apiRateLimiter, requireServerAccess, (req, res) => {
  const playerData = getPlayersOverview(req.server);
  res.json({ success: true, message: 'Players retrieved.', data: playerData });
});

router.post(
  '/api/server/:uuid/players/action',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const out = await executePlayerAction(
        req.server,
        {
          action: String(req.body.action || ''),
          username: String(req.body.username || ''),
          reason: String(req.body.reason || '')
        },
        req.user,
        req.ip
      );
      res.json({
        success: true,
        message: `Executed "${out.action}" for ${out.username}.`,
        data: out
      });
    } catch (err) {
      res.status(400).json({
        success: false,
        message: err.message,
        error: 'PLAYER_ACTION_ERROR'
      });
    }
  }
);

module.exports = router;
