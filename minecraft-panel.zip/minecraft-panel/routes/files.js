'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const config = require('../config/config');
const { getSetting } = require('../database/database');
const { requireAuth } = require('../middleware/auth');
const {
  requireServerAccess,
  verifyCsrf,
  apiRateLimiter
} = require('../middleware/permissions');
const { resolveSafePath, sanitizeFilename } = require('../utils/pathGuard');
const {
  listServerDirectory,
  readTextFile,
  writeTextFile,
  createDirectory,
  createEmptyFile,
  renameItem,
  deleteItems,
  zipSelectedItems,
  buildDownloadBufferForMultiple,
  extractZipInServer,
  assertDiskQuotaAvailable
} = require('../services/fileService');
const { recordAudit } = require('../services/auditService');

const router = express.Router();

const uploadStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadsDir),
  filename: (req, file, cb) => cb(null, `upload-${crypto.randomUUID()}`)
});

function createUploader() {
  const maxMb = Math.max(1, parseInt(getSetting('max_upload_mb', String(config.maxUploadMb)), 10) || 256);
  return multer({
    storage: uploadStorage,
    limits: {
      fileSize: maxMb * 1048576,
      files: 20
    }
  });
}

router.get('/server/:uuid/files', requireAuth, requireServerAccess, async (req, res, next) => {
  try {
    const relDir = String(req.query.path || '');
    const listing = await listServerDirectory(req.server, relDir);
    res.render('server/files', {
      pageTitle: `${req.server.name} — File Manager`,
      serverTab: 'files',
      initialPath: listing.currentPath,
      initialItems: listing.items
    });
  } catch (err) {
    next(err);
  }
});

router.get(
  '/api/server/:uuid/files/list',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  async (req, res) => {
    try {
      const listing = await listServerDirectory(req.server, String(req.query.path || ''));
      res.json({ success: true, message: 'Directory listed.', data: listing });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'FILE_LIST_ERROR'
      });
    }
  }
);

router.get(
  '/api/server/:uuid/files/read',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  async (req, res) => {
    try {
      const fileData = await readTextFile(req.server, String(req.query.path || ''));
      res.json({ success: true, message: 'File loaded.', data: fileData });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'FILE_READ_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/write',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const result = await writeTextFile(req.server, req.body.path, req.body.content);
      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'file.save',
        target: `${req.server.name}: ${result.path}`,
        ip: req.ip,
        result: 'success'
      });
      res.json({ success: true, message: 'File saved successfully.', data: result });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'FILE_WRITE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/mkdir',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const result = await createDirectory(
        req.server,
        String(req.body.parentPath || ''),
        String(req.body.name || '')
      );
      res.json({ success: true, message: 'Folder created.', data: result });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'MKDIR_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/touch',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const result = await createEmptyFile(
        req.server,
        String(req.body.parentPath || ''),
        String(req.body.name || ''),
        String(req.body.content || '')
      );
      res.json({ success: true, message: 'File created.', data: result });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'CREATE_FILE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/rename',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const result = await renameItem(
        req.server,
        String(req.body.path || ''),
        String(req.body.newName || '')
      );
      res.json({ success: true, message: 'Renamed successfully.', data: result });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'RENAME_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/delete',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const paths = Array.isArray(req.body.paths) ? req.body.paths : [];
      const result = await deleteItems(req.server, paths);
      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'file.delete',
        target: `${req.server.name} (${result.deleted} item(s))`,
        ip: req.ip,
        result: 'success'
      });
      res.json({ success: true, message: `Deleted ${result.deleted} item(s).`, data: result });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'DELETE_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/upload',
  requireAuth,
  verifyCsrf,
  requireServerAccess,
  (req, res, next) => createUploader().array('files', 20)(req, res, next),
  async (req, res) => {
    const uploaded = req.files || [];
    try {
      if (uploaded.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'No files were uploaded.',
          error: 'NO_FILES'
        });
      }

      const totalBytes = uploaded.reduce((sum, f) => sum + (f.size || 0), 0);
      await assertDiskQuotaAvailable(req.server, totalBytes);

      const targetDir = resolveSafePath(req.server.server_dir, String(req.body.path || ''));
      await fsp.mkdir(targetDir, { recursive: true });

      const saved = [];
      for (const file of uploaded) {
        const cleanName = sanitizeFilename(file.originalname);
        const destFile = resolveSafePath(targetDir, cleanName);
        await fsp.copyFile(file.path, destFile);
        saved.push(cleanName);
      }

      recordAudit({
        userId: req.user.id,
        username: req.user.username,
        action: 'file.upload',
        target: `${req.server.name}: ${saved.join(', ')}`,
        ip: req.ip,
        result: 'success'
      });

      res.json({
        success: true,
        message: `Uploaded ${saved.length} file(s) successfully.`,
        data: { files: saved }
      });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'UPLOAD_ERROR'
      });
    } finally {
      for (const file of uploaded) {
        try {
          if (file.path && fs.existsSync(file.path)) await fsp.unlink(file.path);
        } catch (_) {}
      }
    }
  }
);

router.get(
  '/api/server/:uuid/files/download',
  requireAuth,
  apiRateLimiter,
  requireServerAccess,
  async (req, res) => {
    try {
      if (req.query.paths) {
        let paths = [];
        try {
          paths = JSON.parse(String(req.query.paths));
        } catch (_) {
          paths = String(req.query.paths).split(',').filter(Boolean);
        }
        const buf = buildDownloadBufferForMultiple(req.server, paths);
        const zipName = `${sanitizeFilename(req.server.name)}-files.zip`;
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="${zipName}"`);
        return res.send(buf);
      }

      const relPath = String(req.query.path || '');
      const fullPath = resolveSafePath(req.server.server_dir, relPath);
      const stat = await fsp.stat(fullPath);

      if (stat.isDirectory()) {
        const buf = buildDownloadBufferForMultiple(req.server, [relPath]);
        const zipName = `${sanitizeFilename(path.basename(fullPath))}.zip`;
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="${zipName}"`);
        return res.send(buf);
      }

      return res.download(fullPath, path.basename(fullPath));
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'DOWNLOAD_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/zip',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const paths = Array.isArray(req.body.paths) ? req.body.paths : [];
      const currentDir = String(req.body.currentPath || '');
      const archiveName = req.body.archiveName ? String(req.body.archiveName) : null;
      const out = await zipSelectedItems(req.server, paths, currentDir, archiveName);
      res.json({
        success: true,
        message: `Created ZIP archive "${out.name}".`,
        data: out
      });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'ZIP_ERROR'
      });
    }
  }
);

router.post(
  '/api/server/:uuid/files/unzip',
  requireAuth,
  apiRateLimiter,
  verifyCsrf,
  requireServerAccess,
  async (req, res) => {
    try {
      const out = await extractZipInServer(
        req.server,
        String(req.body.path || ''),
        String(req.body.targetPath || '')
      );
      res.json({
        success: true,
        message: `Extracted ${out.extractedFiles} file(s) safely.`,
        data: out
      });
    } catch (err) {
      res.status(err.statusCode || 400).json({
        success: false,
        message: err.message,
        error: 'UNZIP_ERROR'
      });
    }
  }
);

module.exports = router;
