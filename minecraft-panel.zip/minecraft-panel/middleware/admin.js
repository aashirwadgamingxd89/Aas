'use strict';

const { wantsJson } = require('./auth');
const { recordAudit } = require('../services/auditService');

function requireAdmin(req, res, next) {
  if (!req.user) {
    if (wantsJson(req)) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required.',
        error: 'UNAUTHENTICATED'
      });
    }
    return res.redirect('/auth/login');
  }

  if (req.user.role !== 'admin') {
    recordAudit({
      userId: req.user.id,
      username: req.user.username,
      action: 'admin.unauthorized_attempt',
      target: req.originalUrl,
      ip: req.ip,
      result: 'denied'
    });

    if (wantsJson(req)) {
      return res.status(403).json({
        success: false,
        message: 'Administrator privileges are required for this action.',
        error: 'FORBIDDEN'
      });
    }

    return res.status(403).render('error', {
      pageTitle: 'Access Denied',
      statusCode: 403,
      message: 'You do not have administrator permissions to view this section.'
    });
  }

  next();
}

module.exports = {
  requireAdmin
};
