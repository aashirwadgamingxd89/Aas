'use strict';

const { getDb, getSetting } = require('../database/database');
const { verifyCsrfToken } = require('../utils/cryptoUtils');
const { wantsJson } = require('./auth');
const { enrichServerWithTelemetry } = require('../services/serverManager');

function verifyCsrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }

  const token =
    req.headers['x-csrf-token'] ||
    (req.body && req.body._csrf) ||
    (req.query && req.query._csrf);

  if (!verifyCsrfToken(req.sessionID, token)) {
    if (wantsJson(req)) {
      return res.status(403).json({
        success: false,
        message: 'Invalid or expired security token (CSRF). Refresh the page and try again.',
        error: 'CSRF_INVALID'
      });
    }
    return res.status(403).render('error', {
      pageTitle: 'Security Token Expired',
      statusCode: 403,
      message: 'Your form security token expired or is invalid. Please go back, refresh, and submit again.'
    });
  }

  next();
}

async function requireServerAccess(req, res, next) {
  try {
    const identifier = req.params.uuid || req.params.serverId;
    if (!identifier) {
      return res.status(400).render('error', {
        pageTitle: 'Invalid Request',
        statusCode: 400,
        message: 'Missing server identifier.'
      });
    }

    const db = getDb();
    const serverRow = /^\d+$/.test(String(identifier))
      ? db.prepare('SELECT * FROM servers WHERE id = ?').get(Number(identifier))
      : db.prepare('SELECT * FROM servers WHERE uuid = ?').get(String(identifier));

    if (!serverRow) {
      if (wantsJson(req)) {
        return res.status(404).json({
          success: false,
          message: 'Server not found.',
          error: 'SERVER_NOT_FOUND'
        });
      }
      return res.status(404).render('error', {
        pageTitle: 'Server Not Found',
        statusCode: 404,
        message: 'The requested Minecraft server does not exist or has been deleted.'
      });
    }

    if (req.user.role !== 'admin' && serverRow.owner_id !== req.user.id) {
      if (wantsJson(req)) {
        return res.status(403).json({
          success: false,
          message: 'You are not authorized to access this server.',
          error: 'FORBIDDEN'
        });
      }
      return res.status(403).render('error', {
        pageTitle: 'Forbidden',
        statusCode: 403,
        message: 'You do not have permission to manage this server.'
      });
    }

    if (serverRow.suspended && req.user.role !== 'admin') {
      if (wantsJson(req)) {
        return res.status(423).json({
          success: false,
          message: 'This server has been suspended by an administrator.',
          error: 'SERVER_SUSPENDED'
        });
      }
      return res.status(423).render('error', {
        pageTitle: 'Server Suspended',
        statusCode: 423,
        message: 'This server is currently suspended. Contact an administrator for assistance.'
      });
    }

    const enriched = await enrichServerWithTelemetry(serverRow);
    req.server = enriched;
    res.locals.activeServer = enriched;
    next();
  } catch (err) {
    next(err);
  }
}

function createRateLimiter({ getMax, getWindowMs, keyPrefix = 'rl' }) {
  const buckets = new Map();

  const cleanup = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of buckets.entries()) {
      if (v.resetAt <= now) buckets.delete(k);
    }
  }, 60000);
  cleanup.unref();

  return (req, res, next) => {
    const max = typeof getMax === 'function' ? getMax() : getMax;
    const windowMs = typeof getWindowMs === 'function' ? getWindowMs() : getWindowMs;
    const ip = req.ip || 'unknown';
    const key = `${keyPrefix}:${ip}`;
    const now = Date.now();

    let bucket = buckets.get(key);
    if (!bucket || bucket.resetAt <= now) {
      bucket = { count: 1, resetAt: now + windowMs };
      buckets.set(key, bucket);
      return next();
    }

    bucket.count++;
    if (bucket.count > max) {
      const retryAfterSec = Math.max(1, Math.ceil((bucket.resetAt - now) / 1000));
      res.set('Retry-After', String(retryAfterSec));
      if (wantsJson(req)) {
        return res.status(429).json({
          success: false,
          message: `Too many requests. Please try again in ${retryAfterSec} seconds.`,
          error: 'RATE_LIMITED'
        });
      }
      return res.status(429).render('error', {
        pageTitle: 'Too Many Requests',
        statusCode: 429,
        message: `Rate limit exceeded. Please wait ${retryAfterSec} seconds before retrying.`
      });
    }

    next();
  };
}

const loginRateLimiter = createRateLimiter({
  keyPrefix: 'login',
  getMax: () => Math.max(3, parseInt(getSetting('login_rate_limit_max', '10'), 10) || 10),
  getWindowMs: () =>
    Math.max(1, parseInt(getSetting('login_rate_limit_window_min', '15'), 10) || 15) * 60 * 1000
});

const apiRateLimiter = createRateLimiter({
  keyPrefix: 'api',
  getMax: () => Math.max(30, parseInt(getSetting('api_rate_limit_max', '180'), 10) || 180),
  getWindowMs: () => 60 * 1000
});

function maintenanceGuard(req, res, next) {
  const isMaintenance = getSetting('maintenance_mode', 'false') === 'true';
  if (!isMaintenance) return next();

  if (
    req.path.startsWith('/auth') ||
    req.path.startsWith('/health') ||
    req.path.startsWith('/api/health') ||
    (req.user && req.user.role === 'admin')
  ) {
    return next();
  }

  if (wantsJson(req)) {
    return res.status(503).json({
      success: false,
      message: 'Panel is currently in maintenance mode.',
      error: 'MAINTENANCE_MODE'
    });
  }

  return res.status(503).render('error', {
    pageTitle: 'Maintenance Mode',
    statusCode: 503,
    message: 'The control panel is undergoing scheduled maintenance. Administrator login remains active.'
  });
}

module.exports = {
  verifyCsrf,
  requireServerAccess,
  loginRateLimiter,
  apiRateLimiter,
  maintenanceGuard
};
