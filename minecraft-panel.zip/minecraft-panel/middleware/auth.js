'use strict';

const session = require('express-session');
const config = require('../config/config');
const { getDb, getPanelSettings, getSetting } = require('../database/database');
const { createCsrfToken } = require('../utils/cryptoUtils');
const { getUnreadCount } = require('../services/notificationService');

class SqliteSessionStore extends session.Store {
  constructor() {
    super();
    const cleanupTimer = setInterval(() => {
      try {
        const db = getDb();
        db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
      } catch (_) {}
    }, 10 * 60 * 1000);
    cleanupTimer.unref();
  }

  get(sid, callback) {
    try {
      const db = getDb();
      const row = db
        .prepare('SELECT sess, expires_at FROM sessions WHERE sid = ?')
        .get(sid);
      if (!row) return callback(null, null);
      if (row.expires_at <= Date.now()) {
        db.prepare('DELETE FROM sessions WHERE sid = ?').run(sid);
        return callback(null, null);
      }
      return callback(null, JSON.parse(row.sess));
    } catch (err) {
      return callback(err);
    }
  }

  set(sid, sess, callback) {
    try {
      const db = getDb();
      const maxAge =
        sess && sess.cookie && sess.cookie.maxAge
          ? sess.cookie.maxAge
          : config.sessionLifetimeHours * 3600 * 1000;
      const expiresAt = Date.now() + maxAge;
      db.prepare(`
        INSERT INTO sessions (sid, sess, expires_at)
        VALUES (?, ?, ?)
        ON CONFLICT(sid) DO UPDATE SET sess = excluded.sess, expires_at = excluded.expires_at
      `).run(sid, JSON.stringify(sess), expiresAt);
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  }

  destroy(sid, callback) {
    try {
      const db = getDb();
      db.prepare('DELETE FROM sessions WHERE sid = ?').run(sid);
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  }

  touch(sid, sess, callback) {
    return this.set(sid, sess, callback);
  }
}

const sessionStore = new SqliteSessionStore();

const baseSessionMiddleware = session({
  name: 'ag_panel_sid',
  secret: config.sessionSecret,
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  proxy: true,
  cookie: {
    httpOnly: true,
    maxAge: config.sessionLifetimeHours * 3600 * 1000,
    sameSite: 'lax',
    secure: 'auto'
  }
});

/**
 * Ensures cookies work seamlessly both on direct HTTP (SameSite=Lax) and behind
 * HTTPS reverse-proxied iframe preview environments (SameSite=None; Secure; Partitioned).
 */
function sessionMiddleware(req, res, next) {
  baseSessionMiddleware(req, res, (err) => {
    if (err) return next(err);
    const isHttps =
      req.secure ||
      String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https';

    const lifetimeHours = Math.max(
      1,
      parseInt(getSetting('session_lifetime_hours', String(config.sessionLifetimeHours)), 10) || 24
    );

    if (req.session && req.session.cookie) {
      req.session.cookie.maxAge = lifetimeHours * 3600 * 1000;
      if (isHttps) {
        req.session.cookie.secure = true;
        req.session.cookie.sameSite = 'none';
        req.session.cookie.partitioned = true;
      } else {
        req.session.cookie.secure = false;
        req.session.cookie.sameSite = 'lax';
      }
    }
    next();
  });
}

function attachLocals(req, res, next) {
  const db = getDb();
  const settings = getPanelSettings();

  res.locals.panelSettings = settings;
  res.locals.panelVersion = config.panelVersion;
  res.locals.daemonVersion = config.daemonVersion;
  res.locals.developer = config.developer;
  res.locals.currentPath = req.path;
  res.locals.activeServer = null;

  // Flash helper
  req.flash = (type, message) => {
    if (!req.session) return;
    req.session.flash = { type, message };
  };
  if (req.session && req.session.flash) {
    res.locals.flash = req.session.flash;
    delete req.session.flash;
  } else {
    res.locals.flash = null;
  }

  req.user = null;
  res.locals.currentUser = null;
  res.locals.unreadNotificationsCount = 0;
  res.locals.userServers = [];

  if (req.session && req.session.userId) {
    const user = db
      .prepare(
        'SELECT id, username, email, display_name, role, status, avatar_color, avatar_url, max_servers, max_ram_mb, max_disk_mb, max_cpu_cores, created_at, last_login FROM users WHERE id = ?'
      )
      .get(req.session.userId);

    if (!user || user.status !== 'active') {
      req.session.destroy(() => {});
    } else {
      req.user = user;
      res.locals.currentUser = user;
      res.locals.unreadNotificationsCount = getUnreadCount(user.id);
      res.locals.userServers = db
        .prepare(
          'SELECT id, uuid, name, server_type, mc_version, status, suspended FROM servers WHERE owner_id = ? ORDER BY id DESC'
        )
        .all(user.id);
    }
  }

  if (req.session) {
    if (!req.session.csrfNonce) {
      req.session.csrfNonce = require('crypto').randomBytes(16).toString('hex');
    }
    res.locals.csrfToken = createCsrfToken(req.sessionID, req.session.csrfNonce);
  } else {
    res.locals.csrfToken = '';
  }

  next();
}

function wantsJson(req) {
  return (
    req.xhr ||
    req.path.startsWith('/api/') ||
    req.path.includes('/api/') ||
    String(req.headers.accept || '').includes('application/json')
  );
}

function requireAuth(req, res, next) {
  if (!req.user) {
    if (wantsJson(req)) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required. Please sign in.',
        error: 'UNAUTHENTICATED'
      });
    }
    return res.redirect('/auth/login');
  }
  next();
}

function guestOnly(req, res, next) {
  if (req.user) {
    return res.redirect('/dashboard');
  }
  next();
}

module.exports = {
  sessionStore,
  sessionMiddleware,
  attachLocals,
  requireAuth,
  guestOnly,
  wantsJson
};
