'use strict';

const { logger } = require('../config/logger');
const { wantsJson } = require('./auth');

function notFoundHandler(req, res) {
  if (wantsJson(req)) {
    return res.status(404).json({
      success: false,
      message: `Endpoint not found: ${req.method} ${req.originalUrl}`,
      error: 'NOT_FOUND'
    });
  }

  return res.status(404).render('error', {
    pageTitle: '404 — Page Not Found',
    statusCode: 404,
    message: 'The page or resource you requested could not be found.'
  });
}

function globalErrorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  const statusCode =
    err.statusCode ||
    (err.code === 'LIMIT_FILE_SIZE' ? 413 : 500);

  logger.error('http', err.message || 'Unhandled application error', {
    statusCode,
    method: req.method,
    url: req.originalUrl,
    stack: err.stack
  });

  const safeMessage =
    err.code === 'LIMIT_FILE_SIZE'
      ? 'Uploaded file exceeds the configured upload size limit.'
      : statusCode < 500
      ? err.message
      : 'An unexpected server error occurred. Please check server logs or try again.';

  if (wantsJson(req)) {
    return res.status(statusCode).json({
      success: false,
      message: safeMessage,
      error: err.name || 'SERVER_ERROR'
    });
  }

  return res.status(statusCode).render('error', {
    pageTitle: `Error ${statusCode}`,
    statusCode,
    message: safeMessage
  });
}

module.exports = {
  notFoundHandler,
  globalErrorHandler
};
